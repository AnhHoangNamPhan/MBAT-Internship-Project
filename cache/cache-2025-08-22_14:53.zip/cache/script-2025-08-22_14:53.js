
        var arboe = arboe || {};
        arboe = Object.assign(arboe, {
            // Variables
            json: {
    "type": "FeatureCollection",
    "features": [
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.8190106,
                    48.634186
                ]
            },
            "properties": {
                "id": "INFT-AJJKUQ",
                "name": "Goldbergertank",
                "S98": "0",
                "S95": "1.549",
                "N": "0",
                "D": "1.549",
                "G": "0",
                "zip": "3730",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Horn",
                "city": "Eggenburg",
                "strasse": "Wienerstrasse 13",
                "date": "22.8.2025",
                "time": "5:37:44"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.240267,
                    48.9298793
                ]
            },
            "properties": {
                "id": "INFT-AJJKXT",
                "name": "Genol Lagerhaus Tankstelle",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.579",
                "G": "0",
                "zip": "3851",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Waidhofen/Thaya",
                "city": "Kautzen",
                "strasse": "Illmauerstraße 1",
                "date": "22.8.2025",
                "time": "5:37:55"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.0870434,
                    47.7326535
                ]
            },
            "properties": {
                "id": "INFT-AJJKL5",
                "name": "SB-Tankstelle Ofenböck",
                "S98": "0",
                "S95": "1.509",
                "N": "0",
                "D": "1.519",
                "G": "0",
                "zip": "2620",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Neunkirchen",
                "city": "Neunkirchen",
                "strasse": "Föhrenwaldstrasse 35",
                "date": "22.8.2025",
                "time": "5:37:51"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.2412365,
                    48.312442
                ]
            },
            "properties": {
                "id": "INFT-AJJKVA",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.481",
                "G": "0",
                "zip": "4048",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Urfahr Umgebung",
                "city": "Puchenau",
                "strasse": "Hammerschmiede 3",
                "date": "22.8.2025",
                "time": "5:38:16"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.9583799,
                    48.7536887
                ]
            },
            "properties": {
                "id": "INFT-AJJL8T",
                "name": "Pollak-Deine Tankstelle",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.47",
                "G": "0",
                "zip": "2070",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Hollabrunn",
                "city": "Retz",
                "strasse": "Im Stadtfeld 2",
                "date": "22.8.2025",
                "time": "5:37:43"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.12554,
                    47.3744
                ]
            },
            "properties": {
                "id": "INFT-AJJKTZ",
                "name": "AVANTI - Pinkafeld Wiener Straße 8",
                "S98": "0",
                "S95": "1.478",
                "N": "0",
                "D": "1.488",
                "G": "0",
                "zip": "7423",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Oberwart",
                "city": "Pinkafeld",
                "strasse": "Wiener Strasse 8",
                "date": "22.8.2025",
                "time": "5:37:25"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.8824867,
                    47.4347321
                ]
            },
            "properties": {
                "id": "INFT-AJJL24",
                "name": "Rissbacher Walter GmbH",
                "S98": "0",
                "S95": "1.469",
                "N": "0",
                "D": "1.469",
                "G": "0",
                "zip": "6230",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Kufstein",
                "city": "Brixlegg",
                "strasse": "Innsbrucker Str. 47",
                "date": "22.8.2025",
                "time": "5:38:42"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.163935,
                    47.168488
                ]
            },
            "properties": {
                "id": "INFT-AJJLBH",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.467",
                "N": "0",
                "D": "1.477",
                "G": "0",
                "zip": "7551",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Güssing",
                "city": "Stegersbach",
                "strasse": "Wienerstraße 56",
                "date": "22.8.2025",
                "time": "5:37:20"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.8368875,
                    47.8565454
                ]
            },
            "properties": {
                "id": "INFT-AJJL9F",
                "name": "Lagerhaus-Genol",
                "S98": "0",
                "S95": "1.474",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "7141",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Neusiedl am See",
                "city": "Podersdorf",
                "strasse": "Weinberggasse 1",
                "date": "22.8.2025",
                "time": "5:37:23"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.2678969,
                    46.8971308
                ]
            },
            "properties": {
                "id": "INFT-AJJKWG",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.434",
                "N": "0",
                "D": "1.449",
                "G": "0",
                "zip": "8510",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Deutschlandsberg",
                "city": "Stainz",
                "strasse": "Grazer Straße 34-35",
                "date": "22.8.2025",
                "time": "5:38:26"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.42064,
                    48.05739
                ]
            },
            "properties": {
                "id": "INFT-AJJKUX",
                "name": "AVANTI - Steyr Ennser Straße 16",
                "S98": "0",
                "S95": "1.432",
                "N": "0",
                "D": "1.46",
                "G": "0",
                "zip": "4400",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Steyr Land",
                "city": "Steyr",
                "strasse": "Ennser Strasse 16",
                "date": "22.8.2025",
                "time": "5:38:1"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.73571,
                    47.3999401
                ]
            },
            "properties": {
                "id": "INFT-AJJKMN",
                "name": "Disk + Tankautomat",
                "S98": "0",
                "S95": "1.508",
                "N": "0",
                "D": "1.529",
                "G": "0",
                "zip": "6850",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Dornbirn",
                "city": "Dornbirn",
                "strasse": "Arlbergstraße 6",
                "date": "22.8.2025",
                "time": "5:38:50"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.272992,
                    47.002851
                ]
            },
            "properties": {
                "id": "INFT-AJJKNL",
                "name": "Diskonttankstelle Kaier",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.429",
                "G": "0",
                "zip": "8561",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Graz Umgebung",
                "city": "Söding",
                "strasse": "Packerstraße 106",
                "date": "22.8.2025",
                "time": "5:38:32"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.1558516,
                    46.7337805
                ]
            },
            "properties": {
                "id": "INFT-AJJL7N",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.452",
                "N": "0",
                "D": "1.454",
                "G": "0",
                "zip": "9560",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Feldkirchen",
                "city": "Untere Glan",
                "strasse": "Bundesstraße 33",
                "date": "22.8.2025",
                "time": "5:37:34"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.9238938,
                    47.8438135
                ]
            },
            "properties": {
                "id": "INFT-AJJL9L",
                "name": "LSC Wenzl GmbH",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.49",
                "G": "0",
                "zip": "7132",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Neusiedl am See",
                "city": "Frauenkirchen",
                "strasse": "Krautgartengasse 20",
                "date": "22.8.2025",
                "time": "5:37:22"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.28828,
                    48.28312
                ]
            },
            "properties": {
                "id": "INFT-AJJKLW",
                "name": "AVANTI - Linz Unionstraße 71a",
                "S98": "0",
                "S95": "1.454",
                "N": "0",
                "D": "1.474",
                "G": "0",
                "zip": "4020",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Linz Land",
                "city": "Linz",
                "strasse": "Unionstrasse 71a",
                "date": "22.8.2025",
                "time": "5:37:59"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.596074,
                    48.25254
                ]
            },
            "properties": {
                "id": "INFT-AJJL3F",
                "name": "Petschl Tankstelle",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.474",
                "G": "0",
                "zip": "4320",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Perg",
                "city": "Perg",
                "strasse": "Josef-Petschl-Straße 1",
                "date": "22.8.2025",
                "time": "5:38:11"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.77229,
                    47.38314
                ]
            },
            "properties": {
                "id": "INFT-AJJKZS",
                "name": "BP Express",
                "S98": "0",
                "S95": "1.629",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "6220",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Schwaz",
                "city": "Buch b. Jenbach",
                "strasse": "Bundesstrasse",
                "date": "22.8.2025",
                "time": "5:38:47"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.3748223,
                    48.2408605
                ]
            },
            "properties": {
                "id": "INFT-AJJL62",
                "name": "BP",
                "S98": "0",
                "S95": "1.589",
                "N": "0",
                "D": "1.629",
                "G": "0",
                "zip": "1200",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Brigittenau",
                "city": "Wien",
                "strasse": "Dresdnerstrasse 8 ",
                "date": "22.8.2025",
                "time": "5:38:59"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.28047,
                    46.65383
                ]
            },
            "properties": {
                "id": "INFT-AJJKRG",
                "name": "AVANTI - Klagenfurt Feldkirchnerstraße 275",
                "S98": "0",
                "S95": "1.444",
                "N": "0",
                "D": "1.444",
                "G": "0",
                "zip": "9020",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Klagenfurt Land",
                "city": "Klagenfurt",
                "strasse": "Feldkirchnerstrasse 275",
                "date": "22.8.2025",
                "time": "5:37:26"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.38747,
                    48.04345
                ]
            },
            "properties": {
                "id": "INFT-AJJKUV",
                "name": "AVANTI - Steyr Sierninger Straße 178",
                "S98": "0",
                "S95": "1.432",
                "N": "0",
                "D": "1.46",
                "G": "0",
                "zip": "4400",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Steyr Land",
                "city": "Steyr",
                "strasse": "Sierninger Strasse 178",
                "date": "22.8.2025",
                "time": "5:38:1"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.4072263,
                    48.8814316
                ]
            },
            "properties": {
                "id": "INFT-AJJKXK",
                "name": "AVIA XPress (unser Service: Luft und Wasser)",
                "S98": "0",
                "S95": "1.574",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "3822",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Waidhofen/Thaya",
                "city": "Karlstein",
                "strasse": "Raabserstraße 8",
                "date": "22.8.2025",
                "time": "5:37:56"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.4967657,
                    48.8432528
                ]
            },
            "properties": {
                "id": "INFT-AJJKXU",
                "name": "Genol Lagerhaus Tankstelle",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.579",
                "G": "0",
                "zip": "3820",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Waidhofen/Thaya",
                "city": "Raabs an der Thaya",
                "strasse": "Bahnstraße 20",
                "date": "22.8.2025",
                "time": "5:37:55"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.8022277,
                    48.7873611
                ]
            },
            "properties": {
                "id": "INFT-AJJKUF",
                "name": "Genol",
                "S98": "0",
                "S95": "1.569",
                "N": "0",
                "D": "1.569",
                "G": "0",
                "zip": "2084",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Horn",
                "city": "Weitersfeld",
                "strasse": "Weitersfeld 265",
                "date": "22.8.2025",
                "time": "5:37:44"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.19135,
                    47.78134
                ]
            },
            "properties": {
                "id": "INFT-AJJL6N",
                "name": "AVANTI - Wiener Neustadt Neunkirchner Straße 118",
                "S98": "0",
                "S95": "1.501",
                "N": "0",
                "D": "1.516",
                "G": "0",
                "zip": "2700",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Wiener Neustadt Land",
                "city": "Wiener Neustadt",
                "strasse": "Neunkirchner Strasse 118",
                "date": "22.8.2025",
                "time": "5:37:37"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.1072403,
                    47.1571884
                ]
            },
            "properties": {
                "id": "INFT-AJJKPW",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.524",
                "N": "0",
                "D": "1.549",
                "G": "0",
                "zip": "5630",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "St. Johann",
                "city": "Bad Hofgastein",
                "strasse": "Weitmoserstr. 1",
                "date": "22.8.2025",
                "time": "5:38:22"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.4421257,
                    48.0782678
                ]
            },
            "properties": {
                "id": "INFT-AJJKKF",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.434",
                "N": "0",
                "D": "1.45",
                "G": "0",
                "zip": "2325",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Wien Umgebung",
                "city": "Himberg",
                "strasse": "Gutenhoferstraße 16",
                "date": "22.8.2025",
                "time": "5:37:39"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.1891661,
                    47.1443074
                ]
            },
            "properties": {
                "id": "INFT-AJJLBM",
                "name": "SPRITKÖNIG",
                "S98": "0",
                "S95": "1.469",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "7551",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Güssing",
                "city": "Bocksdorf",
                "strasse": "Gewerbegebiet 1",
                "date": "22.8.2025",
                "time": "5:37:20"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.7462471,
                    48.2090333
                ]
            },
            "properties": {
                "id": "INFT-AJJL3E",
                "name": "KK Kaindl AVIA",
                "S98": "0",
                "S95": "1.447",
                "N": "0",
                "D": "1.467",
                "G": "0",
                "zip": "4342",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Perg",
                "city": "Baumgartenberg",
                "strasse": "Baumgartenberg 40",
                "date": "22.8.2025",
                "time": "5:38:12"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.6779343,
                    47.2060639
                ]
            },
            "properties": {
                "id": "INFT-AJJKRB",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.452",
                "N": "0",
                "D": "1.457",
                "G": "0",
                "zip": "8753",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Judenburg",
                "city": "Fohnsdorf",
                "strasse": "Judenburger Straße 12",
                "date": "22.8.2025",
                "time": "5:38:36"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.734028263541672,
                    47.15922191686116
                ]
            },
            "properties": {
                "id": "INFT-AJJKR7",
                "name": "Sprint - Landforst Weißkirchen",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.459",
                "G": "0",
                "zip": "8741",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Judenburg",
                "city": "Weißkirchen",
                "strasse": "Fisching 37",
                "date": "22.8.2025",
                "time": "5:38:35"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.16488,
                    47.16113
                ]
            },
            "properties": {
                "id": "INFT-AJJLBJ",
                "name": "AVANTI - Stegersbach Wiener Straße 3",
                "S98": "0",
                "S95": "1.466",
                "N": "0",
                "D": "1.476",
                "G": "0",
                "zip": "7551",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Güssing",
                "city": "Stegersbach",
                "strasse": "Wiener Strasse 3",
                "date": "22.8.2025",
                "time": "5:37:20"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.057685,
                    48.071871
                ]
            },
            "properties": {
                "id": "INFT-AJJL2M",
                "name": "Genol",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.489",
                "G": "0",
                "zip": "3261",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Scheibbs",
                "city": "Wolfpassing",
                "strasse": "Automeile 1",
                "date": "22.8.2025",
                "time": "5:37:54"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.1698067,
                    47.0354119
                ]
            },
            "properties": {
                "id": "INFT-AJJKNH",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.439",
                "N": "0",
                "D": "1.439",
                "G": "0",
                "zip": "8570",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Voitsberg",
                "city": "Voitsberg",
                "strasse": "Umfahrungsstraße 2",
                "date": "22.8.2025",
                "time": "5:38:33"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.31387,
                    46.65337
                ]
            },
            "properties": {
                "id": "INFT-AJJKRF",
                "name": "AVANTI - Klagenfurt St.Veiter Straße 258",
                "S98": "0",
                "S95": "1.439",
                "N": "0",
                "D": "1.444",
                "G": "0",
                "zip": "9020",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Klagenfurt Land",
                "city": "Klagenfurt",
                "strasse": "St.Veiter Strasse 258",
                "date": "22.8.2025",
                "time": "5:37:26"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.4823698,
                    47.2766173
                ]
            },
            "properties": {
                "id": "INFT-AJJL6L",
                "name": "Gutmann ENI Tankstelle",
                "S98": "0",
                "S95": "1.594",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "6060",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Innsbruck Land",
                "city": "Hall ",
                "strasse": "Innsbruckerstraße 90",
                "date": "22.8.2025",
                "time": "5:38:40"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.090068,
                    46.726883
                ]
            },
            "properties": {
                "id": "INFT-AJJL7V",
                "name": "Shell Austria",
                "S98": "0",
                "S95": "1.468",
                "N": "0",
                "D": "1.473",
                "G": "0",
                "zip": "9560",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Feldkirchen",
                "city": "FELDKIRCHEN",
                "strasse": "DR.ARTHUR LEMISCHSTRASSE 16",
                "date": "22.8.2025",
                "time": "5:37:34"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.8709332,
                    47.9991587
                ]
            },
            "properties": {
                "id": "INFT-AJJL9N",
                "name": "LSC Wenzl GmbH",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.49",
                "G": "0",
                "zip": "7111",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Neusiedl am See",
                "city": "Parndorf",
                "strasse": "Neudorferstrasse, Betriebsgebiet 2 (Strassenmeisterei Parndorf)",
                "date": "22.8.2025",
                "time": "5:37:22"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.7083395,
                    47.5160681
                ]
            },
            "properties": {
                "id": "INFT-AJJL23",
                "name": "Egger Wolfgang Internationale Transporte",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.525",
                "G": "0",
                "zip": "6215",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Schwaz",
                "city": "Achenkirch",
                "strasse": "Achenkirch 205",
                "date": "22.8.2025",
                "time": "5:38:46"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.45756,
                    47.27753
                ]
            },
            "properties": {
                "id": "INFT-AJJL6H",
                "name": "AVANTI - Rum Siemensstraße 1",
                "S98": "0",
                "S95": "1.579",
                "N": "0",
                "D": "1.599",
                "G": "0",
                "zip": "6063",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Innsbruck Land",
                "city": "Rum",
                "strasse": "Siemensstrasse 1",
                "date": "22.8.2025",
                "time": "5:38:40"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.276709198951721,
                    48.81313414767661
                ]
            },
            "properties": {
                "id": "INFT-AJJKXJ",
                "name": "Genol Lagerhaus Tankstelle",
                "S98": "0",
                "S95": "1.559",
                "N": "0",
                "D": "1.579",
                "G": "0",
                "zip": "3830",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Waidhofen/Thaya",
                "city": "Waidhofen an der Thaya",
                "strasse": "Raiffeisenstraße 10",
                "date": "22.8.2025",
                "time": "5:37:56"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.1320992,
                    48.0654151
                ]
            },
            "properties": {
                "id": "INFT-AJJL2P",
                "name": "Genol",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.489",
                "G": "0",
                "zip": "3251",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Scheibbs",
                "city": "Purgstall",
                "strasse": "Ellershofstraße 1",
                "date": "22.8.2025",
                "time": "5:37:54"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.320799,
                    48.913686
                ]
            },
            "properties": {
                "id": "INFT-AJJKXL",
                "name": "AVIA XPress (unser Service: Luft und Wasser)",
                "S98": "0",
                "S95": "1.574",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "3843",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Waidhofen/Thaya",
                "city": "Dobersberg",
                "strasse": "Waidhofener Straße 8",
                "date": "22.8.2025",
                "time": "5:37:56"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.85336304,
                    47.49052893
                ]
            },
            "properties": {
                "id": "INFT-AJJKME",
                "name": "www.voegel-trans.at",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.512",
                "G": "0",
                "zip": "6933",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Bregenz",
                "city": "Doren",
                "strasse": "Säge 156",
                "date": "22.8.2025",
                "time": "5:38:48"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.1568711,
                    48.4675476
                ]
            },
            "properties": {
                "id": "INFT-AJJKVP",
                "name": "Genol - Lagerhaus",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "4173",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Rohrbach",
                "city": "St. Veit ",
                "strasse": "Hansbergstrasse 22",
                "date": "22.8.2025",
                "time": "5:38:13"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.53427,
                    48.24347
                ]
            },
            "properties": {
                "id": "INFT-AJJL3B",
                "name": "AVANTI - Mauthausen Machlandstraße 5",
                "S98": "0",
                "S95": "1.412",
                "N": "0",
                "D": "1.439",
                "G": "0",
                "zip": "4310",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Perg",
                "city": "Mauthausen",
                "strasse": "Machlandstrasse 5",
                "date": "22.8.2025",
                "time": "5:38:11"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.8082987,
                    47.1346161
                ]
            },
            "properties": {
                "id": "INFT-AJJLAG",
                "name": "Lagerhaus-Tankstelle 24 h",
                "S98": "0",
                "S95": "1.689",
                "N": "0",
                "D": "1.509",
                "G": "0",
                "zip": "5580",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Tamsweg",
                "city": "Tamsweg",
                "strasse": "Wöltingerstrasse 9a",
                "date": "22.8.2025",
                "time": "5:38:23"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.4536911,
                    47.2778885
                ]
            },
            "properties": {
                "id": "INFT-AJJKQC",
                "name": "Koidl Discounttankstelle",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.56",
                "G": "0",
                "zip": "5730",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Zell am See",
                "city": "Mittersill",
                "strasse": "Gewerbering West 5",
                "date": "22.8.2025",
                "time": "5:38:23"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.6314642,
                    47.0968149
                ]
            },
            "properties": {
                "id": "INFT-AJJLAL",
                "name": "Diesel Prommegger St. Michael",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.539",
                "G": "0",
                "zip": "5582",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Tamsweg",
                "city": "St. Michael",
                "strasse": "Gewerbestraße 649",
                "date": "22.8.2025",
                "time": "5:38:22"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.5037784,
                    47.5086025
                ]
            },
            "properties": {
                "id": "INFT-AJJKW9",
                "name": "Tanke Blaguss",
                "S98": "0",
                "S95": "1.475",
                "N": "0",
                "D": "1.475",
                "G": "0",
                "zip": "7350",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Oberpullendorf",
                "city": "Oberpullendorf",
                "strasse": "Wiener Straße 26",
                "date": "22.8.2025",
                "time": "5:37:24"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.4249757530303,
                    47.2655627212236
                ]
            },
            "properties": {
                "id": "INFT-AJJLAU",
                "name": "Disk TANKAUTOMAT",
                "S98": "0",
                "S95": "1.589",
                "N": "0",
                "D": "1.589",
                "G": "0",
                "zip": "6020",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Innsbruck",
                "city": "Innsbruck",
                "strasse": "Langer Weg 8",
                "date": "22.8.2025",
                "time": "5:38:37"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.8435871,
                    46.5939688
                ]
            },
            "properties": {
                "id": "INFT-AJJL58",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.458",
                "N": "0",
                "D": "1.458",
                "G": "0",
                "zip": "9500",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Villach",
                "city": "Villach",
                "strasse": "Triglavstraße 1",
                "date": "22.8.2025",
                "time": "5:37:27"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    10.0052375,
                    47.123429
                ]
            },
            "properties": {
                "id": "INFT-AJJKQN",
                "name": "Disk TANKAUTOMAT",
                "S98": "0",
                "S95": "1.492",
                "N": "0",
                "D": "1.534",
                "G": "0",
                "zip": "6752",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Bludenz",
                "city": "Dalaas",
                "strasse": "Klostertalerstraße 100",
                "date": "22.8.2025",
                "time": "5:38:48"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.3338164,
                    46.9151971
                ]
            },
            "properties": {
                "id": "INFT-AJJKYM",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.519",
                "N": "0",
                "D": "1.519",
                "G": "0",
                "zip": "9963",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Lienz",
                "city": "St. Jakob",
                "strasse": "Innerrotte 50",
                "date": "22.8.2025",
                "time": "5:38:45"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.9188821,
                    48.0051382
                ]
            },
            "properties": {
                "id": "INFT-AJJKSZ",
                "name": "DICKINGER Agrarhandel GmbH",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "4655",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Gmunden",
                "city": "Vorchdorf",
                "strasse": "Stampfstraße 3",
                "date": "22.8.2025",
                "time": "5:38:6"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.2361085,
                    46.8271642
                ]
            },
            "properties": {
                "id": "INFT-AJJKWL",
                "name": "Diesel-Klösch",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.438",
                "G": "0",
                "zip": "8530",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Deutschlandsberg",
                "city": "Deutschlandsberg",
                "strasse": "Mostbauerstrasse 3",
                "date": "22.8.2025",
                "time": "5:38:25"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.600584649999995,
                    48.3577548
                ]
            },
            "properties": {
                "id": "INFT-AJJL69",
                "name": "Brenner",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.489",
                "G": "0",
                "zip": "2213",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Mistelbach",
                "city": "Bockfließ",
                "strasse": "Wagramer Straße 16",
                "date": "22.8.2025",
                "time": "5:37:49"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.61341,
                    46.65757
                ]
            },
            "properties": {
                "id": "INFT-AJJLC2",
                "name": "Rudolf GmbH",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.454",
                "G": "0",
                "zip": "9100",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Völkermarkt",
                "city": "Voelkermarkt",
                "strasse": "Klagenfurter Strasse 46",
                "date": "22.8.2025",
                "time": "5:37:32"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.089773,
                    46.726235
                ]
            },
            "properties": {
                "id": "INFT-AJJL7P",
                "name": "SOCAR Feldkirchen",
                "S98": "0",
                "S95": "1.458",
                "N": "0",
                "D": "1.463",
                "G": "0",
                "zip": "9560",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Feldkirchen",
                "city": "Feldkirchen",
                "strasse": "Doktor-Arthur-Lemisch-Straße 7",
                "date": "22.8.2025",
                "time": "5:37:34"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.0553276,
                    47.0239873
                ]
            },
            "properties": {
                "id": "INFT-AJJKNE",
                "name": "SB DISKONT plus",
                "S98": "0",
                "S95": "1.428",
                "N": "0",
                "D": "1.418",
                "G": "0",
                "zip": "8583",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Voitsberg",
                "city": "Edelschrott",
                "strasse": "Packerstrasse 50",
                "date": "22.8.2025",
                "time": "5:38:33"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.6948144,
                    48.3976496
                ]
            },
            "properties": {
                "id": "INFT-AJJKX4",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.442",
                "N": "0",
                "D": "1.458",
                "G": "0",
                "zip": "2243",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Gänserndorf",
                "city": "Matzen",
                "strasse": "Reyerdorfer Straße 4a",
                "date": "22.8.2025",
                "time": "5:37:40"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.0346315,
                    48.1670468
                ]
            },
            "properties": {
                "id": "INFT-AJJL3N",
                "name": "AVIA Xpress",
                "S98": "0",
                "S95": "1.487",
                "N": "0",
                "D": "1.49",
                "G": "0",
                "zip": "4600",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Wels",
                "city": "Wels",
                "strasse": "Reitschulgasse 9",
                "date": "22.8.2025",
                "time": "5:38:2"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.44392,
                    48.43865
                ]
            },
            "properties": {
                "id": "INFT-AJJKXX",
                "name": "AVANTI - Sankt Florian/Inn Bundesstraße 129",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.469",
                "G": "0",
                "zip": "4780",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Schärding",
                "city": "Sankt Florian/Inn",
                "strasse": "Bundesstrasse 129",
                "date": "22.8.2025",
                "time": "5:38:14"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.37077,
                    46.63785
                ]
            },
            "properties": {
                "id": "INFT-AJJKRK",
                "name": "AVANTI - Klagenfurt Görtschitztal Straße 22",
                "S98": "0",
                "S95": "1.438",
                "N": "0",
                "D": "1.443",
                "G": "0",
                "zip": "9020",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Klagenfurt Land",
                "city": "Klagenfurt",
                "strasse": "Görtschitztal Strasse 22",
                "date": "22.8.2025",
                "time": "5:37:26"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.009414,
                    48.36248
                ]
            },
            "properties": {
                "id": "INFT-AJJL7F",
                "name": "GENOL-LH EFERDING-OÖ. MITTE eGen",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "4082",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Eferding",
                "city": "ASCHACH AN DER DONAU",
                "strasse": "BAHNHOFSTRASSE 25",
                "date": "22.8.2025",
                "time": "5:38:4"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.9208267,
                    48.5293754
                ]
            },
            "properties": {
                "id": "INFT-AJJL8P",
                "name": "Lagerhaus - Genol",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.494",
                "G": "0",
                "zip": "3710",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Hollabrunn",
                "city": "Ziersdorf",
                "strasse": "Hornerstrasse  43",
                "date": "22.8.2025",
                "time": "5:37:43"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.9296436,
                    47.7351682
                ]
            },
            "properties": {
                "id": "INFT-AJJL9K",
                "name": "Lagerhaus-Genol",
                "S98": "0",
                "S95": "1.474",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "7151",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Neusiedl am See",
                "city": "Wallern",
                "strasse": "Bahnstraße 115",
                "date": "22.8.2025",
                "time": "5:37:23"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.8486015,
                    48.466849
                ]
            },
            "properties": {
                "id": "INFT-AJJKX2",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.442",
                "N": "0",
                "D": "1.458",
                "G": "0",
                "zip": "2263",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Gänserndorf",
                "city": "Dürnkrut",
                "strasse": "Bernsteinstraße 48",
                "date": "22.8.2025",
                "time": "5:37:40"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.0887587,
                    47.3789195
                ]
            },
            "properties": {
                "id": "INFT-AJJKNW",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.442",
                "N": "0",
                "D": "1.447",
                "G": "0",
                "zip": "8700",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Leoben",
                "city": "Leoben",
                "strasse": "Zeltenschlagstraße 2",
                "date": "22.8.2025",
                "time": "5:38:29"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.0373365,
                    47.2917213
                ]
            },
            "properties": {
                "id": "INFT-AJJKLY",
                "name": "Disk TANKAUTOMAT",
                "S98": "0",
                "S95": "1.609",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "6421",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Imst",
                "city": "Rietz",
                "strasse": "Bundesstraße 32",
                "date": "22.8.2025",
                "time": "5:38:39"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.6323395,
                    48.8257786
                ]
            },
            "properties": {
                "id": "INFT-AJJKUL",
                "name": "Genol",
                "S98": "0",
                "S95": "1.569",
                "N": "0",
                "D": "1.569",
                "G": "0",
                "zip": "2094",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Waidhofen/Thaya",
                "city": "Zissersdorf",
                "strasse": "Zissersdorf 96",
                "date": "22.8.2025",
                "time": "5:37:45"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.2523853,
                    46.6283556
                ]
            },
            "properties": {
                "id": "INFT-AJJKS9",
                "name": "eni/Zankl GmbH",
                "S98": "0",
                "S95": "1.599",
                "N": "0",
                "D": "1.619",
                "G": "0",
                "zip": "9631",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Hermagor",
                "city": "Jenig",
                "strasse": "Jenig 7",
                "date": "22.8.2025",
                "time": "5:37:28"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.191680598162456,
                    47.10981058881867
                ]
            },
            "properties": {
                "id": "INFT-AJJKYE",
                "name": "Sprint - Landforst Murau",
                "S98": "0",
                "S95": "1.517",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "8850",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Murau",
                "city": "Murau",
                "strasse": "Römersiedlung 61",
                "date": "22.8.2025",
                "time": "5:38:32"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.052246,
                    48.4412627
                ]
            },
            "properties": {
                "id": "INFT-AJJKVN",
                "name": "Genol - Lagerhaus",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "4174",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Rohrbach",
                "city": "Niederwaldkirchen",
                "strasse": "Drautendorf 54",
                "date": "22.8.2025",
                "time": "5:38:13"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.043058,
                    48.165209
                ]
            },
            "properties": {
                "id": "INFT-AJJL3P",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.484",
                "N": "0",
                "D": "1.491",
                "G": "0",
                "zip": "4600",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Wels",
                "city": "Wels",
                "strasse": "Linzerstraße 92a",
                "date": "22.8.2025",
                "time": "5:38:2"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.3179707,
                    46.8242704
                ]
            },
            "properties": {
                "id": "INFT-AJJKWK",
                "name": "Treibstoffparadies",
                "S98": "0",
                "S95": "1.459",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "8522",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Leibnitz",
                "city": "Gr. St. Florian",
                "strasse": "Grazerstraße 2",
                "date": "22.8.2025",
                "time": "5:38:26"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.1753462,
                    48.7566554
                ]
            },
            "properties": {
                "id": "INFT-AJJKXG",
                "name": "Genol",
                "S98": "0",
                "S95": "1.559",
                "N": "0",
                "D": "1.579",
                "G": "0",
                "zip": "3902",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Waidhofen/Thaya",
                "city": "Vitis",
                "strasse": "Raiffeisenstraße 19",
                "date": "22.8.2025",
                "time": "5:37:56"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.189367,
                    47.3343734
                ]
            },
            "properties": {
                "id": "INFT-AJJKPX",
                "name": " LMEnergy Express",
                "S98": "0",
                "S95": "1.519",
                "N": "0",
                "D": "1.544",
                "G": "0",
                "zip": "5600",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "St. Johann",
                "city": "St. Johann",
                "strasse": "Bundesstraße 2",
                "date": "22.8.2025",
                "time": "5:38:22"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.32173,
                    48.19039
                ]
            },
            "properties": {
                "id": "INFT-AJJKWX",
                "name": "Shell Austria",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "1150",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Rudolfsheim",
                "city": "WIEN",
                "strasse": "LINZER STR 2A",
                "date": "22.8.2025",
                "time": "5:38:58"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.3201416,
                    47.0781445
                ]
            },
            "properties": {
                "id": "INFT-AJJLBQ",
                "name": "Landestankstelle Güssing Partner Luisser",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "7540",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Güssing",
                "city": "Güssing ",
                "strasse": "Wiener Straße 62",
                "date": "22.8.2025",
                "time": "5:37:20"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.7864336,
                    48.5171956
                ]
            },
            "properties": {
                "id": "INFT-AJJL96",
                "name": "Lagerhaus - Genol",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.494",
                "G": "0",
                "zip": "3473",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Hollabrunn",
                "city": "Mühlbach am Manhartsberg",
                "strasse": "Mühlbach 93",
                "date": "22.8.2025",
                "time": "5:37:43"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.9235613,
                    47.9056277
                ]
            },
            "properties": {
                "id": "INFT-AJJL9M",
                "name": "LSC Wenzl GmbH",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.49",
                "G": "0",
                "zip": "7122",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Neusiedl am See",
                "city": "Gols",
                "strasse": "Hochäcker 7",
                "date": "22.8.2025",
                "time": "5:37:22"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.6922177,
                    48.4039189
                ]
            },
            "properties": {
                "id": "INFT-AJJLB3",
                "name": "SB-Tankstelle Schmied im Wald",
                "S98": "0",
                "S95": "1.436",
                "N": "0",
                "D": "1.436",
                "G": "0",
                "zip": "4723",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Grieskirchen",
                "city": "Natternbach",
                "strasse": "Gschaid 8",
                "date": "22.8.2025",
                "time": "5:38:8"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.29075,
                    47.98609
                ]
            },
            "properties": {
                "id": "INFT-AJJLA4",
                "name": "AVANTI - Oeynhausen Ebreichsdorfer Straße 28",
                "S98": "0",
                "S95": "1.449",
                "N": "0",
                "D": "1.464",
                "G": "0",
                "zip": "2512",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Baden",
                "city": "Oeynhausen",
                "strasse": "Ebreichsdorfer Strasse 28",
                "date": "22.8.2025",
                "time": "5:37:38"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.9573163,
                    47.6727758
                ]
            },
            "properties": {
                "id": "INFT-AJJKKZ",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.504",
                "N": "0",
                "D": "1.524",
                "G": "0",
                "zip": "2640",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Neunkirchen",
                "city": "Gloggnitz",
                "strasse": "Wiener Straße 106",
                "date": "22.8.2025",
                "time": "5:37:51"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.711388,
                    48.3350589
                ]
            },
            "properties": {
                "id": "INFT-AJJKWZ",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.442",
                "N": "0",
                "D": "1.458",
                "G": "0",
                "zip": "2230",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Gänserndorf",
                "city": "Gänserndorf",
                "strasse": "Wienerstraße 14",
                "date": "22.8.2025",
                "time": "5:37:40"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.72846,
                    46.70256
                ]
            },
            "properties": {
                "id": "INFT-AJJLBS",
                "name": "AVANTI - Griffen",
                "S98": "0",
                "S95": "1.461",
                "N": "0",
                "D": "1.464",
                "G": "0",
                "zip": "9112",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Völkermarkt",
                "city": "Griffen",
                "strasse": " ",
                "date": "22.8.2025",
                "time": "5:37:32"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.3835,
                    48.1365
                ]
            },
            "properties": {
                "id": "INFT-AJJKYS",
                "name": "OIL! Tankstelle",
                "S98": "0",
                "S95": "1.448",
                "N": "0",
                "D": "1.459",
                "G": "0",
                "zip": "1100",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Favoriten",
                "city": "Wien",
                "strasse": "Himberger Straße 50",
                "date": "22.8.2025",
                "time": "5:38:53"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.7281924,
                    48.1351055
                ]
            },
            "properties": {
                "id": "INFT-AJJLB4",
                "name": "Aspöck - Freie Tankstelle",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.485",
                "G": "0",
                "zip": "4673",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Grieskirchen",
                "city": "Gaspoltshofen",
                "strasse": "Obeltsham 29",
                "date": "22.8.2025",
                "time": "5:38:7"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.4324706,
                    47.5591137
                ]
            },
            "properties": {
                "id": "INFT-AJJKW8",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.474",
                "N": "0",
                "D": "1.474",
                "G": "0",
                "zip": "7341",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Oberpullendorf",
                "city": "Markt Sankt Martin",
                "strasse": "Hauptstraße 78",
                "date": "22.8.2025",
                "time": "5:37:24"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.992052,
                    47.221419
                ]
            },
            "properties": {
                "id": "INFT-AJJKQ8",
                "name": "Lagerhaus-Tankstelle 24 h",
                "S98": "0",
                "S95": "1.539",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "5661",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Zell am See",
                "city": "Rauris",
                "strasse": "Oberer Markt 15",
                "date": "22.8.2025",
                "time": "5:38:23"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.33505,
                    48.18452
                ]
            },
            "properties": {
                "id": "INFT-AJJL5Q",
                "name": "boesch energy, turmöl",
                "S98": "0",
                "S95": "1.452",
                "N": "0",
                "D": "1.452",
                "G": "0",
                "zip": "1120",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Meidling",
                "city": "Wien",
                "strasse": "Schoenbrunner Strasse 213",
                "date": "22.8.2025",
                "time": "5:38:55"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.9982722,
                    48.7693868
                ]
            },
            "properties": {
                "id": "INFT-AJJLAX",
                "name": "AVIA XPress (unser Service: Luft und Wasser)",
                "S98": "0",
                "S95": "1.559",
                "N": "0",
                "D": "1.579",
                "G": "0",
                "zip": "3950",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Gmünd",
                "city": "Gmünd",
                "strasse": "Schremser Straße 50",
                "date": "22.8.2025",
                "time": "5:37:42"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.347336,
                    48.172218
                ]
            },
            "properties": {
                "id": "INFT-AJJL3V",
                "name": "AVIA Xpress (Automaten-Tankstelle)",
                "S98": "0",
                "S95": "1.474",
                "N": "0",
                "D": "1.484",
                "G": "0",
                "zip": "4931",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Ried",
                "city": "Mettmach",
                "strasse": "Rieder Straße 17",
                "date": "22.8.2025",
                "time": "5:38:13"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.2069591,
                    46.7601246
                ]
            },
            "properties": {
                "id": "INFT-AJJKWM",
                "name": "SOCAR Schwanberg",
                "S98": "0",
                "S95": "1.459",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "8541",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Deutschlandsberg",
                "city": "Schwanberg",
                "strasse": "Deutschlandsberger Straße 6",
                "date": "22.8.2025",
                "time": "5:38:26"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.37405,
                    48.2997
                ]
            },
            "properties": {
                "id": "INFT-AJJKSW",
                "name": "AVANTI - Langenzersdorf Wiener Straße 176-196",
                "S98": "0",
                "S95": "1.445",
                "N": "0",
                "D": "1.462",
                "G": "0",
                "zip": "2103",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Korneuburg",
                "city": "Langenzersdorf",
                "strasse": "Wiener Strasse 176-196",
                "date": "22.8.2025",
                "time": "5:37:45"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.94180584,
                    48.33325905
                ]
            },
            "properties": {
                "id": "INFT-AJJKTH",
                "name": "Schildecker-DISKONT",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.439",
                "G": "0",
                "zip": "3435",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Tulln",
                "city": "Pischelsdorf",
                "strasse": "Industriegelände Objekt 2",
                "date": "22.8.2025",
                "time": "5:37:54"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.9048504,
                    47.4491533
                ]
            },
            "properties": {
                "id": "INFT-AJJKMH",
                "name": "SCHWÄRZLER",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.539",
                "G": "0",
                "zip": "6951",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Bregenz",
                "city": "Lingenau",
                "strasse": "Zeihenbühl 422",
                "date": "22.8.2025",
                "time": "5:38:49"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.971261978149414,
                    48.254009723698374
                ]
            },
            "properties": {
                "id": "INFT-AJJL79",
                "name": "Land-lebt-auf",
                "S98": "0",
                "S95": "1.499",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "4075",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Eferding",
                "city": "Breitenaich",
                "strasse": "Breitenaich 100",
                "date": "22.8.2025",
                "time": "5:38:5"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.8807031,
                    47.4370676
                ]
            },
            "properties": {
                "id": "INFT-AJJL25",
                "name": "AP Brixlegg",
                "S98": "0",
                "S95": "1.469",
                "N": "0",
                "D": "1.469",
                "G": "0",
                "zip": "6230",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Kufstein",
                "city": "Brixlegg",
                "strasse": "Niederfeldweg 9a",
                "date": "22.8.2025",
                "time": "5:38:42"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.907774,
                    48.6786932
                ]
            },
            "properties": {
                "id": "INFT-AJJKVQ",
                "name": "LKW - Genol Lagerhaus",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "4161",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Rohrbach",
                "city": "Ulrichsberg",
                "strasse": "Dreisesselbergstrasse 19",
                "date": "22.8.2025",
                "time": "5:38:13"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.9091111,
                    47.7887601
                ]
            },
            "properties": {
                "id": "INFT-AJJKL2",
                "name": "M3 Puchberg ",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.519",
                "G": "0",
                "zip": "2734",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Neunkirchen",
                "city": "Puchberg am Schneeberg",
                "strasse": "Schneeberg 29",
                "date": "22.8.2025",
                "time": "5:37:51"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.207326,
                    46.930587
                ]
            },
            "properties": {
                "id": "INFT-AJJKRZ",
                "name": "Wulz",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "9821",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Spittal",
                "city": "Obervellach",
                "strasse": "Obervellach",
                "date": "22.8.2025",
                "time": "5:37:30"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.139662,
                    48.706617
                ]
            },
            "properties": {
                "id": "INFT-AJJL8L",
                "name": "U2 Hadres",
                "S98": "0",
                "S95": "1.518",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "2061",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Hollabrunn",
                "city": "Hadres",
                "strasse": "Bundesstrasse 41",
                "date": "22.8.2025",
                "time": "5:37:44"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.8195391,
                    48.7363868
                ]
            },
            "properties": {
                "id": "INFT-AJJKVR",
                "name": "LKW - Tankstelle",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "4164",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Rohrbach",
                "city": "Schwarzenberg",
                "strasse": "Schwarzenberg 168",
                "date": "22.8.2025",
                "time": "5:38:14"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.334813,
                    48.20462
                ]
            },
            "properties": {
                "id": "INFT-AJJL7Y",
                "name": "NNB BRUNNENTANKSTELLE",
                "S98": "0",
                "S95": "1.538",
                "N": "0",
                "D": "1.549",
                "G": "0",
                "zip": "1160",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Ottakring",
                "city": "WIEN",
                "strasse": "Brunnengasse 4",
                "date": "22.8.2025",
                "time": "5:38:58"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    10.9373833,
                    47.2687587
                ]
            },
            "properties": {
                "id": "INFT-AJJKM4",
                "name": "Disk TANKAUTOMAT",
                "S98": "0",
                "S95": "1.589",
                "N": "0",
                "D": "1.589",
                "G": "0",
                "zip": "6424",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Innsbruck Land",
                "city": "Silz",
                "strasse": "Tirolerstraße 14",
                "date": "22.8.2025",
                "time": "5:38:39"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.4911117,
                    47.2851698
                ]
            },
            "properties": {
                "id": "INFT-AJJKQ7",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.544",
                "N": "0",
                "D": "1.564",
                "G": "0",
                "zip": "5730",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Zell am See",
                "city": "Mittersill",
                "strasse": "Zellerstraße 26",
                "date": "22.8.2025",
                "time": "5:38:24"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.092691,
                    47.373778
                ]
            },
            "properties": {
                "id": "INFT-AJJKTW",
                "name": "Rekord-Tankstelle",
                "S98": "0",
                "S95": "1.478",
                "N": "0",
                "D": "1.478",
                "G": "0",
                "zip": "7423",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Oberwart",
                "city": "Pinkafeld",
                "strasse": "Wirtschaftspark-West 9",
                "date": "22.8.2025",
                "time": "5:37:25"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.4024476,
                    46.800983
                ]
            },
            "properties": {
                "id": "INFT-AJJKRU",
                "name": "Steindorfer Mail",
                "S98": "0",
                "S95": "1.499",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "9300",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "St. Veit",
                "city": "Sankt Veit an der Glan",
                "strasse": "Mail Süd 1-5",
                "date": "22.8.2025",
                "time": "5:37:30"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.44904,
                    47.54417
                ]
            },
            "properties": {
                "id": "INFT-AJJL2B",
                "name": "AVANTI - Kirchdorf in Tirol Innsbrucker Straße 51",
                "S98": "0",
                "S95": "1.559",
                "N": "0",
                "D": "1.549",
                "G": "0",
                "zip": "6383",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Kitzbühel",
                "city": "Kirchdorf in Tirol",
                "strasse": "Innsbrucker Strasse 51",
                "date": "22.8.2025",
                "time": "5:38:41"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    17.0054015,
                    47.9839221
                ]
            },
            "properties": {
                "id": "INFT-AJJL9R",
                "name": "Pamer GmbH",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.489",
                "G": "0",
                "zip": "2424",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Neusiedl am See",
                "city": "Zurndorf",
                "strasse": "Wirtschaftsweg 2",
                "date": "22.8.2025",
                "time": "5:37:22"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.07613,
                    48.28792
                ]
            },
            "properties": {
                "id": "INFT-AJJL77",
                "name": "AVANTI - Alkoven Strass 16",
                "S98": "0",
                "S95": "1.494",
                "N": "0",
                "D": "1.484",
                "G": "0",
                "zip": "4072",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Eferding",
                "city": "Alkoven",
                "strasse": "Strass 16",
                "date": "22.8.2025",
                "time": "5:38:5"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.4044,
                    47.6481
                ]
            },
            "properties": {
                "id": "INFT-AJJL2D",
                "name": "BELLINGER, freie Tankstelle",
                "S98": "0",
                "S95": "1.539",
                "N": "0",
                "D": "1.549",
                "G": "0",
                "zip": "6385",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Kitzbühel",
                "city": "Schwendt bei Kössen",
                "strasse": "Unterschwendt 46",
                "date": "22.8.2025",
                "time": "5:38:41"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.8960945,
                    47.7917642
                ]
            },
            "properties": {
                "id": "INFT-AJJKL3",
                "name": "Paulischin",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.519",
                "G": "0",
                "zip": "2734",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Neunkirchen",
                "city": "Puchberg",
                "strasse": " Unternbergweg 1",
                "date": "22.8.2025",
                "time": "5:37:51"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.970329,
                    48.762337
                ]
            },
            "properties": {
                "id": "INFT-AJJLAZ",
                "name": "Disk TANKAUTOMAT",
                "S98": "0",
                "S95": "1.559",
                "N": "0",
                "D": "1.579",
                "G": "0",
                "zip": "3950",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Gmünd",
                "city": "Gmünd",
                "strasse": "Weitraer Straße 109",
                "date": "22.8.2025",
                "time": "5:37:42"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.512151,
                    47.712072
                ]
            },
            "properties": {
                "id": "INFT-AJJL48",
                "name": "Diskont-Tankstelle",
                "S98": "0",
                "S95": "1.479",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "7022",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Mattersburg",
                "city": "Schattendorf",
                "strasse": "Hauptstraße 121",
                "date": "22.8.2025",
                "time": "5:37:22"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.0143393,
                    48.3021109
                ]
            },
            "properties": {
                "id": "INFT-AJJL7A",
                "name": "GENOL-LH EFERDING-OÖ. MITTE eGen",
                "S98": "0",
                "S95": "1.469",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "4070",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Eferding",
                "city": "EFERDING",
                "strasse": "BAHNHOFSTRASSE 51-55",
                "date": "22.8.2025",
                "time": "5:38:4"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.8918456,
                    48.6652995
                ]
            },
            "properties": {
                "id": "INFT-AJJKUG",
                "name": "Genol",
                "S98": "0",
                "S95": "1.569",
                "N": "0",
                "D": "1.569",
                "G": "0",
                "zip": "3743",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Horn",
                "city": "Röschitz",
                "strasse": "Pulkauerstraße 1",
                "date": "22.8.2025",
                "time": "5:37:45"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.408926010131836,
                    48.788983283912714
                ]
            },
            "properties": {
                "id": "INFT-AJJKXS",
                "name": "Genol Lagerhaus Tankstelle",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.579",
                "G": "0",
                "zip": "3812",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Waidhofen/Thaya",
                "city": "Groß Siegharts",
                "strasse": "Silostraße 5",
                "date": "22.8.2025",
                "time": "5:37:55"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.874917,
                    47.9276196
                ]
            },
            "properties": {
                "id": "INFT-AJJL9A",
                "name": "Lagerhaus-Genol",
                "S98": "0",
                "S95": "1.474",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "7121",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Neusiedl am See",
                "city": "Weiden",
                "strasse": "Triftstraße 24",
                "date": "22.8.2025",
                "time": "5:37:22"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.8530872,
                    46.8580653
                ]
            },
            "properties": {
                "id": "INFT-AJJKP5",
                "name": "Treibstoffparadies ",
                "S98": "0",
                "S95": "1.479",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "9413",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Wolfsberg",
                "city": "St. Gertraud",
                "strasse": "Zellach 6b",
                "date": "22.8.2025",
                "time": "5:37:33"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.5336044,
                    47.8328353
                ]
            },
            "properties": {
                "id": "INFT-AJJKKU",
                "name": "Tanke Blaguss",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.475",
                "G": "0",
                "zip": "7000",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Eisenstadt",
                "city": "Eisenstadt",
                "strasse": "Industriestraße",
                "date": "22.8.2025",
                "time": "5:37:19"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.1369005,
                    47.0547254
                ]
            },
            "properties": {
                "id": "INFT-AJJKNF",
                "name": "SB DISKONT plus",
                "S98": "0",
                "S95": "1.428",
                "N": "0",
                "D": "1.418",
                "G": "0",
                "zip": "8570",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Voitsberg",
                "city": "Bärnbach",
                "strasse": "Packerstrasse 4",
                "date": "22.8.2025",
                "time": "5:38:33"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.0641858,
                    47.7313262
                ]
            },
            "properties": {
                "id": "INFT-AJJKLE",
                "name": "LMEnergy Express",
                "S98": "0",
                "S95": "1.461",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "5081",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Salzburg Umgebung",
                "city": "Anif",
                "strasse": "Salzachtalbundesstraße 111",
                "date": "22.8.2025",
                "time": "5:38:20"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.9760281,
                    47.8702538
                ]
            },
            "properties": {
                "id": "INFT-AJJL9B",
                "name": "Lagerhaus-Genol",
                "S98": "0",
                "S95": "1.474",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "7131",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Neusiedl am See",
                "city": "Halbturn",
                "strasse": "Andauerstraße 1",
                "date": "22.8.2025",
                "time": "5:37:23"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.0209109,
                    48.3081944
                ]
            },
            "properties": {
                "id": "INFT-AJJL7C",
                "name": "PINK - so pink, so clever",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.489",
                "G": "0",
                "zip": "4070",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Eferding",
                "city": "Eferding",
                "strasse": "Schmiedstraße 29",
                "date": "22.8.2025",
                "time": "5:38:3"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.3882226,
                    47.4964984
                ]
            },
            "properties": {
                "id": "INFT-AJJL2C",
                "name": "Gutmann ENI Tankstelle + TANKAUTOMAT",
                "S98": "0",
                "S95": "1.548",
                "N": "0",
                "D": "1.538",
                "G": "0",
                "zip": "6372",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Kitzbühel",
                "city": "Oberndorf",
                "strasse": "Bahnhofstraße 11",
                "date": "22.8.2025",
                "time": "5:38:41"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.219604,
                    47.887392
                ]
            },
            "properties": {
                "id": "INFT-AJJKPH",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.483",
                "N": "0",
                "D": "1.476",
                "G": "0",
                "zip": "2751",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Wiener Neustadt Land",
                "city": "Matzendorf-Hölles",
                "strasse": "Badenerstraße 51",
                "date": "22.8.2025",
                "time": "5:37:57"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.732715,
                    48.222328
                ]
            },
            "properties": {
                "id": "INFT-AJJLB8",
                "name": "Easy Tank",
                "S98": "0",
                "S95": "1.478",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "4716",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Grieskirchen",
                "city": "Hofkirchen/Tr.",
                "strasse": "Strötting 1",
                "date": "22.8.2025",
                "time": "5:38:8"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.0497956,
                    47.8157985
                ]
            },
            "properties": {
                "id": "INFT-AJJL47",
                "name": "Wildenhofer Diesel Tankstelle",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.458",
                "G": "0",
                "zip": "5020",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Salzburg Umgebung",
                "city": "Salzburg",
                "strasse": "Gniglerstraße 5-7",
                "date": "22.8.2025",
                "time": "5:38:18"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.9408497,
                    48.260292
                ]
            },
            "properties": {
                "id": "INFT-AJJL75",
                "name": "PINK - so pink, so clever",
                "S98": "0",
                "S95": "1.493",
                "N": "0",
                "D": "1.494",
                "G": "0",
                "zip": "4076",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Eferding",
                "city": "St. Marienkirchen",
                "strasse": "Freundorf 2",
                "date": "22.8.2025",
                "time": "5:38:4"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.181366099756072,
                    47.18660800475122
                ]
            },
            "properties": {
                "id": "INFT-AJJKYD",
                "name": "Sprint - Landforst Kammersberg",
                "S98": "0",
                "S95": "1.517",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "8843",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Murau",
                "city": "St.Peter am Kammersberg",
                "strasse": "St.Peter am Kammersberg 181",
                "date": "22.8.2025",
                "time": "5:38:32"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.642724,
                    48.189051
                ]
            },
            "properties": {
                "id": "INFT-AJJLB6",
                "name": "DISKONT Grausgruber",
                "S98": "0",
                "S95": "1.459",
                "N": "0",
                "D": "1.469",
                "G": "0",
                "zip": "4680",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Grieskirchen",
                "city": "Haag/Hausruck",
                "strasse": "Starhemberg 15",
                "date": "22.8.2025",
                "time": "5:38:8"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.316303,
                    48.112274
                ]
            },
            "properties": {
                "id": "INFT-AJJKX7",
                "name": "SPRITKÖNIG SCS",
                "S98": "0",
                "S95": "1.429",
                "N": "0",
                "D": "1.439",
                "G": "0",
                "zip": "2334",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Mödling",
                "city": "Vösendorf",
                "strasse": "Westring Area 1",
                "date": "22.8.2025",
                "time": "5:37:50"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.010318,
                    48.363754
                ]
            },
            "properties": {
                "id": "INFT-AJJL76",
                "name": "PINK - so pink, so clever",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "4082",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Eferding",
                "city": "Aschach an der Donau",
                "strasse": "Bahnhofstrasse 26",
                "date": "22.8.2025",
                "time": "5:38:4"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.6962295,
                    46.7983963
                ]
            },
            "properties": {
                "id": "INFT-AJJKS2",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.473",
                "N": "0",
                "D": "1.473",
                "G": "0",
                "zip": "9545",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Spittal",
                "city": "Radenthein",
                "strasse": "Millstätterstraße 42a",
                "date": "22.8.2025",
                "time": "5:37:30"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    10.75935,
                    47.21094
                ]
            },
            "properties": {
                "id": "INFT-AJJKM2",
                "name": "AVANTI - Arzl im Pitztal Dorfstraße 16",
                "S98": "0",
                "S95": "1.594",
                "N": "0",
                "D": "1.594",
                "G": "0",
                "zip": "6471",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Imst",
                "city": "Arzl im Pitztal",
                "strasse": "Dorfstrasse 16",
                "date": "22.8.2025",
                "time": "5:38:39"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.741538,
                    48.438084
                ]
            },
            "properties": {
                "id": "INFT-AJJKUZ",
                "name": "Hoftankstelle - Stöbermühle",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "3492",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Krems Land",
                "city": "Etsdorf",
                "strasse": "Mühlweg 1",
                "date": "22.8.2025",
                "time": "5:37:46"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.314299,
                    48.1893108
                ]
            },
            "properties": {
                "id": "INFT-AJJKWN",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.453",
                "N": "0",
                "D": "1.464",
                "G": "0",
                "zip": "1140",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Penzing",
                "city": "Wien",
                "strasse": "Schlossallee 2",
                "date": "22.8.2025",
                "time": "5:38:57"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.7383998,
                    47.1314124
                ]
            },
            "properties": {
                "id": "INFT-AJJKR8",
                "name": "Land lebt auf !",
                "S98": "0",
                "S95": "1.45",
                "N": "0",
                "D": "1.46",
                "G": "0",
                "zip": "8741",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Judenburg",
                "city": "Eppenstein",
                "strasse": "Eppenstein 1",
                "date": "22.8.2025",
                "time": "5:38:35"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.194403,
                    48.75864
                ]
            },
            "properties": {
                "id": "INFT-AJJKXF",
                "name": "AVIA XPress (unser Service: Luft und Wasser)",
                "S98": "0",
                "S95": "1.559",
                "N": "0",
                "D": "1.579",
                "G": "0",
                "zip": "3902",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Waidhofen/Thaya",
                "city": "Vitis",
                "strasse": "Europastraße",
                "date": "22.8.2025",
                "time": "5:37:56"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.410579,
                    48.164827
                ]
            },
            "properties": {
                "id": "INFT-AJJKYX",
                "name": "IQ Tankstelle",
                "S98": "0",
                "S95": "1.426",
                "N": "0",
                "D": "1.446",
                "G": "0",
                "zip": "1110",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Simmering",
                "city": "Wien",
                "strasse": "Gadnergasse 12",
                "date": "22.8.2025",
                "time": "5:38:54"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.00062,
                    47.938634
                ]
            },
            "properties": {
                "id": "INFT-AJJL7H",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.484",
                "N": "0",
                "D": "1.494",
                "G": "0",
                "zip": "4643",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Kirchdorf",
                "city": "Pettenbach",
                "strasse": "Scharnsteiner Straße 38",
                "date": "22.8.2025",
                "time": "5:38:9"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.99141,
                    47.46366
                ]
            },
            "properties": {
                "id": "INFT-AJJKP3",
                "name": "Rumpold",
                "S98": "0",
                "S95": "1.442",
                "N": "0",
                "D": "1.447",
                "G": "0",
                "zip": "8794",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Leoben",
                "city": "Vordernberg",
                "strasse": "Gewerbepark 9",
                "date": "22.8.2025",
                "time": "5:38:29"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.6285154,
                    47.323657
                ]
            },
            "properties": {
                "id": "INFT-AJJKW3",
                "name": "Loacker Tours GmbH (Diesel + Super95)",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.496",
                "G": "0",
                "zip": "6842",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Feldkirch",
                "city": "Koblach",
                "strasse": "Bundesstraße 17",
                "date": "22.8.2025",
                "time": "5:38:51"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.29472,
                    48.24886
                ]
            },
            "properties": {
                "id": "INFT-AJJKLX",
                "name": "AVANTI - Linz Franzosenhausweg 1",
                "S98": "0",
                "S95": "1.454",
                "N": "0",
                "D": "1.474",
                "G": "0",
                "zip": "4020",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Linz Land",
                "city": "Linz",
                "strasse": "Franzosenhausweg 1",
                "date": "22.8.2025",
                "time": "5:37:59"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.8289382,
                    48.3817953
                ]
            },
            "properties": {
                "id": "INFT-AJJKWY",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.442",
                "N": "0",
                "D": "1.458",
                "G": "0",
                "zip": "2261",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Gänserndorf",
                "city": "Angern an der March",
                "strasse": "Bahnstraße 30",
                "date": "22.8.2025",
                "time": "5:37:40"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.4331036,
                    47.5381315
                ]
            },
            "properties": {
                "id": "INFT-AJJKWC",
                "name": "Tanken an der S31",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.475",
                "G": "0",
                "zip": "7343",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Oberpullendorf",
                "city": "Neutal",
                "strasse": "Siemensstrasse 1",
                "date": "22.8.2025",
                "time": "5:37:24"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.6796379,
                    48.2073704
                ]
            },
            "properties": {
                "id": "INFT-AJJLB7",
                "name": "Land lebt auf",
                "S98": "0",
                "S95": "1.478",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "4681",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Grieskirchen",
                "city": "Rottenbach",
                "strasse": "Rottenbach Nr. 52",
                "date": "22.8.2025",
                "time": "5:38:8"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.3613545,
                    48.2438482
                ]
            },
            "properties": {
                "id": "INFT-AJJUBS",
                "name": "BP",
                "S98": "0",
                "S95": "1.659",
                "N": "0",
                "D": "1.679",
                "G": "0",
                "zip": "1190",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Döbling",
                "city": "Wien",
                "strasse": "Heiligenstaedterstr.77 ",
                "date": "22.8.2025",
                "time": "5:38:59"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.623819,
                    46.757742
                ]
            },
            "properties": {
                "id": "INFT-AJJU4T",
                "name": "Rumpold",
                "S98": "0",
                "S95": "1.444",
                "N": "0",
                "D": "1.453",
                "G": "0",
                "zip": "8423",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Leibnitz",
                "city": "St. Veit am Vogau",
                "strasse": "Technologiepark 1",
                "date": "22.8.2025",
                "time": "5:38:28"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.6962469,
                    46.5532088
                ]
            },
            "properties": {
                "id": "INFT-AJJUAA",
                "name": "Maurer - Arnoldstein",
                "S98": "0",
                "S95": "1.497",
                "N": "0",
                "D": "1.497",
                "G": "0",
                "zip": "9601",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Villach Land",
                "city": "Arnoldstein",
                "strasse": "Industriestraße 6",
                "date": "22.8.2025",
                "time": "5:37:31"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.7004781,
                    47.3510889
                ]
            },
            "properties": {
                "id": "INFT-AJJU95",
                "name": "Gutmann ENI Tankstelle",
                "S98": "0",
                "S95": "1.599",
                "N": "0",
                "D": "1.599",
                "G": "0",
                "zip": "6134",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Schwaz",
                "city": "Vomp",
                "strasse": "Industriestraße 12",
                "date": "22.8.2025",
                "time": "5:38:46"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.36138,
                    48.24161
                ]
            },
            "properties": {
                "id": "INFT-AJJUBP",
                "name": "Shell Austria",
                "S98": "0",
                "S95": "1.654",
                "N": "0",
                "D": "1.674",
                "G": "0",
                "zip": "1190",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Döbling",
                "city": "WIEN",
                "strasse": "HEILIGENSTAEDTERSTR. 60",
                "date": "22.8.2025",
                "time": "5:38:59"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.903348,
                    48.310987
                ]
            },
            "properties": {
                "id": "INFT-AJJUB7",
                "name": "GENOL-LH EFERDING-OÖ. MITTE eGen",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "4731",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Eferding",
                "city": "PRAMBACHKIRCHEN",
                "strasse": "GRIESKIRCHNERSTRASSE 6",
                "date": "22.8.2025",
                "time": "5:38:4"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.268679,
                    48.742847
                ]
            },
            "properties": {
                "id": "INFT-AJJU7Y",
                "name": "Genol",
                "S98": "0",
                "S95": "1.559",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "3900",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Zwettl",
                "city": "Schwarzenau",
                "strasse": "Schwarzenau 51",
                "date": "22.8.2025",
                "time": "5:37:58"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.3997343,
                    48.7247357
                ]
            },
            "properties": {
                "id": "INFT-AJJU7X",
                "name": "Genol",
                "S98": "0",
                "S95": "1.559",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "3900",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Zwettl",
                "city": "Goepfritz",
                "strasse": "Hauptstraße 73",
                "date": "22.8.2025",
                "time": "5:37:58"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.05145,
                    48.26028
                ]
            },
            "properties": {
                "id": "INFT-AJJU5J",
                "name": "AVANTI - Braunau Laabstraße",
                "S98": "0",
                "S95": "1.484",
                "N": "0",
                "D": "1.504",
                "G": "0",
                "zip": "5280",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Braunau",
                "city": "Braunau",
                "strasse": "Laabstrasse ",
                "date": "22.8.2025",
                "time": "5:38:3"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.4171484,
                    48.2165742
                ]
            },
            "properties": {
                "id": "INFT-AJJU5B",
                "name": "BP",
                "S98": "0",
                "S95": "1.539",
                "N": "0",
                "D": "1.619",
                "G": "0",
                "zip": "1020",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Leopoldstadt",
                "city": "Wien",
                "strasse": "Handelskai 276-280 ",
                "date": "22.8.2025",
                "time": "5:38:52"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.39351,
                    46.97355
                ]
            },
            "properties": {
                "id": "INFT-AJJU65",
                "name": "AVANTI - Friesach Judendorf 9",
                "S98": "0",
                "S95": "1.499",
                "N": "0",
                "D": "1.519",
                "G": "0",
                "zip": "9360",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "St. Veit",
                "city": "Friesach",
                "strasse": "Judendorf 9",
                "date": "22.8.2025",
                "time": "5:37:29"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.39875,
                    47.4446
                ]
            },
            "properties": {
                "id": "INFT-AJJU9A",
                "name": "Shell Austria",
                "S98": "0",
                "S95": "1.569",
                "N": "0",
                "D": "1.579",
                "G": "0",
                "zip": "6370",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Kitzbühel",
                "city": "KITZBUEHEL",
                "strasse": "AM SPORTFELD 4",
                "date": "22.8.2025",
                "time": "5:38:41"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.077085,
                    48.255305
                ]
            },
            "properties": {
                "id": "INFT-AJJU5L",
                "name": "Wölfl",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.439",
                "G": "0",
                "zip": "4963",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Braunau",
                "city": "St. Peter am Hart",
                "strasse": "Gewerbestraße 10",
                "date": "22.8.2025",
                "time": "5:38:2"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.4449326,
                    48.4584665
                ]
            },
            "properties": {
                "id": "INFT-AJJU85",
                "name": "Lagerhaus Genol",
                "S98": "0",
                "S95": "1.499",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "4786",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Schärding",
                "city": "Brunnenthal",
                "strasse": "Otterbacherstrasse 2",
                "date": "22.8.2025",
                "time": "5:38:15"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.11491,
                    48.288005
                ]
            },
            "properties": {
                "id": "INFT-AJJUB9",
                "name": "GENOL-LH EFERDING-OÖ. MITTE eGen",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "4072",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Eferding",
                "city": "ALKOVEN",
                "strasse": "SCHLOSSSTRASSE 51",
                "date": "22.8.2025",
                "time": "5:38:4"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.3517548,
                    48.1796472
                ]
            },
            "properties": {
                "id": "INFT-AJJUAN",
                "name": "BP",
                "S98": "0",
                "S95": "1.619",
                "N": "0",
                "D": "1.639",
                "G": "0",
                "zip": "1050",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Margareten",
                "city": "Wien",
                "strasse": "Margaretenguertel 43-45 ",
                "date": "22.8.2025",
                "time": "5:38:52"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.680457,
                    47.363987
                ]
            },
            "properties": {
                "id": "INFT-AJJU4M",
                "name": "ESW Dieselkraftstoff",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.494",
                "G": "0",
                "zip": "6845",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Dornbirn",
                "city": "Hohenems",
                "strasse": "Kaulbachstraße 6",
                "date": "22.8.2025",
                "time": "5:38:49"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.1053708,
                    48.9169877
                ]
            },
            "properties": {
                "id": "INFT-AJJUCP",
                "name": "Genol",
                "S98": "0",
                "S95": "1.559",
                "N": "0",
                "D": "1.579",
                "G": "0",
                "zip": "3862",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Gmünd",
                "city": "Eisgarn",
                "strasse": "Raiffeisenstraße 62",
                "date": "22.8.2025",
                "time": "5:37:42"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.916588,
                    48.416328
                ]
            },
            "properties": {
                "id": "INFT-AJJUB8",
                "name": "GENOL-LH EFERDING-OÖ. MITTE eGen",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "4083",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Eferding",
                "city": "HAIBACH OB DER DONAU",
                "strasse": "BERGERSTRASSE 1",
                "date": "22.8.2025",
                "time": "5:38:4"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.9935071,
                    48.5621814
                ]
            },
            "properties": {
                "id": "INFT-AJJU72",
                "name": "BP - Lagerhaus",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "4150",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Rohrbach",
                "city": "Rohrbach",
                "strasse": "Scheiblberg 44",
                "date": "22.8.2025",
                "time": "5:38:14"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.981425,
                    48.125481
                ]
            },
            "properties": {
                "id": "INFT-AJJU9F",
                "name": "Essmeister Diskont",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.449",
                "G": "0",
                "zip": "3372",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Melk",
                "city": "Blindenmarkt",
                "strasse": "Bahnhofstrasse 5",
                "date": "22.8.2025",
                "time": "5:37:48"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.8195141,
                    48.7363704
                ]
            },
            "properties": {
                "id": "INFT-AJJU73",
                "name": "BP - Lagerhaus",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "4164",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Rohrbach",
                "city": "Schwarzenberg",
                "strasse": "Schwarzenberg 168",
                "date": "22.8.2025",
                "time": "5:38:14"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.42036,
                    48.23367
                ]
            },
            "properties": {
                "id": "INFT-AJJUBT",
                "name": "Shell Austria",
                "S98": "0",
                "S95": "1.497",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "1220",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Donaustadt",
                "city": "WIEN",
                "strasse": "WAGRAMERSTRASSE 14",
                "date": "22.8.2025",
                "time": "5:39:2"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.122093,
                    47.379013
                ]
            },
            "properties": {
                "id": "INFT-AJJU6S",
                "name": "eni",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "7423",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Oberwart",
                "city": "Pinkafeld",
                "strasse": "Wiener Strasse 52",
                "date": "22.8.2025",
                "time": "5:37:24"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.73619,
                    47.95502
                ]
            },
            "properties": {
                "id": "INFT-AJJU6D",
                "name": "AVANTI - Rutzenmoos Autobahnzubringer Gmunden",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.503",
                "G": "0",
                "zip": "4845",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Vöcklabruck",
                "city": "Rutzenmoos",
                "strasse": "Autobahnzubringer Gmunden ",
                "date": "22.8.2025",
                "time": "5:38:6"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.9935071,
                    48.5621814
                ]
            },
            "properties": {
                "id": "INFT-AJJU75",
                "name": "Genol - Lagerhaus",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "4150",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Rohrbach",
                "city": "Rohrbach",
                "strasse": "Scheiblberg 44",
                "date": "22.8.2025",
                "time": "5:38:13"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.519458003456242,
                    47.043302810014616
                ]
            },
            "properties": {
                "id": "INFT-AJJUBJ",
                "name": "F. LEITNER",
                "S98": "0",
                "S95": "1.438",
                "N": "0",
                "D": "1.443",
                "G": "0",
                "zip": "8075",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Graz Umgebung",
                "city": "Hart bei Graz",
                "strasse": "Harter Süd Straße 6",
                "date": "22.8.2025",
                "time": "5:38:27"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.12039,
                    48.86169
                ]
            },
            "properties": {
                "id": "INFT-AJJUCR",
                "name": "AVANTI - Heidenreichstein Schremser Straße 52",
                "S98": "0",
                "S95": "1.559",
                "N": "0",
                "D": "1.579",
                "G": "0",
                "zip": "3860",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Gmünd",
                "city": "Heidenreichstein",
                "strasse": "Schremser Strasse 52",
                "date": "22.8.2025",
                "time": "5:37:42"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.9978364,
                    47.834666
                ]
            },
            "properties": {
                "id": "INFT-AJJU9T",
                "name": "IQ Tankstelle",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.514",
                "G": "0",
                "zip": "5020",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Salzburg Umgebung",
                "city": "Salzburg",
                "strasse": "Franz Sauer-Strasse 46 ",
                "date": "22.8.2025",
                "time": "5:38:18"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.31328,
                    48.20786
                ]
            },
            "properties": {
                "id": "INFT-AJJUBK",
                "name": "Shell Austria",
                "S98": "0",
                "S95": "1.569",
                "N": "0",
                "D": "1.579",
                "G": "0",
                "zip": "1160",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Ottakring",
                "city": "WIEN",
                "strasse": "PFENNINGGELDG 2/ECKE HERBSTSTRASSE",
                "date": "22.8.2025",
                "time": "5:38:58"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.88519,
                    47.43729
                ]
            },
            "properties": {
                "id": "INFT-AJJU97",
                "name": "Disk TANKAUTOMAT",
                "S98": "0",
                "S95": "1.469",
                "N": "0",
                "D": "1.469",
                "G": "0",
                "zip": "6230",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Kufstein",
                "city": "Brixlegg",
                "strasse": "Innsbrucker Straße 20",
                "date": "22.8.2025",
                "time": "5:38:42"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.31767,
                    48.20186
                ]
            },
            "properties": {
                "id": "INFT-AJJU7P",
                "name": "Shell Austria",
                "S98": "0",
                "S95": "1.569",
                "N": "0",
                "D": "1.579",
                "G": "0",
                "zip": "1150",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Rudolfsheim",
                "city": "WIEN",
                "strasse": "OEVERSEESTRASSE 2B",
                "date": "22.8.2025",
                "time": "5:38:58"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.049067,
                    46.551601
                ]
            },
            "properties": {
                "id": "INFT-AJJUA9",
                "name": "Lagerhaus Tankstelle ",
                "S98": "0",
                "S95": "1.553",
                "N": "0",
                "D": "1.525",
                "G": "0",
                "zip": "9184",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Villach Land",
                "city": "Sankt Jakob",
                "strasse": "Sankt Jakob 70",
                "date": "22.8.2025",
                "time": "5:37:32"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.0553602,
                    48.5733215
                ]
            },
            "properties": {
                "id": "INFT-AJJU76",
                "name": "Genol - Lagerhaus",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "4170",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Rohrbach",
                "city": "Haslach",
                "strasse": "Sternwaldstrasse 56",
                "date": "22.8.2025",
                "time": "5:38:13"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.56378,
                    48.08075
                ]
            },
            "properties": {
                "id": "INFT-AJJU8X",
                "name": "AVANTI - Ampflwang Siedlung 170",
                "S98": "0",
                "S95": "1.484",
                "N": "0",
                "D": "1.494",
                "G": "0",
                "zip": "4843",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Vöcklabruck",
                "city": "Ampflwang",
                "strasse": "Siedlung 170",
                "date": "22.8.2025",
                "time": "5:38:17"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.294513,
                    48.190443
                ]
            },
            "properties": {
                "id": "INFT-AJJU7K",
                "name": "Shell Austria",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "1140",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Penzing",
                "city": "WIEN",
                "strasse": "HADIKGASSE 128-134",
                "date": "22.8.2025",
                "time": "5:38:57"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.2146802,
                    48.0646577
                ]
            },
            "properties": {
                "id": "INFT-AJJU7T",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.429",
                "N": "0",
                "D": "1.439",
                "G": "0",
                "zip": "2531",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Mödling",
                "city": "Gaaden",
                "strasse": "Hauptstraße 101",
                "date": "22.8.2025",
                "time": "5:37:50"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.39464,
                    48.21777
                ]
            },
            "properties": {
                "id": "INFT-AJJU5A",
                "name": "Shell Austria",
                "S98": "0",
                "S95": "1.569",
                "N": "0",
                "D": "1.579",
                "G": "0",
                "zip": "1020",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Leopoldstadt",
                "city": "WIEN",
                "strasse": "AUSSTELLUNGSSTRASSE 4",
                "date": "22.8.2025",
                "time": "5:38:52"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.8192284,
                    47.1478021
                ]
            },
            "properties": {
                "id": "INFT-AJJU5Q",
                "name": "TK Tankstellen GmbH",
                "S98": "0",
                "S95": "1.484",
                "N": "0",
                "D": "1.524",
                "G": "0",
                "zip": "6706",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Bludenz",
                "city": "Bürs",
                "strasse": "Bremschlstrasse 37",
                "date": "22.8.2025",
                "time": "5:38:47"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.9809552,
                    48.7637516
                ]
            },
            "properties": {
                "id": "INFT-AJJUCN",
                "name": "Genol",
                "S98": "0",
                "S95": "1.559",
                "N": "0",
                "D": "1.579",
                "G": "0",
                "zip": "3950",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Gmünd",
                "city": "Gmuend",
                "strasse": "Conrathstraße 3",
                "date": "22.8.2025",
                "time": "5:37:42"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.4338,
                    47.26326
                ]
            },
            "properties": {
                "id": "INFT-AJJU6U",
                "name": "Diesel, Super",
                "S98": "0",
                "S95": "1.469",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "7472",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Oberwart",
                "city": "Schachendorf",
                "strasse": "Steinamanger Straße",
                "date": "22.8.2025",
                "time": "5:37:25"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.27161,
                    48.46445
                ]
            },
            "properties": {
                "id": "INFT-AJJU6Z",
                "name": "AVANTI - Zwettl Linzer Straße 4",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.484",
                "G": "0",
                "zip": "4180",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Urfahr Umgebung",
                "city": "Zwettl",
                "strasse": "Linzer Strasse 4",
                "date": "22.8.2025",
                "time": "5:38:16"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    10.7479088,
                    47.226803
                ]
            },
            "properties": {
                "id": "INFT-AJJU4B",
                "name": "Gutmann Eni Tankstelle ",
                "S98": "0",
                "S95": "1.599",
                "N": "0",
                "D": "1.599",
                "G": "0",
                "zip": "6460",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Imst",
                "city": "Imst",
                "strasse": "Langgasse 95",
                "date": "22.8.2025",
                "time": "5:38:39"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.092447,
                    48.154907
                ]
            },
            "properties": {
                "id": "INFT-AJJU9G",
                "name": "Essmeister Diskont",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.449",
                "G": "0",
                "zip": "3373",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Melk",
                "city": "Kemmelbach",
                "strasse": "Hauptstrasse 5",
                "date": "22.8.2025",
                "time": "5:37:48"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.988022,
                    48.760891
                ]
            },
            "properties": {
                "id": "INFT-AJJUCS",
                "name": "",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.579",
                "G": "0",
                "zip": "3950",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Gmünd",
                "city": "Gmuend",
                "strasse": "Albrechtser Straße 8",
                "date": "22.8.2025",
                "time": "5:37:41"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.0509102,
                    47.021201
                ]
            },
            "properties": {
                "id": "INFT-AJJU53",
                "name": "LAGERHAUS Genol Edelschrott ",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.439",
                "G": "0",
                "zip": "8583",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Voitsberg",
                "city": "Edelschrott",
                "strasse": "Packerstraße 14",
                "date": "22.8.2025",
                "time": "5:38:32"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.77445,
                    47.3885
                ]
            },
            "properties": {
                "id": "INFT-AJJU96",
                "name": "Shell Austria",
                "S98": "0",
                "S95": "1.629",
                "N": "0",
                "D": "1.619",
                "G": "0",
                "zip": "6200",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Schwaz",
                "city": "JENBACH",
                "strasse": "ACHENSEE-STRASSE 2",
                "date": "22.8.2025",
                "time": "5:38:46"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.10054,
                    47.69183
                ]
            },
            "properties": {
                "id": "INFT-AJJUCC",
                "name": "Shell Austria",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.529",
                "G": "0",
                "zip": "5411",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Hallein",
                "city": "OBERALM",
                "strasse": "HALLEINER LANDESSTRASSE 12",
                "date": "22.8.2025",
                "time": "5:38:19"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.3620933,
                    47.8067759
                ]
            },
            "properties": {
                "id": "INFT-AJJU9W",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.464",
                "N": "0",
                "D": "1.482",
                "G": "0",
                "zip": "7033",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Mattersburg",
                "city": "Pöttsching",
                "strasse": "Wienerneustädter Straße 65",
                "date": "22.8.2025",
                "time": "5:37:21"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.2187091,
                    47.0530953
                ]
            },
            "properties": {
                "id": "INFT-AJJU54",
                "name": "LAGERHAUS Genol Stallhofen",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.439",
                "G": "0",
                "zip": "8152",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Voitsberg",
                "city": "Stallhofen",
                "strasse": "Aichegg 110",
                "date": "22.8.2025",
                "time": "5:38:32"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.2702762,
                    46.8895356
                ]
            },
            "properties": {
                "id": "INFT-AJJU7J",
                "name": "LAGERHAUS Genol Stainz ",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.449",
                "G": "0",
                "zip": "8510",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Deutschlandsberg",
                "city": "Stainz",
                "strasse": "Langwiesenbachgasse 9",
                "date": "22.8.2025",
                "time": "5:38:25"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.4855,
                    48.1397
                ]
            },
            "properties": {
                "id": "INFT-AJJU3W",
                "name": "AVANTI - Schwechat Bruck-Hainburger Straße 24a",
                "S98": "0",
                "S95": "1.433",
                "N": "0",
                "D": "1.452",
                "G": "0",
                "zip": "2320",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Wien Umgebung",
                "city": "Schwechat",
                "strasse": "Bruck-Hainburger Strasse 24a",
                "date": "22.8.2025",
                "time": "5:37:39"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.9020769,
                    48.6988542
                ]
            },
            "properties": {
                "id": "INFT-AJJUCQ",
                "name": "Genol",
                "S98": "0",
                "S95": "1.559",
                "N": "0",
                "D": "1.579",
                "G": "0",
                "zip": "3970",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Gmünd",
                "city": "Weitra",
                "strasse": "Zwettler Straße 133",
                "date": "22.8.2025",
                "time": "5:37:42"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.6141023,
                    48.1574747
                ]
            },
            "properties": {
                "id": "INFT-AJJU48",
                "name": "BP",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.519",
                "G": "0",
                "zip": "3100",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "St. Pölten",
                "city": "St. Poelten",
                "strasse": "Mariazeller Str.264 ",
                "date": "22.8.2025",
                "time": "5:37:35"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.158255,
                    48.153132
                ]
            },
            "properties": {
                "id": "INFT-AJJUB6",
                "name": "IQ  Tankomat Allhaming",
                "S98": "0",
                "S95": "1.439",
                "N": "0",
                "D": "1.445",
                "G": "0",
                "zip": "4511",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Linz Land",
                "city": "Allhaming",
                "strasse": "Poststrasse 3",
                "date": "22.8.2025",
                "time": "5:38:10"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.072502,
                    47.300377
                ]
            },
            "properties": {
                "id": "INFT-AJJUAW",
                "name": "Unser Lagerhaus",
                "S98": "0",
                "S95": "1.609",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "6405",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Innsbruck Land",
                "city": "Pfaffenhofen",
                "strasse": "Gewerbepark 2",
                "date": "22.8.2025",
                "time": "5:38:40"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.2826219,
                    47.8011008
                ]
            },
            "properties": {
                "id": "INFT-AJJU9V",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.476",
                "G": "0",
                "zip": "7201",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Mattersburg",
                "city": "Neudörfl",
                "strasse": "Haupstraße 140",
                "date": "22.8.2025",
                "time": "5:37:21"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.362988,
                    47.880376
                ]
            },
            "properties": {
                "id": "INFT-AJJU5E",
                "name": "LAGERHAUS Genol mit Tankkartensystem",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.458",
                "G": "0",
                "zip": "2490",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Wiener Neustadt Land",
                "city": "Ebenfurth",
                "strasse": "Ing.Gerhard Fildan Strasse",
                "date": "22.8.2025",
                "time": "5:37:56"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.9885879,
                    48.0391046
                ]
            },
            "properties": {
                "id": "INFT-AJJU5G",
                "name": "Disconttankstelle Huber Petrol",
                "S98": "0",
                "S95": "1.468",
                "N": "0",
                "D": "1.468",
                "G": "0",
                "zip": "5141",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Braunau",
                "city": "Moosdorf",
                "strasse": "Gewerbepark Süd 3",
                "date": "22.8.2025",
                "time": "5:38:3"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    10.6671344,
                    47.0914553
                ]
            },
            "properties": {
                "id": "INFT-AJJUCU",
                "name": "Gutmann ENI Tankstelle",
                "S98": "0",
                "S95": "1.619",
                "N": "0",
                "D": "1.619",
                "G": "0",
                "zip": "6522",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Landeck",
                "city": "Prutz",
                "strasse": "Gewerbestraße 2",
                "date": "22.8.2025",
                "time": "5:38:44"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.49421958255084,
                    47.03007469884339
                ]
            },
            "properties": {
                "id": "INFT-AJJUBH",
                "name": "F.LEITNER - Autohaus Fleck",
                "S98": "0",
                "S95": "1.438",
                "N": "0",
                "D": "1.443",
                "G": "0",
                "zip": "8074",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Graz Umgebung",
                "city": "Raaba",
                "strasse": "Bahnhofstraße 1",
                "date": "22.8.2025",
                "time": "5:38:27"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.2776905,
                    48.1927168
                ]
            },
            "properties": {
                "id": "INFT-AJJU7M",
                "name": "BP",
                "S98": "0",
                "S95": "1.499",
                "N": "0",
                "D": "1.519",
                "G": "0",
                "zip": "1140",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Penzing",
                "city": "Wien",
                "strasse": "Hadikgasse/Kefergasse ",
                "date": "22.8.2025",
                "time": "5:38:57"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.42524,
                    48.31724
                ]
            },
            "properties": {
                "id": "INFT-AJJU9R",
                "name": "AVANTI - Ort im Innkreis Kammer 19",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.454",
                "G": "0",
                "zip": "4974",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Ried",
                "city": "Ort im Innkreis",
                "strasse": "Kammer 19",
                "date": "22.8.2025",
                "time": "5:38:12"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.4393,
                    46.88821
                ]
            },
            "properties": {
                "id": "INFT-AJJU66",
                "name": "Shell Austria",
                "S98": "0",
                "S95": "1.519",
                "N": "0",
                "D": "1.529",
                "G": "0",
                "zip": "9330",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "St. Veit",
                "city": "TREIBACH",
                "strasse": "POECKSTEIN 3",
                "date": "22.8.2025",
                "time": "5:37:30"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.6397468,
                    48.1979429
                ]
            },
            "properties": {
                "id": "INFT-AJJU47",
                "name": "BP",
                "S98": "0",
                "S95": "1.499",
                "N": "0",
                "D": "1.519",
                "G": "0",
                "zip": "3100",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "St. Pölten",
                "city": "St. Poelten",
                "strasse": "Niederoesterreichring 20 ",
                "date": "22.8.2025",
                "time": "5:37:36"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.3481402,
                    48.2392811
                ]
            },
            "properties": {
                "id": "INFT-AJJU9P",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.474",
                "N": "0",
                "D": "1.484",
                "G": "0",
                "zip": "4942",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Ried",
                "city": "Gurten",
                "strasse": "Rieder Straße 8",
                "date": "22.8.2025",
                "time": "5:38:13"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.7227999,
                    47.3596855
                ]
            },
            "properties": {
                "id": "INFT-AJJU94",
                "name": "Tankstelle Schaller",
                "S98": "0",
                "S95": "1.599",
                "N": "0",
                "D": "1.599",
                "G": "0",
                "zip": "6130",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Schwaz",
                "city": "Schwaz",
                "strasse": "Bergwerkstraße 33",
                "date": "22.8.2025",
                "time": "5:38:46"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.2767613,
                    48.1926383
                ]
            },
            "properties": {
                "id": "INFT-AJJU5H",
                "name": "Freie Tankstelle",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "5273",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Braunau",
                "city": "Rossbach",
                "strasse": "Fraham 13",
                "date": "22.8.2025",
                "time": "5:38:2"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.1175531,
                    48.8651376
                ]
            },
            "properties": {
                "id": "INFT-AJJUCT",
                "name": "Genol",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.579",
                "G": "0",
                "zip": "3860",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Gmünd",
                "city": "Heidenreichstein",
                "strasse": "Altmannser Straße 2",
                "date": "22.8.2025",
                "time": "5:37:41"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    10.6575315,
                    47.5502075
                ]
            },
            "properties": {
                "id": "INFT-AJJU79",
                "name": "Autohof Huter GmbH",
                "S98": "0",
                "S95": "1.579",
                "N": "0",
                "D": "1.589",
                "G": "0",
                "zip": "6682",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Reutte",
                "city": "Vils",
                "strasse": "Stegen 7",
                "date": "22.8.2025",
                "time": "5:38:45"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.60984,
                    47.2468
                ]
            },
            "properties": {
                "id": "INFT-AJJU7C",
                "name": "Shell Austria",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "6800",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Feldkirch",
                "city": "FELDKIRCH-LEVIS",
                "strasse": "REICHSSTRASSE 137",
                "date": "22.8.2025",
                "time": "5:38:51"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.19655,
                    47.60068
                ]
            },
            "properties": {
                "id": "INFT-AJJU5D",
                "name": "Gemeinde Lichtenegg",
                "S98": "0",
                "S95": "1.499",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "2813",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Wiener Neustadt Land",
                "city": "Lichtenegg",
                "strasse": "Hauptstrasse 15",
                "date": "22.8.2025",
                "time": "5:37:57"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.780412,
                    48.433248
                ]
            },
            "properties": {
                "id": "INFT-AJK39U",
                "name": "Genol  Lagerhaus Pregarten-Gallneukirchen",
                "S98": "0",
                "S95": "1.494",
                "N": "0",
                "D": "1.474",
                "G": "0",
                "zip": "4273",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Freistadt",
                "city": "Unterweißenbach",
                "strasse": "Markt Unterweißenbach 204",
                "date": "22.8.2025",
                "time": "5:38:6"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.3790297,
                    48.7147259
                ]
            },
            "properties": {
                "id": "INFT-AJK3AT",
                "name": "Genol",
                "S98": "0",
                "S95": "1.498",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "2136",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Mistelbach",
                "city": "Laa/Thaya",
                "strasse": "Thayapark 1-2",
                "date": "22.8.2025",
                "time": "5:37:50"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.50239,
                    47.929355
                ]
            },
            "properties": {
                "id": "INFT-AJK3AC",
                "name": "IQ Tankstelle",
                "S98": "0",
                "S95": "1.474",
                "N": "0",
                "D": "1.494",
                "G": "0",
                "zip": "4880",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Vöcklabruck",
                "city": "St.Georgen/Attergau",
                "strasse": "Am Seering 6",
                "date": "22.8.2025",
                "time": "5:38:17"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.425225,
                    48.308489
                ]
            },
            "properties": {
                "id": "INFT-AJK3AH",
                "name": "Wölfl",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.439",
                "G": "0",
                "zip": "4974",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Ried",
                "city": "Reichersberg",
                "strasse": "Kammer 38 - Gewerbegebiet",
                "date": "22.8.2025",
                "time": "5:38:12"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    10.8198,
                    47.3272
                ]
            },
            "properties": {
                "id": "INFT-AJK39F",
                "name": "OMV - Nassereith Fernpaß Bundesstraße 1",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.619",
                "G": "0",
                "zip": "6465",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Imst",
                "city": "Nassereith",
                "strasse": "Fernpass Bundesstrasse 1",
                "date": "22.8.2025",
                "time": "5:38:38"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.6042398,
                    47.2690136
                ]
            },
            "properties": {
                "id": "INFT-AJK39X",
                "name": "TK Tankstellen GmbH",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "6800",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Feldkirch",
                "city": "Feldkirch",
                "strasse": "Studa 3a",
                "date": "22.8.2025",
                "time": "5:38:51"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.7377447,
                    47.534922
                ]
            },
            "properties": {
                "id": "INFT-AJK39H",
                "name": "Deuring",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.539",
                "G": "0",
                "zip": "6912",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Bregenz",
                "city": "Hörbranz",
                "strasse": "Seestrasse 10",
                "date": "22.8.2025",
                "time": "5:38:48"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.5695697,
                    48.3535047
                ]
            },
            "properties": {
                "id": "INFT-AJK3B2",
                "name": "GENOL",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.489",
                "G": "0",
                "zip": "2212",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Mistelbach",
                "city": "Grossengersdorf",
                "strasse": "Bahngasse 35",
                "date": "22.8.2025",
                "time": "5:37:49"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.3743119,
                    48.2123537
                ]
            },
            "properties": {
                "id": "INFT-AJK3AQ",
                "name": "BP",
                "S98": "0",
                "S95": "1.619",
                "N": "0",
                "D": "1.619",
                "G": "0",
                "zip": "1010",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Innere Stadt",
                "city": "Wien",
                "strasse": "Franz Josefskai/Morzinpl ",
                "date": "22.8.2025",
                "time": "5:38:52"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.61824,
                    48.23172
                ]
            },
            "properties": {
                "id": "INFT-AJK3BC",
                "name": "GENOL-LH EFERDING-OÖ. MITTE eGen",
                "S98": "0",
                "S95": "1.478",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "4742",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Grieskirchen",
                "city": "PRAM",
                "strasse": "STEINBRUCK 16",
                "date": "22.8.2025",
                "time": "5:38:8"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.900355,
                    47.472489
                ]
            },
            "properties": {
                "id": "INFT-AJK39G",
                "name": "Wälderhaus",
                "S98": "0",
                "S95": "1.56",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "6941",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Bregenz",
                "city": "Langenegg",
                "strasse": "Gfäll 134",
                "date": "22.8.2025",
                "time": "5:38:49"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.7393838,
                    47.5333189
                ]
            },
            "properties": {
                "id": "INFT-AJK6RE",
                "name": "Schindele, Hörbranz",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.539",
                "G": "0",
                "zip": "6912",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Bregenz",
                "city": "Hörbranz",
                "strasse": "Seestr. 14a",
                "date": "22.8.2025",
                "time": "5:38:48"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.443402,
                    47.052683
                ]
            },
            "properties": {
                "id": "INFT-AJKA8D",
                "name": "Rumpold",
                "S98": "0",
                "S95": "1.432",
                "N": "0",
                "D": "1.436",
                "G": "0",
                "zip": "8010",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Graz",
                "city": "Graz",
                "strasse": "Kasernstraße 14",
                "date": "22.8.2025",
                "time": "5:38:24"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.17546924,
                    47.59195584
                ]
            },
            "properties": {
                "id": "INFT-AJKA8H",
                "name": "ENI",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.529",
                "G": "0",
                "zip": "5440",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Hallein",
                "city": "Golling",
                "strasse": "Obergäu 310",
                "date": "22.8.2025",
                "time": "5:38:19"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.5173,
                    46.8401
                ]
            },
            "properties": {
                "id": "INFT-AJKA6R",
                "name": "OIL! Tankstelle",
                "S98": "0",
                "S95": "1.449",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "8403",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Leibnitz",
                "city": "Lebring Joess",
                "strasse": "Joess 7A",
                "date": "22.8.2025",
                "time": "5:38:28"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.122109,
                    47.903796
                ]
            },
            "properties": {
                "id": "INFT-AJKA8C",
                "name": "SOCAR Kirchdorf a. d. Krems",
                "S98": "0",
                "S95": "1.529",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "4560",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Kirchdorf",
                "city": "Kirchdorf a. d. Krems",
                "strasse": "Bambergstraße 44",
                "date": "22.8.2025",
                "time": "5:38:9"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.846774,
                    48.226524
                ]
            },
            "properties": {
                "id": "INFT-AJKBE3",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.494",
                "G": "0",
                "zip": "4710",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Grieskirchen",
                "city": "Grieskirchen",
                "strasse": "Industriegelände 5",
                "date": "22.8.2025",
                "time": "5:38:7"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.8432788,
                    47.8587366
                ]
            },
            "properties": {
                "id": "INFT-AJKCSA",
                "name": "boesch energy,  turmöl Quick",
                "S98": "0",
                "S95": "1.472",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "7141",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Neusiedl am See",
                "city": "Podersdorf",
                "strasse": "Neusiedlerstr. 67",
                "date": "22.8.2025",
                "time": "5:37:22"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.74609,
                    47.04704
                ]
            },
            "properties": {
                "id": "INFT-AJKCS8",
                "name": "AVANTI - Sankt Margarethen an der Raab 190",
                "S98": "0",
                "S95": "1.459",
                "N": "0",
                "D": "1.459",
                "G": "0",
                "zip": "8321",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Weiz",
                "city": "Sankt Margarethen an der Raab",
                "strasse": "Sankt Margarethen an der Raab 190",
                "date": "22.8.2025",
                "time": "5:38:34"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.9148443,
                    48.2226367
                ]
            },
            "properties": {
                "id": "INFT-AJKCSC",
                "name": "AVIA Xpress (Automaten-Tankstelle)",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.494",
                "G": "0",
                "zip": "4701",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Grieskirchen",
                "city": "Bad Schallerbach",
                "strasse": "Am Müllerberg 23",
                "date": "22.8.2025",
                "time": "5:38:7"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.1933142,
                    48.3800171
                ]
            },
            "properties": {
                "id": "INFT-AJKF23",
                "name": "Turmöl",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "4201",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Urfahr Umgebung",
                "city": "Gramastetten",
                "strasse": "Wöranstraße 2",
                "date": "22.8.2025",
                "time": "5:38:16"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.75363,
                    46.83172
                ]
            },
            "properties": {
                "id": "INFT-AJKF26",
                "name": "OMV Fast Lane - Lienz Iseltaler Straße 30",
                "S98": "0",
                "S95": "1.514",
                "N": "0",
                "D": "1.514",
                "G": "0",
                "zip": "9900",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Lienz",
                "city": "Lienz",
                "strasse": "Iseltaler Strasse 30",
                "date": "22.8.2025",
                "time": "5:38:45"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.6461741,
                    48.4018614
                ]
            },
            "properties": {
                "id": "INFT-AJKHRK",
                "name": "Rickl Mühle",
                "S98": "0",
                "S95": "1.438",
                "N": "0",
                "D": "1.448",
                "G": "0",
                "zip": "2221",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Gänserndorf",
                "city": "Groß Schweinbarth",
                "strasse": "Raggendorfer Straße 1",
                "date": "22.8.2025",
                "time": "5:37:40"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.5719529,
                    48.4845822
                ]
            },
            "properties": {
                "id": "INFT-AJKHRQ",
                "name": "Diskont Lichtenauer",
                "S98": "0",
                "S95": "1.499",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "4792",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Schärding",
                "city": "Münzkirchen",
                "strasse": "Hofmark 26",
                "date": "22.8.2025",
                "time": "5:38:15"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.192861,
                    48.205435
                ]
            },
            "properties": {
                "id": "INFT-AJKHPS",
                "name": "eni24",
                "S98": "0",
                "S95": "1.442",
                "N": "0",
                "D": "1.453",
                "G": "0",
                "zip": "3002",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Wien Umgebung",
                "city": "Purkersdorf",
                "strasse": "Wiener Strasse 48",
                "date": "22.8.2025",
                "time": "5:37:53"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.669049,
                    48.7434981
                ]
            },
            "properties": {
                "id": "INFT-AJKHR7",
                "name": "Genol",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.569",
                "G": "0",
                "zip": "3753",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Horn",
                "city": "Hötzelsdorf",
                "strasse": "43",
                "date": "22.8.2025",
                "time": "5:37:44"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.0741368,
                    47.3002541
                ]
            },
            "properties": {
                "id": "INFT-AJKHSR",
                "name": "Disk TANKAUTOMAT",
                "S98": "0",
                "S95": "1.609",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "6405",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Innsbruck Land",
                "city": "Pfaffenhofen",
                "strasse": "Unterdorf 171",
                "date": "22.8.2025",
                "time": "5:38:40"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.501615,
                    48.756557
                ]
            },
            "properties": {
                "id": "INFT-AJKHSP",
                "name": "tom´s Tankautomat",
                "S98": "0",
                "S95": "1.483",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "2164",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Mistelbach",
                "city": "Wildendürnbach",
                "strasse": "Wildendürnbach 114",
                "date": "22.8.2025",
                "time": "5:37:49"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.9296682,
                    48.2814015
                ]
            },
            "properties": {
                "id": "INFT-AJKHQW",
                "name": "SOCAR Michelhausen",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.442",
                "G": "0",
                "zip": "3451",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Tulln",
                "city": "Michelhausen",
                "strasse": "Bergstraße 1",
                "date": "22.8.2025",
                "time": "5:37:54"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.4851752,
                    48.5176115
                ]
            },
            "properties": {
                "id": "INFT-AJKHRE",
                "name": "Shell",
                "S98": "0",
                "S95": "1.499",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "3542",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Krems Land",
                "city": "Gföhl",
                "strasse": "Zwettlerstraße  16",
                "date": "22.8.2025",
                "time": "5:37:46"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.2038779,
                    48.1381917
                ]
            },
            "properties": {
                "id": "INFT-AJKHRM",
                "name": "Vivod GmbH",
                "S98": "0",
                "S95": "1.43",
                "N": "0",
                "D": "1.44",
                "G": "0",
                "zip": "2384",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Mödling",
                "city": "Breitenfurt",
                "strasse": "Laaberstrasse 1",
                "date": "22.8.2025",
                "time": "5:37:51"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.5623334,
                    48.4825163
                ]
            },
            "properties": {
                "id": "INFT-AJKHRN",
                "name": "Turmöl",
                "S98": "0",
                "S95": "1.499",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "4792",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Schärding",
                "city": "Münzkirchen",
                "strasse": "Schärdinger Straße 30",
                "date": "22.8.2025",
                "time": "5:38:15"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.42309,
                    47.261905
                ]
            },
            "properties": {
                "id": "INFT-AJKHT3",
                "name": "Gutmann Shell Tankstelle",
                "S98": "0",
                "S95": "1.599",
                "N": "0",
                "D": "1.599",
                "G": "0",
                "zip": "6020",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Innsbruck",
                "city": "Innsbruck",
                "strasse": "Amraser See Straße 29",
                "date": "22.8.2025",
                "time": "5:38:37"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.4489482,
                    46.6218093
                ]
            },
            "properties": {
                "id": "INFT-AJKHQJ",
                "name": "Lagerhaus",
                "S98": "0",
                "S95": "1.457",
                "N": "0",
                "D": "1.457",
                "G": "0",
                "zip": "9131",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Klagenfurt Land",
                "city": "Grafenstein",
                "strasse": "10. Oktoberstrasse 9",
                "date": "22.8.2025",
                "time": "5:37:28"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.475316,
                    48.670913
                ]
            },
            "properties": {
                "id": "INFT-AJKHR6",
                "name": "Genol",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.569",
                "G": "0",
                "zip": "3592",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Horn",
                "city": "Winkl",
                "strasse": "51",
                "date": "22.8.2025",
                "time": "5:37:44"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.3386575,
                    47.56657
                ]
            },
            "properties": {
                "id": "INFT-AJKLMC",
                "name": "LMEnergy",
                "S98": "0",
                "S95": "1.474",
                "N": "0",
                "D": "1.504",
                "G": "0",
                "zip": "5441",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Hallein",
                "city": "Abtenau",
                "strasse": "Markt 240",
                "date": "22.8.2025",
                "time": "5:38:20"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.2710589,
                    47.9926268
                ]
            },
            "properties": {
                "id": "INFT-AJKMLM",
                "name": "SOCAR Tribuswinkel",
                "S98": "0",
                "S95": "1.449",
                "N": "0",
                "D": "1.464",
                "G": "0",
                "zip": "2512",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Baden",
                "city": "Tribuswinkel",
                "strasse": "Zubringerstraße 40",
                "date": "22.8.2025",
                "time": "5:37:38"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.5377049,
                    46.8465923
                ]
            },
            "properties": {
                "id": "INFT-AJKML8",
                "name": "SOCAR Lebring",
                "S98": "0",
                "S95": "1.449",
                "N": "0",
                "D": "1.453",
                "G": "0",
                "zip": "8403",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Leibnitz",
                "city": "Lebring",
                "strasse": "Leibnitzer Straße 76",
                "date": "22.8.2025",
                "time": "5:38:28"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.637852,
                    48.203264
                ]
            },
            "properties": {
                "id": "INFT-AJKTML",
                "name": "eni",
                "S98": "0",
                "S95": "1.499",
                "N": "0",
                "D": "1.519",
                "G": "0",
                "zip": "3100",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "St. Pölten",
                "city": "St. Pölten",
                "strasse": "Wiener Strasse 66",
                "date": "22.8.2025",
                "time": "5:37:36"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.31919002532959,
                    46.821875191797574
                ]
            },
            "properties": {
                "id": "INFT-AJKTMU",
                "name": "LAGERHAUS Genol Groß St. Florian ",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.449",
                "G": "0",
                "zip": "8522",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Leibnitz",
                "city": "Groß St. Florian",
                "strasse": "Markstraße 38",
                "date": "22.8.2025",
                "time": "5:38:25"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.0161079,
                    48.557693
                ]
            },
            "properties": {
                "id": "INFT-AJL3AP",
                "name": "AVIA XPress (unser Service: Luft und Wasser)",
                "S98": "0",
                "S95": "1.559",
                "N": "0",
                "D": "1.569",
                "G": "0",
                "zip": "3920",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Zwettl",
                "city": "Groß Gerungs",
                "strasse": "Groß Meinharts 10",
                "date": "22.8.2025",
                "time": "5:37:58"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.00609,
                    47.79796
                ]
            },
            "properties": {
                "id": "INFT-AJL3AT",
                "name": "OMV - Salzburg Innsbrucker Bundesstraße 142",
                "S98": "0",
                "S95": "1.504",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "5020",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Salzburg Umgebung",
                "city": "Salzburg",
                "strasse": "Innsbrucker Bundesstrasse 142",
                "date": "22.8.2025",
                "time": "5:38:18"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.5380846,
                    48.439863
                ]
            },
            "properties": {
                "id": "INFT-AJL6YP",
                "name": "Genol Lagerhaus Pregarten-Gallneukirchen",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.469",
                "G": "0",
                "zip": "4292",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Freistadt",
                "city": "Kefermarkt",
                "strasse": "Am Bahnhof 1",
                "date": "22.8.2025",
                "time": "5:38:5"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.8664272,
                    46.7080112
                ]
            },
            "properties": {
                "id": "INFT-AJL6YJ",
                "name": "Raiff. Lagerhaus St. Paul",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.491",
                "G": "0",
                "zip": "9470",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Wolfsberg",
                "city": "St. Paul",
                "strasse": "Bahnhofstrasse 21",
                "date": "22.8.2025",
                "time": "5:37:33"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.4939519,
                    48.2174061
                ]
            },
            "properties": {
                "id": "INFT-AJLA22",
                "name": "SOCAR Ried im Innkreis",
                "S98": "0",
                "S95": "1.474",
                "N": "0",
                "D": "1.484",
                "G": "0",
                "zip": "4910",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Ried",
                "city": "Ried im Innkreis",
                "strasse": "Riedauer Straße 35",
                "date": "22.8.2025",
                "time": "5:38:13"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.8870475,
                    48.573888
                ]
            },
            "properties": {
                "id": "INFT-AJLGD7",
                "name": "AVIA XPress",
                "S98": "0",
                "S95": "1.559",
                "N": "0",
                "D": "1.569",
                "G": "0",
                "zip": "3921",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Zwettl",
                "city": "Langschlag",
                "strasse": "Franz Diebl-Str. 44",
                "date": "22.8.2025",
                "time": "5:37:59"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.484127,
                    48.293787
                ]
            },
            "properties": {
                "id": "INFT-AJLGCB",
                "name": "GENOL",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.489",
                "G": "0",
                "zip": "2201",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Wien Umgebung",
                "city": "Gerasdorf",
                "strasse": "Am Bahnhof",
                "date": "22.8.2025",
                "time": "5:37:45"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.70056,
                    47.57544
                ]
            },
            "properties": {
                "id": "INFT-AJLGCH",
                "name": "Lagerhaus-Tankstelle 24h",
                "S98": "0",
                "S95": "1.559",
                "N": "0",
                "D": "1.569",
                "G": "0",
                "zip": "5092",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Zell am See",
                "city": "St. Martin/Lofer",
                "strasse": "St. Martin 179",
                "date": "22.8.2025",
                "time": "5:38:24"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.9673527,
                    48.4628625
                ]
            },
            "properties": {
                "id": "INFT-AJLGD6",
                "name": "IQ Diskont",
                "S98": "0",
                "S95": "1.549",
                "N": "0",
                "D": "1.569",
                "G": "0",
                "zip": "3925",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Zwettl",
                "city": "Altmelon",
                "strasse": "Altmelon 63",
                "date": "22.8.2025",
                "time": "5:37:58"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.9520745,
                    48.4936271
                ]
            },
            "properties": {
                "id": "INFT-AJLGD9",
                "name": "AVIA XPress (unser Service: Luft und Wasser)",
                "S98": "0",
                "S95": "1.559",
                "N": "0",
                "D": "1.569",
                "G": "0",
                "zip": "3925",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Zwettl",
                "city": "Arbesbach ",
                "strasse": "Nr. 44",
                "date": "22.8.2025",
                "time": "5:37:59"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.3283117,
                    47.2642527
                ]
            },
            "properties": {
                "id": "INFT-AJLGCJ",
                "name": "Lagerhaus-Tankstelle 24 h",
                "S98": "0",
                "S95": "1.544",
                "N": "0",
                "D": "1.564",
                "G": "0",
                "zip": "5733",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Zell am See",
                "city": "Bramberg",
                "strasse": "Weyerstrasse 366",
                "date": "22.8.2025",
                "time": "5:38:23"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.4732359,
                    48.3453667
                ]
            },
            "properties": {
                "id": "INFT-AJLTPN",
                "name": "Treibstoffparadies",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.489",
                "G": "0",
                "zip": "2201",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Wien Umgebung",
                "city": "Seyring",
                "strasse": "Am Weichselgarten 3",
                "date": "22.8.2025",
                "time": "5:37:45"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.9257925,
                    48.2275333
                ]
            },
            "properties": {
                "id": "INFT-AJM2XZ",
                "name": "PINK - so pink, so clever",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.494",
                "G": "0",
                "zip": "4701",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Grieskirchen",
                "city": "Bad Schallerbach",
                "strasse": "Welserstraße 5",
                "date": "22.8.2025",
                "time": "5:38:7"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.40058,
                    47.02883
                ]
            },
            "properties": {
                "id": "INFT-AJM2XX",
                "name": "AVANTI - Graz Weblinger Straße 41",
                "S98": "0",
                "S95": "1.433",
                "N": "0",
                "D": "1.437",
                "G": "0",
                "zip": "8054",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Graz",
                "city": "Graz",
                "strasse": "Weblinger Strasse 41",
                "date": "22.8.2025",
                "time": "5:38:27"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.3126125,
                    46.6359198
                ]
            },
            "properties": {
                "id": "INFT-AJMGD8",
                "name": "SOCAR Klagenfurt-St.Veiter-Straße",
                "S98": "0",
                "S95": "1.442",
                "N": "0",
                "D": "1.446",
                "G": "0",
                "zip": "9020",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Klagenfurt Land",
                "city": "Klagenfurt",
                "strasse": "St. Veiter Straße 94",
                "date": "22.8.2025",
                "time": "5:37:26"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.7666716,
                    47.6552697
                ]
            },
            "properties": {
                "id": "INFT-AJMGDD",
                "name": "AVIA XPress (unser Service: Luft und Wasser)",
                "S98": "0",
                "S95": "1.477",
                "N": "0",
                "D": "1.482",
                "G": "0",
                "zip": "8921",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Liezen",
                "city": "Mooslandl",
                "strasse": "Nr. 138",
                "date": "22.8.2025",
                "time": "5:38:31"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.2919418,
                    48.1301731
                ]
            },
            "properties": {
                "id": "INFT-AJML7F",
                "name": "SOCAR Perchtoldsdorf",
                "S98": "0",
                "S95": "1.429",
                "N": "0",
                "D": "1.442",
                "G": "0",
                "zip": "2380",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Mödling",
                "city": "Perchtoldsdorf",
                "strasse": "Ketzergasse 191a",
                "date": "22.8.2025",
                "time": "5:37:50"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.595071,
                    47.291649
                ]
            },
            "properties": {
                "id": "INFT-AJMTS8",
                "name": "Disk TANKAUTOMAT",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.589",
                "G": "0",
                "zip": "6112",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Innsbruck Land",
                "city": "Wattens",
                "strasse": "Salzburgerstraße 8",
                "date": "22.8.2025",
                "time": "5:38:39"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.150235,
                    47.565769
                ]
            },
            "properties": {
                "id": "INFT-AJN39T",
                "name": "INNTALER Logistik Park GmbH",
                "S98": "0",
                "S95": "1.498",
                "N": "0",
                "D": "1.498",
                "G": "0",
                "zip": "6330",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Kufstein",
                "city": "Kufstein",
                "strasse": "Endach 34",
                "date": "22.8.2025",
                "time": "5:38:43"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    10.5108575,
                    46.9531126
                ]
            },
            "properties": {
                "id": "INFT-AJNJJP",
                "name": "Disk",
                "S98": "0",
                "S95": "1.617",
                "N": "0",
                "D": "1.617",
                "G": "0",
                "zip": "6542",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Landeck",
                "city": "Pfunds",
                "strasse": "Reschenstraße 644",
                "date": "22.8.2025",
                "time": "5:38:43"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.466253,
                    48.247683
                ]
            },
            "properties": {
                "id": "INFT-AJNTT9",
                "name": "BP",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.519",
                "G": "0",
                "zip": "1220",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Donaustadt",
                "city": "Wien",
                "strasse": "Gewerbeparkstr.On1 Gew.Park Stadlau ",
                "date": "22.8.2025",
                "time": "5:39:1"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.3942247,
                    47.2533315
                ]
            },
            "properties": {
                "id": "INFT-AJNTTA",
                "name": "Unser Lagerhaus",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.595",
                "G": "0",
                "zip": "6020",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Innsbruck",
                "city": "Innsbruck",
                "strasse": "Duilestr. 20",
                "date": "22.8.2025",
                "time": "5:38:36"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.6856897,
                    48.4707896
                ]
            },
            "properties": {
                "id": "INFT-AJPCYZ",
                "name": "Loistank",
                "S98": "0",
                "S95": "1.499",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "3550",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Krems Land",
                "city": "Langenlois",
                "strasse": "Wienerstraße 42",
                "date": "22.8.2025",
                "time": "5:37:47"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.42971,
                    47.26338
                ]
            },
            "properties": {
                "id": "INFT-AJQ3EY",
                "name": "Shell Austria",
                "S98": "0",
                "S95": "1.599",
                "N": "0",
                "D": "1.599",
                "G": "0",
                "zip": "6020",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Innsbruck",
                "city": "INNSBRUCK",
                "strasse": "AMRASERSEE-STRASSE 56",
                "date": "22.8.2025",
                "time": "5:38:38"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.8808568,
                    47.2233433
                ]
            },
            "properties": {
                "id": "INFT-AJPTQT",
                "name": "Disk Tankstelle + TANKAUTOMAT",
                "S98": "0",
                "S95": "1.624",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "6284",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Schwaz",
                "city": "Ramsau",
                "strasse": "Talstrasse 25",
                "date": "22.8.2025",
                "time": "5:38:46"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.505802,
                    46.8799972
                ]
            },
            "properties": {
                "id": "INFT-AJS7ES",
                "name": "Kuss Autodienst",
                "S98": "0",
                "S95": "1.529",
                "N": "0",
                "D": "1.539",
                "G": "0",
                "zip": "9334",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "St. Veit",
                "city": "Guttaring",
                "strasse": "Christophorusweg 1",
                "date": "22.8.2025",
                "time": "5:37:30"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.0844437,
                    47.0628136
                ]
            },
            "properties": {
                "id": "INFT-AJT2YY",
                "name": "LAGERHAUS Genol Köflach ",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.439",
                "G": "0",
                "zip": "8580",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Voitsberg",
                "city": "Köflach",
                "strasse": "Bahnweg 6",
                "date": "22.8.2025",
                "time": "5:38:32"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.47347,
                    47.27348
                ]
            },
            "properties": {
                "id": "INFT-AJTTYA",
                "name": "OMV - Hall in Tirol Schlöglstraße 77",
                "S98": "0",
                "S95": "1.599",
                "N": "0",
                "D": "1.609",
                "G": "0",
                "zip": "6060",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Innsbruck Land",
                "city": "Hall in Tirol",
                "strasse": "Schlöglstrasse 77",
                "date": "22.8.2025",
                "time": "5:38:40"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.435534,
                    48.491525
                ]
            },
            "properties": {
                "id": "INFT-AJUJF4",
                "name": "LAGLER ",
                "S98": "0",
                "S95": "1.479",
                "N": "0",
                "D": "1.495",
                "G": "0",
                "zip": "3522",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Krems Land",
                "city": "Lichtenau",
                "strasse": "Loiwein 65",
                "date": "22.8.2025",
                "time": "5:37:46"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.4942357,
                    48.033501
                ]
            },
            "properties": {
                "id": "INFT-AJVMAX",
                "name": "LAGERHAUS Genol mit Tankkartensystem",
                "S98": "0",
                "S95": "1.448",
                "N": "0",
                "D": "1.458",
                "G": "0",
                "zip": "2440",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Wien Umgebung",
                "city": "Gramatneusiedl",
                "strasse": "Bahnstraße 66",
                "date": "22.8.2025",
                "time": "5:37:38"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.3184664,
                    48.1609065
                ]
            },
            "properties": {
                "id": "INFT-AJXUG5",
                "name": "BP",
                "S98": "0",
                "S95": "1.499",
                "N": "0",
                "D": "1.519",
                "G": "0",
                "zip": "1120",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Meidling",
                "city": "Wien",
                "strasse": "Altmannsdorferstr.117 ",
                "date": "22.8.2025",
                "time": "5:38:56"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.3172305,
                    48.1623607
                ]
            },
            "properties": {
                "id": "INFT-AJXUG6",
                "name": "BP",
                "S98": "0",
                "S95": "1.499",
                "N": "0",
                "D": "1.519",
                "G": "0",
                "zip": "1120",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Meidling",
                "city": "Wien",
                "strasse": "Altmannsdorferstr.94 ",
                "date": "22.8.2025",
                "time": "5:38:56"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.16222,
                    47.58636
                ]
            },
            "properties": {
                "id": "INFT-AK2TYF",
                "name": "AVANTI - Kufstein Schubertstraße 20",
                "S98": "0",
                "S95": "1.484",
                "N": "0",
                "D": "1.484",
                "G": "0",
                "zip": "6330",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Kufstein",
                "city": "Kufstein",
                "strasse": "Schubertstrasse 20",
                "date": "22.8.2025",
                "time": "5:38:43"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.3622129,
                    48.5001792
                ]
            },
            "properties": {
                "id": "INFT-AK3GJZ",
                "name": "Fa. Elmecker Martin",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.484",
                "G": "0",
                "zip": "4192",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Urfahr Umgebung",
                "city": "Schenkenfelden",
                "strasse": "Linzerstrasse 14",
                "date": "22.8.2025",
                "time": "5:38:16"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.98,
                    47.817794
                ]
            },
            "properties": {
                "id": "INFT-AK4H6H",
                "name": "Wölfl",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.439",
                "G": "0",
                "zip": "5071",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Salzburg Umgebung",
                "city": "Wals-Siezenheim",
                "strasse": "Bayernstrasse 24",
                "date": "22.8.2025",
                "time": "5:38:20"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.4770062,
                    48.3585818
                ]
            },
            "properties": {
                "id": "INFT-AK4H6P",
                "name": "Genol  Lagerhaus Pregarten-Gallneukirchen",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.469",
                "G": "0",
                "zip": "4224",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Freistadt",
                "city": "Wartberg",
                "strasse": "Betriebsstraße 20",
                "date": "22.8.2025",
                "time": "5:38:5"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.50778,
                    47.8449265
                ]
            },
            "properties": {
                "id": "INFT-AK4H6G",
                "name": "CP - so günstig wie möglich",
                "S98": "0",
                "S95": "1.447",
                "N": "0",
                "D": "1.457",
                "G": "0",
                "zip": "7000",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Eisenstadt",
                "city": "Eisenstadt",
                "strasse": "Wiener Straße 36-38",
                "date": "22.8.2025",
                "time": "5:37:19"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.3451602,
                    48.3726732
                ]
            },
            "properties": {
                "id": "INFT-AK4L39",
                "name": "Genol  Lagerhaus Pregarten-Gallneukirchen",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.469",
                "G": "0",
                "zip": "4203",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Urfahr Umgebung",
                "city": "Altenberg",
                "strasse": "Linzerstraße 20",
                "date": "22.8.2025",
                "time": "5:38:16"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.7928574,
                    47.948442
                ]
            },
            "properties": {
                "id": "INFT-AK52FA",
                "name": "Lagerhaus-Genol",
                "S98": "0",
                "S95": "1.491",
                "N": "0",
                "D": "1.497",
                "G": "0",
                "zip": "3340",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Scheibbs",
                "city": "Waidhofen/Ybbs",
                "strasse": "Ybbsitzerstraße 130",
                "date": "22.8.2025",
                "time": "5:37:36"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.9586789,
                    48.5712179
                ]
            },
            "properties": {
                "id": "INFT-AKAF59",
                "name": "Genol",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.569",
                "G": "0",
                "zip": "3920",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Zwettl",
                "city": "Gr. Gerungs",
                "strasse": "Kreuzberg   112",
                "date": "22.8.2025",
                "time": "5:37:58"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.070968,
                    48.520897
                ]
            },
            "properties": {
                "id": "INFT-AKAGHR",
                "name": "Genol",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.569",
                "G": "0",
                "zip": "3911",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Zwettl",
                "city": "Rappottenstein",
                "strasse": "Grünbach  20",
                "date": "22.8.2025",
                "time": "5:37:58"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.9521204,
                    48.492093
                ]
            },
            "properties": {
                "id": "INFT-AKB3DH",
                "name": "Genol",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.569",
                "G": "0",
                "zip": "3925",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Zwettl",
                "city": "Arbesbach",
                "strasse": "Linzerstraße  99",
                "date": "22.8.2025",
                "time": "5:37:58"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.8846694,
                    48.5767039
                ]
            },
            "properties": {
                "id": "INFT-AKB3DG",
                "name": "Genol",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.569",
                "G": "0",
                "zip": "3921",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Zwettl",
                "city": "Langschlag",
                "strasse": "Bahnhofstraße  136",
                "date": "22.8.2025",
                "time": "5:37:58"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.3059831,
                    48.4175608
                ]
            },
            "properties": {
                "id": "INFT-AKBFBJ",
                "name": "Genol",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.529",
                "G": "0",
                "zip": "3623",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Zwettl",
                "city": "Kottes",
                "strasse": "Kottes  75",
                "date": "22.8.2025",
                "time": "5:37:57"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.880056,
                    48.284471
                ]
            },
            "properties": {
                "id": "INFT-AKGGA6",
                "name": "GENOL-LH EFERDING-OÖ. MITTE eGen",
                "S98": "0",
                "S95": "1.469",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "4732",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Grieskirchen",
                "city": "ST. THOMAS BEI WAIZENKIRCHEN",
                "strasse": "ST. THOMAS 34",
                "date": "22.8.2025",
                "time": "5:38:8"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.4362911,
                    48.4186387
                ]
            },
            "properties": {
                "id": "INFT-AKGG9V",
                "name": "Land lebt auf Suben Gmbh",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.489",
                "G": "0",
                "zip": "4975",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Schärding",
                "city": "Suben",
                "strasse": "Schnelldorf 60",
                "date": "22.8.2025",
                "time": "5:38:14"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.0436211,
                    48.9432285
                ]
            },
            "properties": {
                "id": "INFT-AKGGA5",
                "name": "AVIA XPress (unser Service: Luft und Wasser)",
                "S98": "0",
                "S95": "1.559",
                "N": "0",
                "D": "1.579",
                "G": "0",
                "zip": "3874",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Gmünd",
                "city": "Litschau",
                "strasse": "Bahnhofstraße 4",
                "date": "22.8.2025",
                "time": "5:37:42"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.2552517,
                    47.070226
                ]
            },
            "properties": {
                "id": "INFT-AKH3HP",
                "name": "LAGERHAUS Genol St. Bartholomä",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.439",
                "G": "0",
                "zip": "8113",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Graz Umgebung",
                "city": "St. Bartholomä",
                "strasse": "St. Bartholomä 59",
                "date": "22.8.2025",
                "time": "5:38:27"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.1517289,
                    47.4526716
                ]
            },
            "properties": {
                "id": "INFT-AKHMD3",
                "name": "LAGERHAUS   Hopfgarten - Wörgl und Umgebung reg.Gen.m.b.H.",
                "S98": "0",
                "S95": "1.519",
                "N": "0",
                "D": "1.553",
                "G": "0",
                "zip": "6361",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Kitzbühel",
                "city": "Hopfgarten",
                "strasse": "Bahnhofstr. 7",
                "date": "22.8.2025",
                "time": "5:38:41"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.86411,
                    47.514998
                ]
            },
            "properties": {
                "id": "INFT-AKN3A7",
                "name": "Geist Transporte",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.539",
                "G": "0",
                "zip": "6934",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Bregenz",
                "city": "Sulzberg",
                "strasse": "Fahl 125",
                "date": "22.8.2025",
                "time": "5:38:48"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.9094319,
                    47.5205385
                ]
            },
            "properties": {
                "id": "INFT-AKNGQ7",
                "name": "Geist Transporte",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.539",
                "G": "0",
                "zip": "6934",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Bregenz",
                "city": "Sulzberg",
                "strasse": "Widum 235",
                "date": "22.8.2025",
                "time": "5:38:48"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.804691,
                    47.172211
                ]
            },
            "properties": {
                "id": "INFT-AKRMER",
                "name": "Durlacher Peter Freie Tankstelle",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.459",
                "G": "0",
                "zip": "8212",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Weiz",
                "city": "Pischelsdorf",
                "strasse": "Pischelsdorf 55",
                "date": "22.8.2025",
                "time": "5:38:33"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.90395,
                    47.9107899
                ]
            },
            "properties": {
                "id": "INFT-AKS3RE",
                "name": "Müller Tankstellen GesmbH",
                "S98": "0",
                "S95": "1.478",
                "N": "0",
                "D": "1.498",
                "G": "0",
                "zip": "4817",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Gmunden",
                "city": "St. Konrad",
                "strasse": "Bundesstraße 15",
                "date": "22.8.2025",
                "time": "5:38:6"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.1370813,
                    48.0719143
                ]
            },
            "properties": {
                "id": "INFT-AKS3RL",
                "name": "Disk Eisinger",
                "S98": "0",
                "S95": "1.477",
                "N": "0",
                "D": "1.487",
                "G": "0",
                "zip": "3251",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Scheibbs",
                "city": "Purgstall an der Erlauf",
                "strasse": "Erlauftalstraße 86",
                "date": "22.8.2025",
                "time": "5:37:53"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.5085973,
                    48.3769919
                ]
            },
            "properties": {
                "id": "INFT-AKYJ43",
                "name": "GENOL",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "2120",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Mistelbach",
                "city": "Wolkersdorf",
                "strasse": "Winzerstraße 3",
                "date": "22.8.2025",
                "time": "5:37:49"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.4888098,
                    48.4263346
                ]
            },
            "properties": {
                "id": "INFT-AKYJ44",
                "name": "GENOL",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "2123",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Mistelbach",
                "city": "Schleinbach",
                "strasse": "Landstraße 360",
                "date": "22.8.2025",
                "time": "5:37:49"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.659578,
                    48.4431738
                ]
            },
            "properties": {
                "id": "INFT-AL6FYK",
                "name": "Lagerhaus Genol",
                "S98": "0",
                "S95": "1.499",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "4794",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Schärding",
                "city": "Kopfing",
                "strasse": "Sportplatzstrasse 121",
                "date": "22.8.2025",
                "time": "5:38:15"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.5658676,
                    48.3664201
                ]
            },
            "properties": {
                "id": "INFT-AL6FYH",
                "name": "Lagerhaus Genol",
                "S98": "0",
                "S95": "1.499",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "4770",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Schärding",
                "city": "Andorf",
                "strasse": "Hauptstrasse 75",
                "date": "22.8.2025",
                "time": "5:38:15"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.7377153,
                    48.4781749
                ]
            },
            "properties": {
                "id": "INFT-AL6FYM",
                "name": "Lagerhaus Genol",
                "S98": "0",
                "S95": "1.499",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "4725",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Schärding",
                "city": "St. Aegidi",
                "strasse": "St. Aegidi 29",
                "date": "22.8.2025",
                "time": "5:38:15"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.6676972,
                    48.3469
                ]
            },
            "properties": {
                "id": "INFT-AL75UX",
                "name": "Genol  Lagerhaus Pregarten-Gallneukirchen",
                "S98": "0",
                "S95": "1.494",
                "N": "0",
                "D": "1.474",
                "G": "0",
                "zip": "4283",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Freistadt",
                "city": "Bad Zell",
                "strasse": "Linzer Straße 11",
                "date": "22.8.2025",
                "time": "5:38:6"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.9733529,
                    47.7877589
                ]
            },
            "properties": {
                "id": "INFT-AM2FU2",
                "name": "Lagerhaus-Tankstelle 24 h",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "5071",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Salzburg Umgebung",
                "city": "Wals",
                "strasse": "Lagerhausstrasse 2",
                "date": "22.8.2025",
                "time": "5:38:21"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.4047107,
                    47.7366435
                ]
            },
            "properties": {
                "id": "INFT-AM4CLG",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.464",
                "N": "0",
                "D": "1.482",
                "G": "0",
                "zip": "7210",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Mattersburg",
                "city": "Mattersburg",
                "strasse": "Bahnstraße 30",
                "date": "22.8.2025",
                "time": "5:37:21"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.2274847,
                    46.8187066
                ]
            },
            "properties": {
                "id": "INFT-AMBF5Y",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.434",
                "N": "0",
                "D": "1.454",
                "G": "0",
                "zip": "8530",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Deutschlandsberg",
                "city": "Deutschlandsberg",
                "strasse": "Frauentaler Straße 76",
                "date": "22.8.2025",
                "time": "5:38:26"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.3486869,
                    47.8534393
                ]
            },
            "properties": {
                "id": "INFT-AMMJQJ",
                "name": "Tankstelle Mondsee",
                "S98": "0",
                "S95": "1.479",
                "N": "0",
                "D": "1.474",
                "G": "0",
                "zip": "5310",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Vöcklabruck",
                "city": "Mondsee",
                "strasse": "Franz Kreutzbergerstraße  9",
                "date": "22.8.2025",
                "time": "5:38:17"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.5973356,
                    48.4708909
                ]
            },
            "properties": {
                "id": "INFT-AN3EPU",
                "name": "Lagerhaus - Genol",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.494",
                "G": "0",
                "zip": "3552",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Krems Land",
                "city": "Lengenfeld",
                "strasse": "Kirchengasse 3",
                "date": "22.8.2025",
                "time": "5:37:46"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.6903453,
                    48.4325584
                ]
            },
            "properties": {
                "id": "INFT-AN3EPW",
                "name": "Lagerhaus - Genol",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.494",
                "G": "0",
                "zip": "3494",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Krems Land",
                "city": "Gedersdorf",
                "strasse": "Linke Bahnzeile 2",
                "date": "22.8.2025",
                "time": "5:37:46"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.6912918,
                    48.4711342
                ]
            },
            "properties": {
                "id": "INFT-AN3EPV",
                "name": "Lagerhaus - Genol",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.494",
                "G": "0",
                "zip": "3550",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Krems Land",
                "city": "Langenlois",
                "strasse": "Gewerbestrasse 8-12",
                "date": "22.8.2025",
                "time": "5:37:46"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.132146,
                    47.591636
                ]
            },
            "properties": {
                "id": "INFT-AN3EPZ",
                "name": "INN-TANK",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.498",
                "G": "0",
                "zip": "6335",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Kufstein",
                "city": "Thiersee",
                "strasse": "Breiten 2",
                "date": "22.8.2025",
                "time": "5:38:42"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.677582,
                    47.373695
                ]
            },
            "properties": {
                "id": "INFT-ANPLGH",
                "name": "BP",
                "S98": "0",
                "S95": "1.529",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "6845",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Dornbirn",
                "city": "Hohenems",
                "strasse": "Lustenauer Strasse 112a ",
                "date": "22.8.2025",
                "time": "5:38:50"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.4509,
                    46.6396
                ]
            },
            "properties": {
                "id": "INFT-AP8FKB",
                "name": "OMV - Grafenstein Dolina 36",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.489",
                "G": "0",
                "zip": "9131",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Klagenfurt Land",
                "city": "Grafenstein",
                "strasse": "Dolina 36",
                "date": "22.8.2025",
                "time": "5:37:29"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.8794874,
                    48.5044768
                ]
            },
            "properties": {
                "id": "INFT-AQ3CNN",
                "name": "BP - Lagerhaus ",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "4134",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Rohrbach",
                "city": "Putzleinsdorf ",
                "strasse": "Glotzing 20",
                "date": "22.8.2025",
                "time": "5:38:14"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    10.289706,
                    47.139757
                ]
            },
            "properties": {
                "id": "INFT-AQYFVV",
                "name": "Gutmann ENI Tankstelle ",
                "S98": "0",
                "S95": "1.677",
                "N": "0",
                "D": "1.699",
                "G": "0",
                "zip": "6580",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Landeck",
                "city": "Sankt Anton ",
                "strasse": "Gewerbegebiet 16",
                "date": "22.8.2025",
                "time": "5:38:44"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.661951500031934,
                    47.16207428098524
                ]
            },
            "properties": {
                "id": "INFT-ARDBUA",
                "name": "F. LEITNER",
                "S98": "0",
                "S95": "1.458",
                "N": "0",
                "D": "1.458",
                "G": "0",
                "zip": "8181",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Weiz",
                "city": "St.Ruprecht",
                "strasse": "Obere Haupstraße 384",
                "date": "22.8.2025",
                "time": "5:38:34"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.7363227,
                    47.161529
                ]
            },
            "properties": {
                "id": "INFT-AS7CEU",
                "name": "Freie Tankstelle",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.429",
                "G": "0",
                "zip": "8741",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Judenburg",
                "city": "Weißkirchen",
                "strasse": "Fisching 45",
                "date": "22.8.2025",
                "time": "5:38:35"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.68,
                    46.69
                ]
            },
            "properties": {
                "id": "INFT-ASP3S7",
                "name": "ENI",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.489",
                "G": "0",
                "zip": "9710",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Villach Land",
                "city": "Neu-Feffernitz",
                "strasse": "Drautalstrasse 14",
                "date": "22.8.2025",
                "time": "5:37:31"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.4176861,
                    47.4482398
                ]
            },
            "properties": {
                "id": "INFT-ASVFV6",
                "name": "TURMÖL",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "7373",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Oberpullendorf",
                "city": "Piringsdorf",
                "strasse": "Bundesstraße 50",
                "date": "22.8.2025",
                "time": "5:37:24"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.5015729,
                    46.8878741
                ]
            },
            "properties": {
                "id": "INFT-AT3TXP",
                "name": "Treibstoffparadies",
                "S98": "0",
                "S95": "1.449",
                "N": "0",
                "D": "1.453",
                "G": "0",
                "zip": "8410",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Leibnitz",
                "city": "Wildon",
                "strasse": "Grazerstraße 2",
                "date": "22.8.2025",
                "time": "5:38:28"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.482978,
                    48.205796
                ]
            },
            "properties": {
                "id": "INFT-ATKJ9K",
                "name": "AVIA Xpress (Automaten-Tankstelle)",
                "S98": "0",
                "S95": "1.474",
                "N": "0",
                "D": "1.484",
                "G": "0",
                "zip": "4910",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Ried",
                "city": "Ried im Innkreis",
                "strasse": "Braunauer Straße 3a",
                "date": "22.8.2025",
                "time": "5:38:13"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.4265899,
                    47.0591358
                ]
            },
            "properties": {
                "id": "INFT-ATLCKW",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.432",
                "N": "0",
                "D": "1.436",
                "G": "0",
                "zip": "8020",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Graz",
                "city": "Graz",
                "strasse": "Fabrikgasse 29",
                "date": "22.8.2025",
                "time": "5:38:25"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.1769673,
                    46.6589993
                ]
            },
            "properties": {
                "id": "INFT-ATLKD5",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.457",
                "N": "0",
                "D": "1.459",
                "G": "0",
                "zip": "9062",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Feldkirchen",
                "city": "Moosburg",
                "strasse": "Klagenfurterstraße 21",
                "date": "22.8.2025",
                "time": "5:37:28"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.6076839,
                    46.5800719
                ]
            },
            "properties": {
                "id": "INFT-ATLMUG",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.488",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "9613",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Villach Land",
                "city": "Feistritz/Gail",
                "strasse": "Gail 159",
                "date": "22.8.2025",
                "time": "5:37:31"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    10.7356,
                    47.218065
                ]
            },
            "properties": {
                "id": "INFT-ATSHWH",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.589",
                "N": "0",
                "D": "1.589",
                "G": "0",
                "zip": "6460",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Imst",
                "city": "IMST",
                "strasse": "INDUSTRIEZONE 33",
                "date": "22.8.2025",
                "time": "5:38:39"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.679413,
                    47.47757
                ]
            },
            "properties": {
                "id": "INFT-ATSHWJ",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.568",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "6971",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Bregenz",
                "city": "HARD",
                "strasse": "RHEINSTRASSE 99",
                "date": "22.8.2025",
                "time": "5:38:49"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.370664,
                    46.634892
                ]
            },
            "properties": {
                "id": "INFT-ATSHX2",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.443",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "9020",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Klagenfurt Land",
                "city": "KLAGENFURT",
                "strasse": "GÖRTSCHITZTALSTR. 20",
                "date": "22.8.2025",
                "time": "5:37:26"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.421146,
                    48.037385
                ]
            },
            "properties": {
                "id": "INFT-ATSHXJ",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.437",
                "N": "0",
                "D": "1.465",
                "G": "0",
                "zip": "4400",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Steyr Land",
                "city": "STEYR",
                "strasse": "DUKARTSTRASSE 19 B",
                "date": "22.8.2025",
                "time": "5:38:1"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.258505,
                    47.560379
                ]
            },
            "properties": {
                "id": "INFT-ATSHXE",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.469",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "8940",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Liezen",
                "city": "LIEZEN",
                "strasse": "GESÄUSESTRASSE 33",
                "date": "22.8.2025",
                "time": "5:38:31"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.426062,
                    48.252498
                ]
            },
            "properties": {
                "id": "INFT-ATSHX9",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.438",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "1210",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Floridsdorf",
                "city": "WIEN",
                "strasse": "DONAUFELDER STRASSE 135",
                "date": "22.8.2025",
                "time": "5:39:1"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.731134,
                    47.39649
                ]
            },
            "properties": {
                "id": "INFT-ATSHWM",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.499",
                "N": "0",
                "D": "1.518",
                "G": "0",
                "zip": "6850",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Dornbirn",
                "city": "DORNBIRN",
                "strasse": "WALLENMAHD 22",
                "date": "22.8.2025",
                "time": "5:38:50"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.617957,
                    48.189512
                ]
            },
            "properties": {
                "id": "INFT-ATSHWE",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.449",
                "N": "0",
                "D": "1.477",
                "G": "0",
                "zip": "3100",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "St. Pölten",
                "city": "ST PÖLTEN",
                "strasse": "MARIAZELLERSTRASSE 91",
                "date": "22.8.2025",
                "time": "5:37:36"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.3708,
                    48.22588
                ]
            },
            "properties": {
                "id": "INFT-ATSHWS",
                "name": "AVANTI - Wien Gaussplatz 1",
                "S98": "0",
                "S95": "1.529",
                "N": "0",
                "D": "1.544",
                "G": "0",
                "zip": "1020",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Leopoldstadt",
                "city": "Wien",
                "strasse": "Gaussplatz 1",
                "date": "22.8.2025",
                "time": "5:38:52"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.822187,
                    46.751579
                ]
            },
            "properties": {
                "id": "INFT-ATSHWR",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.484",
                "N": "0",
                "D": "1.484",
                "G": "0",
                "zip": "9433",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Wolfsberg",
                "city": "ST ANDRÄ",
                "strasse": "BURGSTALL 151",
                "date": "22.8.2025",
                "time": "5:37:33"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.41139,
                    48.25895
                ]
            },
            "properties": {
                "id": "INFT-ATSHX7",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.438",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "1210",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Floridsdorf",
                "city": "WIEN",
                "strasse": "LEOPOLDAUERSTRASSE 40",
                "date": "22.8.2025",
                "time": "5:39:1"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.839675,
                    46.82661
                ]
            },
            "properties": {
                "id": "INFT-ATSHWQ",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.484",
                "N": "0",
                "D": "1.484",
                "G": "0",
                "zip": "9400",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Wolfsberg",
                "city": "WOLFSBERG",
                "strasse": "KLAGENFURTER STRASSE 19 B",
                "date": "22.8.2025",
                "time": "5:37:33"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.38404,
                    48.28664
                ]
            },
            "properties": {
                "id": "INFT-ATSHX8",
                "name": "AVANTI - Wien Prager Straße 270-272",
                "S98": "0",
                "S95": "1.435",
                "N": "0",
                "D": "1.452",
                "G": "0",
                "zip": "1210",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Floridsdorf",
                "city": "Wien",
                "strasse": "Prager Strasse 270-272",
                "date": "22.8.2025",
                "time": "5:39:1"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.814175,
                    47.152278
                ]
            },
            "properties": {
                "id": "INFT-ATSHWY",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.479",
                "N": "0",
                "D": "1.519",
                "G": "0",
                "zip": "6706",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Bludenz",
                "city": "BUERS",
                "strasse": "HERRENAU 1",
                "date": "22.8.2025",
                "time": "5:38:47"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.040511,
                    47.711667
                ]
            },
            "properties": {
                "id": "INFT-ATSHWB",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.509",
                "N": "0",
                "D": "1.529",
                "G": "0",
                "zip": "2630",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Neunkirchen",
                "city": "TERNITZ",
                "strasse": "WERKSTRASSE 14",
                "date": "22.8.2025",
                "time": "5:37:52"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.459643,
                    48.168847
                ]
            },
            "properties": {
                "id": "INFT-ATSHY2",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.438",
                "N": "0",
                "D": "1.458",
                "G": "0",
                "zip": "1110",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Simmering",
                "city": "WIEN",
                "strasse": "JEDLETZBERGERSTRASSE 18",
                "date": "22.8.2025",
                "time": "5:38:55"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    10.581303,
                    47.150185
                ]
            },
            "properties": {
                "id": "INFT-ATSHZ6",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.589",
                "N": "0",
                "D": "1.589",
                "G": "0",
                "zip": "6500",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Landeck",
                "city": "LANDECK",
                "strasse": "BAHNHOFSTR. 26",
                "date": "22.8.2025",
                "time": "5:38:43"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.211228,
                    47.805343
                ]
            },
            "properties": {
                "id": "INFT-ATSHYT",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.506",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "2700",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Wiener Neustadt Land",
                "city": "WIENER NEUSTADT",
                "strasse": "PUCHBERGER STRASSE 1",
                "date": "22.8.2025",
                "time": "5:37:37"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.34549,
                    48.28511
                ]
            },
            "properties": {
                "id": "INFT-ATSHYX",
                "name": "AVANTI - Wien Heiligenstädter Straße 196",
                "S98": "0",
                "S95": "1.624",
                "N": "0",
                "D": "1.639",
                "G": "0",
                "zip": "1190",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Döbling",
                "city": "Wien",
                "strasse": "Heiligenstädter Strasse 196",
                "date": "22.8.2025",
                "time": "5:38:59"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.239466,
                    47.798555
                ]
            },
            "properties": {
                "id": "INFT-ATSHYS",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.505",
                "N": "0",
                "D": "1.52",
                "G": "0",
                "zip": "2700",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Wiener Neustadt Land",
                "city": "WIENER NEUSTADT",
                "strasse": "GÜNSER STRASSE 92",
                "date": "22.8.2025",
                "time": "5:37:37"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.01488,
                    47.801351
                ]
            },
            "properties": {
                "id": "INFT-ATSHYC",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.488",
                "N": "0",
                "D": "1.516",
                "G": "0",
                "zip": "5020",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Salzburg Umgebung",
                "city": "SALZBURG",
                "strasse": "INNSBRUCKER BUNDESSTRASSE 65",
                "date": "22.8.2025",
                "time": "5:38:18"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.349681,
                    48.217896
                ]
            },
            "properties": {
                "id": "INFT-ATSHY8",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.455",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "3390",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Melk",
                "city": "MELK",
                "strasse": "SCHLITPACHERSTRASSE 2",
                "date": "22.8.2025",
                "time": "5:37:49"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    10.56352,
                    47.14163
                ]
            },
            "properties": {
                "id": "INFT-ATSHZ8",
                "name": "AVANTI - Landeck Innstrasse 38",
                "S98": "0",
                "S95": "1.584",
                "N": "0",
                "D": "1.584",
                "G": "0",
                "zip": "6500",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Landeck",
                "city": "Landeck",
                "strasse": "Innstrasse 38",
                "date": "22.8.2025",
                "time": "5:38:43"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.43266,
                    48.159966
                ]
            },
            "properties": {
                "id": "INFT-ATSHXX",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.438",
                "N": "0",
                "D": "1.458",
                "G": "0",
                "zip": "1110",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Simmering",
                "city": "WIEN",
                "strasse": "SIMMERINGER HAUPTSTRASSE 275",
                "date": "22.8.2025",
                "time": "5:38:55"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.410194,
                    48.16679
                ]
            },
            "properties": {
                "id": "INFT-ATSHXZ",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.426",
                "N": "0",
                "D": "1.446",
                "G": "0",
                "zip": "1110",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Simmering",
                "city": "WIEN",
                "strasse": "GADNERGASSE 6",
                "date": "22.8.2025",
                "time": "5:38:54"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.848953,
                    46.59817
                ]
            },
            "properties": {
                "id": "INFT-ATSHYF",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.459",
                "N": "0",
                "D": "1.459",
                "G": "0",
                "zip": "9500",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Villach",
                "city": "VILLACH",
                "strasse": "KARAWANKENWEG 18",
                "date": "22.8.2025",
                "time": "5:37:27"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.31949,
                    48.1724
                ]
            },
            "properties": {
                "id": "INFT-ATSHYH",
                "name": "AVANTI - Wien Edelsinnstraße 16",
                "S98": "0",
                "S95": "1.524",
                "N": "0",
                "D": "1.534",
                "G": "0",
                "zip": "1120",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Meidling",
                "city": "Wien",
                "strasse": "Edelsinnstrasse 66",
                "date": "22.8.2025",
                "time": "5:38:56"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.06908,
                    48.79281
                ]
            },
            "properties": {
                "id": "INFT-ATSHZ5",
                "name": "AVANTI - Schrems Josef Widy-Straße 2",
                "S98": "0",
                "S95": "1.559",
                "N": "0",
                "D": "1.579",
                "G": "0",
                "zip": "3943",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Gmünd",
                "city": "Schrems",
                "strasse": "Josef Widy-Strasse 2",
                "date": "22.8.2025",
                "time": "5:37:42"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.365198,
                    48.165249
                ]
            },
            "properties": {
                "id": "INFT-ATSHXV",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.446",
                "N": "0",
                "D": "1.457",
                "G": "0",
                "zip": "1100",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Favoriten",
                "city": "WIEN",
                "strasse": "RAXSTRASSE 5",
                "date": "22.8.2025",
                "time": "5:38:53"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.103615,
                    47.684607
                ]
            },
            "properties": {
                "id": "INFT-ATSHZ3",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.466",
                "N": "0",
                "D": "1.509",
                "G": "0",
                "zip": "5400",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Hallein",
                "city": "HALLEIN",
                "strasse": "EUROPASTRASSE 8",
                "date": "22.8.2025",
                "time": "5:38:19"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.610381,
                    47.247387
                ]
            },
            "properties": {
                "id": "INFT-ATSHXP",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.479",
                "N": "0",
                "D": "1.489",
                "G": "0",
                "zip": "6800",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Feldkirch",
                "city": "FELDKIRCH",
                "strasse": "REICHSSTRASSE 133 A",
                "date": "22.8.2025",
                "time": "5:38:51"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.37535,
                    48.24309
                ]
            },
            "properties": {
                "id": "INFT-ATSHYK",
                "name": "OMV - Wien Adalbert Stifter-Straße 67",
                "S98": "0",
                "S95": "1.589",
                "N": "0",
                "D": "1.629",
                "G": "0",
                "zip": "1200",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Brigittenau",
                "city": "Wien",
                "strasse": "Adalbert Stifter-Strasse 67",
                "date": "22.8.2025",
                "time": "5:39:0"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.073274,
                    48.579845
                ]
            },
            "properties": {
                "id": "INFT-ATSHZ2",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.487",
                "N": "0",
                "D": "1.517",
                "G": "0",
                "zip": "2020",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Hollabrunn",
                "city": "HOLLABRUNN",
                "strasse": "FACHLEUTNERSTRASSE 1",
                "date": "22.8.2025",
                "time": "5:37:43"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.34598,
                    48.17824
                ]
            },
            "properties": {
                "id": "INFT-ATSHYG",
                "name": "AVANTI - Wien Eichenstraße 3a",
                "S98": "0",
                "S95": "1.524",
                "N": "0",
                "D": "1.534",
                "G": "0",
                "zip": "1120",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Meidling",
                "city": "Wien",
                "strasse": "Eichenstrasse 3a",
                "date": "22.8.2025",
                "time": "5:38:56"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.656679,
                    47.344695
                ]
            },
            "properties": {
                "id": "INFT-ATSHXN",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "6840",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Feldkirch",
                "city": "GÖTZIS",
                "strasse": "LUSTENAUERSTRASSE 2",
                "date": "22.8.2025",
                "time": "5:38:51"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.463353,
                    48.216082
                ]
            },
            "properties": {
                "id": "INFT-ATSHYV",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.418",
                "N": "0",
                "D": "1.444",
                "G": "0",
                "zip": "4470",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Linz Land",
                "city": "ENNS",
                "strasse": "AM RÖMERFELD 1",
                "date": "22.8.2025",
                "time": "5:38:10"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.28135,
                    48.1953
                ]
            },
            "properties": {
                "id": "INFT-ATSHXR",
                "name": "AVANTI - Wien Guldengasse 13",
                "S98": "0",
                "S95": "1.456",
                "N": "0",
                "D": "1.467",
                "G": "0",
                "zip": "1140",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Penzing",
                "city": "Wien",
                "strasse": "Guldengasse 13",
                "date": "22.8.2025",
                "time": "5:38:57"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.289516,
                    48.130709
                ]
            },
            "properties": {
                "id": "INFT-ATSHYL",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.429",
                "N": "0",
                "D": "1.446",
                "G": "0",
                "zip": "1230",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Liesing",
                "city": "WIEN",
                "strasse": "KETZERGASSE 208",
                "date": "22.8.2025",
                "time": "5:39:3"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.460684,
                    48.238087
                ]
            },
            "properties": {
                "id": "INFT-ATSHYZ",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.447",
                "N": "0",
                "D": "1.463",
                "G": "0",
                "zip": "1220",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Donaustadt",
                "city": "WIEN",
                "strasse": "HIRSCHSTETTNERSTRASSE 52",
                "date": "22.8.2025",
                "time": "5:39:2"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.60983,
                    48.04857
                ]
            },
            "properties": {
                "id": "INFT-ATSHY5",
                "name": "AVANTI - Traisen Mariazeller Straße 38a",
                "S98": "0",
                "S95": "1.436",
                "N": "0",
                "D": "1.446",
                "G": "0",
                "zip": "3160",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Lilienfeld",
                "city": "Traisen",
                "strasse": "Mariazeller Strasse 38a",
                "date": "22.8.2025",
                "time": "5:37:47"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.018664,
                    47.817898
                ]
            },
            "properties": {
                "id": "INFT-ATSHYD",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.519",
                "G": "0",
                "zip": "5020",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Salzburg Umgebung",
                "city": "SALZBURG",
                "strasse": "MÜNCHNER BUNDESSTR. 15",
                "date": "22.8.2025",
                "time": "5:38:18"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.557541,
                    46.804627
                ]
            },
            "properties": {
                "id": "INFT-ATSMQ6",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.449",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "8431",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Leibnitz",
                "city": "GRALLA",
                "strasse": "GEWERBEPARK NORD 3",
                "date": "22.8.2025",
                "time": "5:38:28"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.682149,
                    47.18312
                ]
            },
            "properties": {
                "id": "INFT-ATSMQB",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.457",
                "N": "0",
                "D": "1.462",
                "G": "0",
                "zip": "8753",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Judenburg",
                "city": "FOHNSDORF",
                "strasse": "MURWEG 3",
                "date": "22.8.2025",
                "time": "5:38:36"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.42537,
                    47.26533
                ]
            },
            "properties": {
                "id": "INFT-ATSMR7",
                "name": "AVANTI - Innsbruck Andechsstraße West 86",
                "S98": "0",
                "S95": "1.589",
                "N": "0",
                "D": "1.589",
                "G": "0",
                "zip": "6020",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Innsbruck",
                "city": "Innsbruck",
                "strasse": "Andechsstrasse West 86",
                "date": "22.8.2025",
                "time": "5:38:37"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.01891,
                    48.25451
                ]
            },
            "properties": {
                "id": "INFT-ATSMQE",
                "name": "AVANTI - Sieghartskirchen Wiener Straße 26",
                "S98": "0",
                "S95": "1.427",
                "N": "0",
                "D": "1.441",
                "G": "0",
                "zip": "3443",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Wien Umgebung",
                "city": "Sieghartskirchen",
                "strasse": "Wiener Strasse 26",
                "date": "22.8.2025",
                "time": "5:37:55"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.20603,
                    47.8065
                ]
            },
            "properties": {
                "id": "INFT-ATSMR2",
                "name": "AVANTI - Wiener Neustadt Puchberger Straße 44",
                "S98": "0",
                "S95": "1.501",
                "N": "0",
                "D": "1.516",
                "G": "0",
                "zip": "2700",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Wiener Neustadt Land",
                "city": "Wiener Neustadt",
                "strasse": "Puchberger Strasse 44",
                "date": "22.8.2025",
                "time": "5:37:37"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.16551,
                    48.21888
                ]
            },
            "properties": {
                "id": "INFT-ATSMPW",
                "name": "AVANTI - Gablitz Linzer Straße 1a",
                "S98": "0",
                "S95": "1.441",
                "N": "0",
                "D": "1.453",
                "G": "0",
                "zip": "3003",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Wien Umgebung",
                "city": "Gablitz",
                "strasse": "Linzer Strasse 1a",
                "date": "22.8.2025",
                "time": "5:37:52"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.68864,
                    47.55139
                ]
            },
            "properties": {
                "id": "INFT-ATSMQS",
                "name": "AVANTI - Achenkirch 588",
                "S98": "0",
                "S95": "1.594",
                "N": "0",
                "D": "1.594",
                "G": "0",
                "zip": "6215",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Schwaz",
                "city": "Achenkirch",
                "strasse": "Achenkirch 588",
                "date": "22.8.2025",
                "time": "5:38:46"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.521694,
                    47.829222
                ]
            },
            "properties": {
                "id": "INFT-ATSMPY",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.459",
                "N": "0",
                "D": "1.472",
                "G": "0",
                "zip": "7000",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Eisenstadt",
                "city": "EISENSTADT",
                "strasse": "MATTERSBURGERSTR. 48",
                "date": "22.8.2025",
                "time": "5:37:20"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.259575,
                    46.888042
                ]
            },
            "properties": {
                "id": "INFT-ATSMQN",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.439",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "8510",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Deutschlandsberg",
                "city": "STAINZ",
                "strasse": "RADLPASSSTRASSE 10",
                "date": "22.8.2025",
                "time": "5:38:26"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.51461,
                    48.2145
                ]
            },
            "properties": {
                "id": "INFT-ATSMR5",
                "name": "AVANTI - Wien Esslinger Hauptstraße 32",
                "S98": "0",
                "S95": "1.442",
                "N": "0",
                "D": "1.458",
                "G": "0",
                "zip": "1220",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Donaustadt",
                "city": "Wien",
                "strasse": "Esslinger Hauptstrasse 32",
                "date": "22.8.2025",
                "time": "5:39:2"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.75495,
                    47.4541
                ]
            },
            "properties": {
                "id": "INFT-ATSMQ3",
                "name": "OMV - Wolfurt Dornbirner Straße 22",
                "S98": "0",
                "S95": "1.519",
                "N": "0",
                "D": "1.539",
                "G": "0",
                "zip": "6922",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Bregenz",
                "city": "Wolfurt",
                "strasse": "Dornbirner Strasse 22",
                "date": "22.8.2025",
                "time": "5:38:49"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.510506,
                    46.791491
                ]
            },
            "properties": {
                "id": "INFT-ATSMQC",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.477",
                "N": "0",
                "D": "1.477",
                "G": "0",
                "zip": "9800",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Spittal",
                "city": "SPITTAL",
                "strasse": "VILLACHER STRASSE 54",
                "date": "22.8.2025",
                "time": "5:37:31"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.13914,
                    48.06215
                ]
            },
            "properties": {
                "id": "INFT-ATSMQT",
                "name": "AVANTI - Purgstall Erlauftalstraße 34",
                "S98": "0",
                "S95": "1.474",
                "N": "0",
                "D": "1.484",
                "G": "0",
                "zip": "3251",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Scheibbs",
                "city": "Purgstall",
                "strasse": "Erlauftalstrasse 34",
                "date": "22.8.2025",
                "time": "5:37:53"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.46228,
                    48.14844
                ]
            },
            "properties": {
                "id": "INFT-ATSMQR",
                "name": "AVANTI - Wien Simmeringer Hauptstraße 489",
                "S98": "0",
                "S95": "1.433",
                "N": "0",
                "D": "1.453",
                "G": "0",
                "zip": "1110",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Simmering",
                "city": "Wien",
                "strasse": "Simmeringer Hauptstrasse 489",
                "date": "22.8.2025",
                "time": "5:38:54"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.639891,
                    47.204711
                ]
            },
            "properties": {
                "id": "INFT-ATSMQW",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.459",
                "N": "0",
                "D": "1.459",
                "G": "0",
                "zip": "8160",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Weiz",
                "city": "PREDING BEI WEIZ",
                "strasse": "BUNDESSTRASSE 7",
                "date": "22.8.2025",
                "time": "5:38:34"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.704419,
                    47.111991
                ]
            },
            "properties": {
                "id": "INFT-ATSMQV",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.459",
                "N": "0",
                "D": "1.459",
                "G": "0",
                "zip": "8200",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Weiz",
                "city": "GLEISDORF",
                "strasse": "WEIZER STRASSE 50",
                "date": "22.8.2025",
                "time": "5:38:34"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.56957,
                    48.30043
                ]
            },
            "properties": {
                "id": "INFT-ATSMQP",
                "name": "AVANTI - Deutsch-Wagram Gänserndorfer Straße 40",
                "S98": "0",
                "S95": "1.442",
                "N": "0",
                "D": "1.458",
                "G": "0",
                "zip": "2232",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Gänserndorf",
                "city": "Deutsch-Wagram",
                "strasse": "Gänserndorfer Strasse 40",
                "date": "22.8.2025",
                "time": "5:37:41"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.69817,
                    48.47614
                ]
            },
            "properties": {
                "id": "INFT-ATSMQJ",
                "name": "AVANTI - Langenlois Wiener Straße 53",
                "S98": "0",
                "S95": "1.464",
                "N": "0",
                "D": "1.474",
                "G": "0",
                "zip": "3550",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Krems Land",
                "city": "Langenlois",
                "strasse": "Wiener Strasse 53",
                "date": "22.8.2025",
                "time": "5:37:46"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.33873,
                    48.33832
                ]
            },
            "properties": {
                "id": "INFT-ATT35Z",
                "name": "AVANTI - Korneuburg Wiener Straße 44",
                "S98": "0",
                "S95": "1.445",
                "N": "0",
                "D": "1.461",
                "G": "0",
                "zip": "2100",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Korneuburg",
                "city": "Korneuburg",
                "strasse": "Wiener Strasse 44",
                "date": "22.8.2025",
                "time": "5:37:46"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.77878,
                    48.03366
                ]
            },
            "properties": {
                "id": "INFT-ATT368",
                "name": "AVANTI - Hainfeld Wiener Straße 24",
                "S98": "0",
                "S95": "1.469",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "3170",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Lilienfeld",
                "city": "Hainfeld",
                "strasse": "Wiener Strasse 24",
                "date": "22.8.2025",
                "time": "5:37:48"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.73995,
                    47.42804
                ]
            },
            "properties": {
                "id": "INFT-ATT35V",
                "name": "OMV - Dornbirn Schwefel 53",
                "S98": "0",
                "S95": "1.519",
                "N": "0",
                "D": "1.539",
                "G": "0",
                "zip": "6850",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Dornbirn",
                "city": "Dornbirn",
                "strasse": "Schwefel 53",
                "date": "22.8.2025",
                "time": "5:38:50"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.194386,
                    47.350359
                ]
            },
            "properties": {
                "id": "INFT-ATT35X",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.524",
                "N": "0",
                "D": "1.549",
                "G": "0",
                "zip": "5600",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "St. Johann",
                "city": "ST JOHANN IM PONGAU",
                "strasse": "BUNDESSTRASSE 18",
                "date": "22.8.2025",
                "time": "5:38:22"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    10.64229,
                    47.44138
                ]
            },
            "properties": {
                "id": "INFT-ATT363",
                "name": "AVANTI - Weißenbach am Lech 46",
                "S98": "0",
                "S95": "1.574",
                "N": "0",
                "D": "1.574",
                "G": "0",
                "zip": "6671",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Reutte",
                "city": "Weissenbach am Lech",
                "strasse": " 46",
                "date": "22.8.2025",
                "time": "5:38:45"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.356244,
                    48.135681
                ]
            },
            "properties": {
                "id": "INFT-ATT36B",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.448",
                "N": "0",
                "D": "1.459",
                "G": "0",
                "zip": "1230",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Liesing",
                "city": "WIEN",
                "strasse": "LAXENBURGER STRASSE 248",
                "date": "22.8.2025",
                "time": "5:39:3"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.38869,
                    47.25633
                ]
            },
            "properties": {
                "id": "INFT-ATT36L",
                "name": "OMV - Innsbruck Egger-Lienz-Straße 3d",
                "S98": "0",
                "S95": "1.599",
                "N": "0",
                "D": "1.599",
                "G": "0",
                "zip": "6020",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Innsbruck",
                "city": "Innsbruck",
                "strasse": "Egger-Lienz-Strasse 3d",
                "date": "22.8.2025",
                "time": "5:38:38"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.36578,
                    48.24531
                ]
            },
            "properties": {
                "id": "INFT-ATT36G",
                "name": "OMV - Wien Gunoldstraße 7 / Muthgasse 1",
                "S98": "0",
                "S95": "1.624",
                "N": "0",
                "D": "1.664",
                "G": "0",
                "zip": "1190",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Döbling",
                "city": "Wien",
                "strasse": "Gunoldstrasse 7 / Muthgasse 1 ",
                "date": "22.8.2025",
                "time": "5:38:59"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.47211,
                    48.25141
                ]
            },
            "properties": {
                "id": "INFT-ATT36H",
                "name": "OMV - Wien Breitenleer Straße Ost B302 112",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.509",
                "G": "0",
                "zip": "1220",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Donaustadt",
                "city": "Wien",
                "strasse": "Breitenleer Strasse Ost B302 112",
                "date": "22.8.2025",
                "time": "5:39:2"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.28586,
                    47.23079
                ]
            },
            "properties": {
                "id": "INFT-ATT36D",
                "name": "AVANTI - Axams Innsbrucker Straße 37",
                "S98": "0",
                "S95": "1.609",
                "N": "0",
                "D": "1.609",
                "G": "0",
                "zip": "6094",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Innsbruck Land",
                "city": "Axams",
                "strasse": "Innsbrucker Strasse 37",
                "date": "22.8.2025",
                "time": "5:38:40"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.70295,
                    47.49046
                ]
            },
            "properties": {
                "id": "INFT-ATTAVV",
                "name": "AVANTI - Hard Hofsteigstraße 85",
                "S98": "0",
                "S95": "1.563",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "6971",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Bregenz",
                "city": "Hard",
                "strasse": "Hofsteigstrasse 85",
                "date": "22.8.2025",
                "time": "5:38:49"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.412426,
                    47.731865
                ]
            },
            "properties": {
                "id": "INFT-ATTD73",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.469",
                "N": "0",
                "D": "1.487",
                "G": "0",
                "zip": "7210",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Mattersburg",
                "city": "MATTERSBURG",
                "strasse": "FACHMARKTZENTRUM 3 A",
                "date": "22.8.2025",
                "time": "5:37:21"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.125588,
                    47.053103
                ]
            },
            "properties": {
                "id": "INFT-ATTD6T",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.438",
                "G": "0",
                "zip": "8582",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Voitsberg",
                "city": "ROSENTAL",
                "strasse": "BAHNHOFSTRASSE 2",
                "date": "22.8.2025",
                "time": "5:38:32"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.334226,
                    47.861448
                ]
            },
            "properties": {
                "id": "INFT-ATTJ5P",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.489",
                "G": "0",
                "zip": "5310",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Vöcklabruck",
                "city": "MONDSEE",
                "strasse": "GEWERBESTRASSE 3 A",
                "date": "22.8.2025",
                "time": "5:38:17"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.31374,
                    48.20685
                ]
            },
            "properties": {
                "id": "INFT-ATTJ5L",
                "name": "OMV - Wien Gablenzgasse 109",
                "S98": "0",
                "S95": "1.539",
                "N": "0",
                "D": "1.569",
                "G": "0",
                "zip": "1150",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Rudolfsheim",
                "city": "Wien",
                "strasse": "Gablenzgasse 109",
                "date": "22.8.2025",
                "time": "5:38:58"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.16653,
                    47.36978
                ]
            },
            "properties": {
                "id": "INFT-ATU38X",
                "name": "AVANTI - Leutasch Waidach 373",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.597",
                "G": "0",
                "zip": "6105",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Innsbruck Land",
                "city": "Leutasch",
                "strasse": "Waidach 373",
                "date": "22.8.2025",
                "time": "5:38:39"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.058304,
                    48.328077
                ]
            },
            "properties": {
                "id": "INFT-ATV74G",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.426",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "3430",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Tulln",
                "city": "TULLN",
                "strasse": "Brückenstraße 10",
                "date": "22.8.2025",
                "time": "5:37:55"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.61753,
                    48.18769
                ]
            },
            "properties": {
                "id": "INFT-ATV74C",
                "name": "AVANTI - Sankt Pölten Mariazeller Straße 95",
                "S98": "0",
                "S95": "1.444",
                "N": "0",
                "D": "1.472",
                "G": "0",
                "zip": "3100",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "St. Pölten",
                "city": "Sankt Poelten",
                "strasse": "Mariazeller Strasse 95",
                "date": "22.8.2025",
                "time": "5:37:35"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.366831,
                    48.146913
                ]
            },
            "properties": {
                "id": "INFT-ATX7CF",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.448",
                "N": "0",
                "D": "1.459",
                "G": "0",
                "zip": "1230",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Liesing",
                "city": "WIEN",
                "strasse": "OBERLAAERSTR. 276",
                "date": "22.8.2025",
                "time": "5:39:3"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.02148,
                    48.318436
                ]
            },
            "properties": {
                "id": "INFT-AU2UBB",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.426",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "3442",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Tulln",
                "city": "LANGENROHR",
                "strasse": "ÜBERLÄNDSTRASSE 2",
                "date": "22.8.2025",
                "time": "5:37:55"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.08587,
                    48.17039
                ]
            },
            "properties": {
                "id": "INFT-AU4233",
                "name": "AVANTI - Ybbs Bahnhofstraße 13",
                "S98": "0",
                "S95": "1.449",
                "N": "0",
                "D": "1.453",
                "G": "0",
                "zip": "3370",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Melk",
                "city": "Ybbs",
                "strasse": "Bahnhofstrasse 13",
                "date": "22.8.2025",
                "time": "5:37:48"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.1004595,
                    47.6822599
                ]
            },
            "properties": {
                "id": "INFT-AU4B3N",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.461",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "5400",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Hallein",
                "city": "Hallein",
                "strasse": "Salzachtalstraße 16",
                "date": "22.8.2025",
                "time": "5:38:19"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.529877,
                    48.284271
                ]
            },
            "properties": {
                "id": "INFT-AU9GP6",
                "name": "Treibstoffparadies",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.458",
                "G": "0",
                "zip": "2232",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Gänserndorf",
                "city": "Aderklaa",
                "strasse": "Wienerstrasse 12",
                "date": "22.8.2025",
                "time": "5:37:40"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.277629,
                    48.213524
                ]
            },
            "properties": {
                "id": "INFT-AUA3P2",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.464",
                "N": "0",
                "D": "1.484",
                "G": "0",
                "zip": "4052",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Linz Land",
                "city": "ANSFELDEN",
                "strasse": "TRAUNUFERSTRASSE 115",
                "date": "22.8.2025",
                "time": "5:38:0"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.280858,
                    48.211344
                ]
            },
            "properties": {
                "id": "INFT-AUA3P3",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.464",
                "N": "0",
                "D": "1.484",
                "G": "0",
                "zip": "4052",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Linz Land",
                "city": "ANSFELDEN",
                "strasse": "HAIDERSTR. 38",
                "date": "22.8.2025",
                "time": "5:38:0"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.59846,
                    48.12157
                ]
            },
            "properties": {
                "id": "INFT-AUAGG9",
                "name": "AVANTI - Fischamend Reichsstraße 2",
                "S98": "0",
                "S95": "1.433",
                "N": "0",
                "D": "1.452",
                "G": "0",
                "zip": "2401",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Wien Umgebung",
                "city": "Fischamend",
                "strasse": "Reichsstrasse 2",
                "date": "22.8.2025",
                "time": "5:37:39"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.23616,
                    48.20186
                ]
            },
            "properties": {
                "id": "INFT-AVR3C4",
                "name": "OMV - Wien Wientalstraße/Auhofbrücke 40",
                "S98": "0",
                "S95": "1.529",
                "N": "0",
                "D": "1.539",
                "G": "0",
                "zip": "1140",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Penzing",
                "city": "Wien",
                "strasse": "Wientalstrasse/Auhofbrücke 40",
                "date": "22.8.2025",
                "time": "5:38:57"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.2313565,
                    47.8977459
                ]
            },
            "properties": {
                "id": "INFT-AWTG9T",
                "name": "Tankstelle Riener GmbH",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.495",
                "G": "0",
                "zip": "4592",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Kirchdorf",
                "city": "Leonstein",
                "strasse": "Leonsteiner Straße 21",
                "date": "22.8.2025",
                "time": "5:38:8"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.409831,
                    47.153053
                ]
            },
            "properties": {
                "id": "INFT-AXVE42",
                "name": "Landforst Scheifling",
                "S98": "0",
                "S95": "1.499",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "8811",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Murau",
                "city": "Scheifling",
                "strasse": "Murauerstrasse 7",
                "date": "22.8.2025",
                "time": "5:38:31"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.5923631,
                    47.3012592
                ]
            },
            "properties": {
                "id": "INFT-AYSFP8",
                "name": "Plose A Oil",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.579",
                "G": "0",
                "zip": "6122",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Innsbruck Land",
                "city": "Fritzens",
                "strasse": "Innstrasse 13",
                "date": "22.8.2025",
                "time": "5:38:39"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.2542347,
                    46.6273845
                ]
            },
            "properties": {
                "id": "INFT-AZ8HFU",
                "name": "BP Tankstelle Brandner KG",
                "S98": "0",
                "S95": "1.599",
                "N": "0",
                "D": "1.619",
                "G": "0",
                "zip": "9631",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Hermagor",
                "city": "Jenig",
                "strasse": "Tröpolach 177",
                "date": "22.8.2025",
                "time": "5:37:28"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.644945,
                    47.459666
                ]
            },
            "properties": {
                "id": "INFT-B23J4A",
                "name": "ESW Dieselkraftstoff",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.494",
                "G": "0",
                "zip": "6973",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Bregenz",
                "city": "Höchst",
                "strasse": "Hauptstraße 38",
                "date": "22.8.2025",
                "time": "5:38:48"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.5123905,
                    47.4991041
                ]
            },
            "properties": {
                "id": "INFT-B24JD8",
                "name": "Genol-Lagerhaustankstelle - Oberpullendorf",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.475",
                "G": "0",
                "zip": "7350",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Oberpullendorf",
                "city": "OBERPULLENDORF",
                "strasse": "Eisenstädter Strasse 24",
                "date": "22.8.2025",
                "time": "5:37:24"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.80875,
                    47.21001
                ]
            },
            "properties": {
                "id": "INFT-B2BLM8",
                "name": "AVANTI - Knittelfeld Kärntner Straße 75",
                "S98": "0",
                "S95": "1.457",
                "N": "0",
                "D": "1.462",
                "G": "0",
                "zip": "8720",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Knittelfeld",
                "city": "Knittelfeld",
                "strasse": "Kärntner Strasse 75",
                "date": "22.8.2025",
                "time": "5:38:36"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    17.07018,
                    47.9386394
                ]
            },
            "properties": {
                "id": "INFT-B2ELFU",
                "name": "Pamer GmbH",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.489",
                "G": "0",
                "zip": "2425",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Neusiedl am See",
                "city": " Nickelsdorf",
                "strasse": "Scheunengasse 2",
                "date": "22.8.2025",
                "time": "5:37:22"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    17.0059708,
                    47.9805003
                ]
            },
            "properties": {
                "id": "INFT-B2ELFT",
                "name": "Pamer GmbH",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.489",
                "G": "0",
                "zip": "2424",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Neusiedl am See",
                "city": "Zurndorf",
                "strasse": "Fabrikweg 26",
                "date": "22.8.2025",
                "time": "5:37:22"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.233346,
                    46.821138
                ]
            },
            "properties": {
                "id": "INFT-B39K55",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.439",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "8530",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Deutschlandsberg",
                "city": "DEUTSCHLANDSBERG",
                "strasse": "FRAUENTALER STRASSE 97",
                "date": "22.8.2025",
                "time": "5:38:26"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.130639,
                    48.28957
                ]
            },
            "properties": {
                "id": "INFT-B3MJA2",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.499",
                "N": "0",
                "D": "1.489",
                "G": "0",
                "zip": "4072",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Eferding",
                "city": "ALKOVEN",
                "strasse": "GEWERBESTRASSE 19",
                "date": "22.8.2025",
                "time": "5:38:5"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.1490977,
                    48.1253328
                ]
            },
            "properties": {
                "id": "INFT-B4GSSL",
                "name": "24 tanken + shop",
                "S98": "0",
                "S95": "1.488",
                "N": "0",
                "D": "1.488",
                "G": "0",
                "zip": "3250",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Scheibbs",
                "city": "Wieselburg",
                "strasse": "Teichweg 3",
                "date": "22.8.2025",
                "time": "5:37:53"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.917971,
                    48.73747
                ]
            },
            "properties": {
                "id": "INFT-B5SHAJ",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.559",
                "N": "0",
                "D": "1.579",
                "G": "0",
                "zip": "3950",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Gmünd",
                "city": "Gmünd",
                "strasse": "Eichberg 121",
                "date": "22.8.2025",
                "time": "5:37:42"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.58826,
                    47.29775
                ]
            },
            "properties": {
                "id": "INFT-B65E8Z",
                "name": "Shell Austria",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.609",
                "G": "0",
                "zip": "6112",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Innsbruck Land",
                "city": "WATTENS",
                "strasse": "BAHNHOFSTRASSE 55",
                "date": "22.8.2025",
                "time": "5:38:40"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.4533989,
                    48.2675844
                ]
            },
            "properties": {
                "id": "INFT-B68GDW",
                "name": "boesch energy,  turmöl Quick",
                "S98": "0",
                "S95": "1.444",
                "N": "0",
                "D": "1.474",
                "G": "0",
                "zip": "4222",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Perg",
                "city": "St.Georgen an der Gusen",
                "strasse": "Mauthausenerstrasse 48",
                "date": "22.8.2025",
                "time": "5:38:11"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.037198,
                    48.16201
                ]
            },
            "properties": {
                "id": "INFT-B6SBAS",
                "name": "eww-Tankstation",
                "S98": "0",
                "S95": "1.439",
                "N": "0",
                "D": "1.449",
                "G": "0",
                "zip": "4600",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Wels",
                "city": "Wels",
                "strasse": "Wiesenstrasse 39",
                "date": "22.8.2025",
                "time": "5:38:2"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.200116,
                    47.823327
                ]
            },
            "properties": {
                "id": "INFT-B6XGCQ",
                "name": "Lagerhaus-Tankstelle 24 h mit Waschportal",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "5322",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Salzburg Umgebung",
                "city": "Hof",
                "strasse": "Gewerbestrasse 3",
                "date": "22.8.2025",
                "time": "5:38:21"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.4548317,
                    46.9938723
                ]
            },
            "properties": {
                "id": "INFT-B74G4E",
                "name": "car&care Tankstelle Konrad Service-Center",
                "S98": "0",
                "S95": "1.438",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "8073",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Graz Umgebung",
                "city": "Feldkirchen",
                "strasse": "Triester Straße 219",
                "date": "22.8.2025",
                "time": "5:38:27"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.440038,
                    48.34395
                ]
            },
            "properties": {
                "id": "INFT-B7CK6D",
                "name": "Genol Lagerhaus Pregarten-Gallneukirchen",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.469",
                "G": "0",
                "zip": "4209",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Urfahr Umgebung",
                "city": "Engerwitzdorf",
                "strasse": "Engerwitzdorfer Straße 40",
                "date": "22.8.2025",
                "time": "5:38:16"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.459558,
                    46.971032
                ]
            },
            "properties": {
                "id": "INFT-B7JJDR",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.443",
                "G": "0",
                "zip": "8401",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Graz Umgebung",
                "city": "KALSDORF",
                "strasse": "FELDKIRCHENSTRASSE 38",
                "date": "22.8.2025",
                "time": "5:38:27"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.8183828,
                    48.6369792
                ]
            },
            "properties": {
                "id": "INFT-B88G65",
                "name": "Genol",
                "S98": "0",
                "S95": "1.569",
                "N": "0",
                "D": "1.569",
                "G": "0",
                "zip": "3730",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Horn",
                "city": "Eggenburg",
                "strasse": "Zogelsdorferstraße 1-5",
                "date": "22.8.2025",
                "time": "5:37:45"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.430359,
                    47.060424
                ]
            },
            "properties": {
                "id": "INFT-B8QUSB",
                "name": "M3 Energy",
                "S98": "0",
                "S95": "1.432",
                "N": "0",
                "D": "1.436",
                "G": "0",
                "zip": "8020",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Graz",
                "city": "Graz",
                "strasse": "Karlauerstraße 42",
                "date": "22.8.2025",
                "time": "5:38:25"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.4451382,
                    47.2483614
                ]
            },
            "properties": {
                "id": "INFT-B97GH7",
                "name": "Gutmann ENI Tankstelle ",
                "S98": "0",
                "S95": "1.609",
                "N": "0",
                "D": "1.609",
                "G": "0",
                "zip": "6071",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Innsbruck Land",
                "city": "Aldrans",
                "strasse": "Lanserstraße 2a",
                "date": "22.8.2025",
                "time": "5:38:40"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.228437,
                    48.143876
                ]
            },
            "properties": {
                "id": "INFT-B99E5Z",
                "name": "BP Tankautomat Neuhofen",
                "S98": "0",
                "S95": "1.432",
                "N": "0",
                "D": "1.444",
                "G": "0",
                "zip": "4501",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Linz Land",
                "city": "Neuhofen",
                "strasse": "Linzer Straße 41",
                "date": "22.8.2025",
                "time": "5:38:10"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.085068,
                    47.372167
                ]
            },
            "properties": {
                "id": "INFT-B9EBDZ",
                "name": "M3 Energy",
                "S98": "0",
                "S95": "1.442",
                "N": "0",
                "D": "1.447",
                "G": "0",
                "zip": "8700",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Leoben",
                "city": "Leoben",
                "strasse": "Einödmayergasse 1",
                "date": "22.8.2025",
                "time": "5:38:29"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.4383071,
                    48.131813
                ]
            },
            "properties": {
                "id": "INFT-B9KGKP",
                "name": "Champion",
                "S98": "0",
                "S95": "1.433",
                "N": "0",
                "D": "1.444",
                "G": "0",
                "zip": "2320",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Wien Umgebung",
                "city": "Kledering",
                "strasse": "Klederinger Straße 41",
                "date": "22.8.2025",
                "time": "5:37:39"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.272085,
                    47.136327
                ]
            },
            "properties": {
                "id": "INFT-BBLBV9",
                "name": "Welog - Landespartner des Burgenlands",
                "S98": "0",
                "S95": "1.479",
                "N": "0",
                "D": "1.449",
                "G": "0",
                "zip": "7535",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Güssing",
                "city": "St. Michael im Burgenland",
                "strasse": "Obere Hauptstraße 230",
                "date": "22.8.2025",
                "time": "5:37:21"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.771828,
                    48.23407
                ]
            },
            "properties": {
                "id": "INFT-BD8J2L",
                "name": "PINK - so pink, so clever",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.494",
                "G": "0",
                "zip": "4710",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Grieskirchen",
                "city": "Grieskirchen",
                "strasse": "Industriepark Stritzing 18",
                "date": "22.8.2025",
                "time": "5:38:7"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.524077,
                    47.886334
                ]
            },
            "properties": {
                "id": "INFT-BHXGPF",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.469",
                "N": "0",
                "D": "1.489",
                "G": "0",
                "zip": "4865",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Vöcklabruck",
                "city": "Nußdorf am Attersee",
                "strasse": "Dorfstraße 16",
                "date": "22.8.2025",
                "time": "5:38:17"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.621814,
                    46.663089
                ]
            },
            "properties": {
                "id": "INFT-BJRTUP",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.457",
                "N": "0",
                "D": "1.459",
                "G": "0",
                "zip": "9100",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Völkermarkt",
                "city": "VÖLKERMARKT",
                "strasse": "UMFAHRUNGSSTRASSE 7",
                "date": "22.8.2025",
                "time": "5:37:32"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.45797,
                    48.17054
                ]
            },
            "properties": {
                "id": "INFT-BJYJ2G",
                "name": "AVANTI - Wien Jedletzbergerstraße 7",
                "S98": "0",
                "S95": "1.433",
                "N": "0",
                "D": "1.453",
                "G": "0",
                "zip": "1110",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Simmering",
                "city": "Wien",
                "strasse": "Jedletzbergerstrasse 7",
                "date": "22.8.2025",
                "time": "5:38:55"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.388013,
                    48.278186
                ]
            },
            "properties": {
                "id": "INFT-BK2FA7",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.456",
                "G": "0",
                "zip": "1210",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Floridsdorf",
                "city": "WIEN",
                "strasse": "PRAGERSTRASSE 138",
                "date": "22.8.2025",
                "time": "5:39:0"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.72747,
                    47.46296
                ]
            },
            "properties": {
                "id": "INFT-BL4JVV",
                "name": "BayWa Tankstelle",
                "S98": "0",
                "S95": "1.494",
                "N": "0",
                "D": "1.514",
                "G": "0",
                "zip": "6923",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Bregenz",
                "city": "Lauterach",
                "strasse": "Scheibenstraße 2",
                "date": "22.8.2025",
                "time": "5:38:49"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.449924,
                    48.056054
                ]
            },
            "properties": {
                "id": "INFT-BLJNBZ",
                "name": "IQ Tankautomat Steyr",
                "S98": "0",
                "S95": "1.427",
                "N": "0",
                "D": "1.455",
                "G": "0",
                "zip": "4400",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Steyr Land",
                "city": "Steyr",
                "strasse": "Haager Straße 44b",
                "date": "22.8.2025",
                "time": "5:38:1"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.5490549,
                    46.8144216
                ]
            },
            "properties": {
                "id": "INFT-BLKG9F",
                "name": "S1 Tankstelle Sunko GmbH",
                "S98": "0",
                "S95": "1.449",
                "N": "0",
                "D": "1.449",
                "G": "0",
                "zip": "8434",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Leibnitz",
                "city": "Neutillmitsch",
                "strasse": "Grazerstraße 60",
                "date": "22.8.2025",
                "time": "5:38:28"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.716091,
                    47.665699
                ]
            },
            "properties": {
                "id": "INFT-BLNE6V",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.472",
                "N": "0",
                "D": "1.477",
                "G": "0",
                "zip": "8931",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Liezen",
                "city": "Großreifling",
                "strasse": "Großreifling 85",
                "date": "22.8.2025",
                "time": "5:38:31"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.898026,
                    48.703029
                ]
            },
            "properties": {
                "id": "INFT-BPMBAB",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.559",
                "N": "0",
                "D": "1.579",
                "G": "0",
                "zip": "3970",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Gmünd",
                "city": "Weitra",
                "strasse": "Gmündner Straße 198",
                "date": "22.8.2025",
                "time": "5:37:43"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.614191,
                    48.179642
                ]
            },
            "properties": {
                "id": "INFT-BQ7SXH",
                "name": "Eni Oberscheider St. Pölten",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.519",
                "G": "0",
                "zip": "3100",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "St. Pölten",
                "city": "St. Pölten",
                "strasse": "Schulze Delitzsch-Straße 2",
                "date": "22.8.2025",
                "time": "5:37:35"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.608591,
                    48.11764
                ]
            },
            "properties": {
                "id": "INFT-BRKJG9",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.441",
                "N": "0",
                "D": "1.451",
                "G": "0",
                "zip": "3150",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "St. Pölten Land",
                "city": "WILHELMSBURG",
                "strasse": "ST. POELTNER STRASSE 1 C",
                "date": "22.8.2025",
                "time": "5:37:52"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.093432,
                    47.535122
                ]
            },
            "properties": {
                "id": "INFT-BRPLZZ",
                "name": "INN-TANK",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.498",
                "G": "0",
                "zip": "6336",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Kufstein",
                "city": "Langkampfen",
                "strasse": "Kiesweg 10",
                "date": "22.8.2025",
                "time": "5:38:42"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.014680121853992,
                    48.31138203436592
                ]
            },
            "properties": {
                "id": "INFT-BUBEXR",
                "name": "GG Tankstelle Langenrohr",
                "S98": "0",
                "S95": "1.418",
                "N": "0",
                "D": "1.439",
                "G": "0",
                "zip": "3442",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Tulln",
                "city": "Langenrohr",
                "strasse": "Tullner Straße 6 ",
                "date": "22.8.2025",
                "time": "5:37:54"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.131794,
                    47.052799
                ]
            },
            "properties": {
                "id": "INFT-BUFM52",
                "name": "LAGERHAUS Genol Voitsberg",
                "S98": "0",
                "S95": "1.433",
                "N": "0",
                "D": "1.439",
                "G": "0",
                "zip": "8570",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Voitsberg",
                "city": "Voitsberg",
                "strasse": "Am Vorum 2",
                "date": "22.8.2025",
                "time": "5:38:33"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.40998,
                    46.85349
                ]
            },
            "properties": {
                "id": "INFT-BUUAKZ",
                "name": "Treibstoffparadies",
                "S98": "0",
                "S95": "1.459",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "8504",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Deutschlandsberg",
                "city": "Preding",
                "strasse": "Gewerbepark Ost 1",
                "date": "22.8.2025",
                "time": "5:38:26"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.724478,
                    48.015832
                ]
            },
            "properties": {
                "id": "INFT-BV3GDU",
                "name": "SOCAR Attnang - Puchheim",
                "S98": "0",
                "S95": "1.484",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "4800",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Vöcklabruck",
                "city": "Attnang - Puchheim",
                "strasse": "Bahnhofstraße 25",
                "date": "22.8.2025",
                "time": "5:38:17"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.1824,
                    48.20595
                ]
            },
            "properties": {
                "id": "INFT-BW3E86",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.441",
                "N": "0",
                "D": "1.452",
                "G": "0",
                "zip": "3002",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Wien Umgebung",
                "city": "Purkersdorf",
                "strasse": "Wiener Straße 30",
                "date": "22.8.2025",
                "time": "5:37:52"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.242,
                    47.80411
                ]
            },
            "properties": {
                "id": "INFT-BW7DVF",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.501",
                "N": "0",
                "D": "1.516",
                "G": "0",
                "zip": "2700",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Wiener Neustadt Land",
                "city": "Wr. Neustadt",
                "strasse": "Günser Straße 28",
                "date": "22.8.2025",
                "time": "5:37:37"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.210508,
                    47.569864
                ]
            },
            "properties": {
                "id": "INFT-BWHP2X",
                "name": "Rumpold",
                "S98": "0",
                "S95": "1.464",
                "N": "0",
                "D": "1.474",
                "G": "0",
                "zip": "8940",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Liezen",
                "city": "Weissenbach",
                "strasse": "Hauptstraße 213",
                "date": "22.8.2025",
                "time": "5:38:30"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.52446,
                    47.8359
                ]
            },
            "properties": {
                "id": "INFT-BWL9SP",
                "name": "Direct",
                "S98": "0",
                "S95": "1.458",
                "N": "0",
                "D": "1.468",
                "G": "0",
                "zip": "7000",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Eisenstadt",
                "city": "Eisenstadt",
                "strasse": "Mattersburger Straße 5",
                "date": "22.8.2025",
                "time": "5:37:20"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.267408,
                    46.887106
                ]
            },
            "properties": {
                "id": "INFT-C38AE9",
                "name": "SOCAR Napplach",
                "S98": "0",
                "S95": "1.479",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "9816",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Spittal",
                "city": "Penk",
                "strasse": "Napplach 95",
                "date": "22.8.2025",
                "time": "5:37:31"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.80849,
                    46.82868
                ]
            },
            "properties": {
                "id": "INFT-C5HCNH",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.504",
                "N": "0",
                "D": "1.504",
                "G": "0",
                "zip": "9990",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Lienz",
                "city": "Lienz",
                "strasse": "Drautal Bundesstraße 4",
                "date": "22.8.2025",
                "time": "5:38:44"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.27856,
                    47.25181
                ]
            },
            "properties": {
                "id": "INFT-C5MH8T",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.544",
                "N": "0",
                "D": "1.564",
                "G": "0",
                "zip": "5741",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Zell am See",
                "city": "Neukirchen am Großvenediger",
                "strasse": "Gerloser Bundesstraße 262",
                "date": "22.8.2025",
                "time": "5:38:24"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.99039,
                    48.57763
                ]
            },
            "properties": {
                "id": "INFT-C628SC",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.479",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "4150",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Rohrbach",
                "city": "Rohrbach",
                "strasse": "Bahnhofstraße 26",
                "date": "22.8.2025",
                "time": "5:38:14"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    17.05908,
                    48.0927
                ]
            },
            "properties": {
                "id": "INFT-C63KC7",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.474",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "2421",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Neusiedl am See",
                "city": "Kittsee",
                "strasse": "Eisenstädter Straße 3",
                "date": "22.8.2025",
                "time": "5:37:23"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.536066968607242,
                    48.440260165675596
                ]
            },
            "properties": {
                "id": "INFT-C63SYK",
                "name": "Avia Xpress Kefermarkt",
                "S98": "0",
                "S95": "1.488",
                "N": "0",
                "D": "1.468",
                "G": "0",
                "zip": "4292",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Freistadt",
                "city": "Kefermarkt",
                "strasse": "Im Tal 2",
                "date": "22.8.2025",
                "time": "5:38:5"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.09377,
                    46.73206
                ]
            },
            "properties": {
                "id": "INFT-C6P6M8",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.457",
                "N": "0",
                "D": "1.459",
                "G": "0",
                "zip": "9560",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Feldkirchen",
                "city": "FELDKIRCHEN",
                "strasse": "ERMELINDE-KOCH-STRASSE 2",
                "date": "22.8.2025",
                "time": "5:37:34"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.536038807582068,
                    48.74803216824057
                ]
            },
            "properties": {
                "id": "INFT-C7JE2E",
                "name": "Genol",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.569",
                "G": "0",
                "zip": "3754",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Horn",
                "city": "Irnfritz",
                "strasse": "Hauptstraße 3",
                "date": "22.8.2025",
                "time": "5:37:44"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.0487,
                    48.2447
                ]
            },
            "properties": {
                "id": "INFT-C87HQ9",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.484",
                "N": "0",
                "D": "1.504",
                "G": "0",
                "zip": "5280",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Braunau",
                "city": "Braunau",
                "strasse": "Hofer Strasse 1 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:3"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.3007,
                    48.1511
                ]
            },
            "properties": {
                "id": "INFT-C87HQQ",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.431",
                "N": "0",
                "D": "1.453",
                "G": "0",
                "zip": "1230",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Liesing",
                "city": "Wien",
                "strasse": "Breitenfurter Strasse 261 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:39:3"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.42069,
                    47.27889
                ]
            },
            "properties": {
                "id": "INFT-C8FE5J",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.559",
                "N": "0",
                "D": "1.579",
                "G": "0",
                "zip": "6020",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Innsbruck",
                "city": "Innsbruck",
                "strasse": "Hallerstrasse 93 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:37"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.1379,
                    47.6379
                ]
            },
            "properties": {
                "id": "INFT-C9BG5S",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.461",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "5431",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Hallein",
                "city": "Kuchl",
                "strasse": "Garnei 208 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:19"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.0506,
                    47.7388
                ]
            },
            "properties": {
                "id": "INFT-C9FKD5",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.461",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "5081",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Salzburg Umgebung",
                "city": "Anif",
                "strasse": "Alpenstrasse 102 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:20"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.0792562,
                    48.5508163
                ]
            },
            "properties": {
                "id": "INFT-C9GJY9",
                "name": "Turmöl",
                "S98": "0",
                "S95": "1.487",
                "N": "0",
                "D": "1.517",
                "G": "0",
                "zip": "2020",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Hollabrunn",
                "city": "Hollabrunn",
                "strasse": "Wienerstraße 95",
                "date": "22.8.2025",
                "time": "5:37:43"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.96843,
                    46.67948
                ]
            },
            "properties": {
                "id": "INFT-C9MSHP",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.479",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "9551",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Feldkirchen",
                "city": "Bodensdorf",
                "strasse": "Bundesstraße 65",
                "date": "22.8.2025",
                "time": "5:37:35"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.5965,
                    48.01419
                ]
            },
            "properties": {
                "id": "INFT-C9W7R6",
                "name": "Direct",
                "S98": "0",
                "S95": "1.448",
                "N": "0",
                "D": "1.458",
                "G": "0",
                "zip": "3180",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Lilienfeld",
                "city": "Lilienfeld",
                "strasse": "Liese Prokop-Straße 2",
                "date": "22.8.2025",
                "time": "5:37:47"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    10.767215,
                    47.435845
                ]
            },
            "properties": {
                "id": "INFT-C9Y9EA",
                "name": "BP",
                "S98": "0",
                "S95": "1.619",
                "N": "0",
                "D": "1.609",
                "G": "0",
                "zip": "6611",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Reutte",
                "city": "Heiterwang",
                "strasse": "Gewerbegebiet 1",
                "date": "22.8.2025",
                "time": "5:38:45"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.59632,
                    47.18404
                ]
            },
            "properties": {
                "id": "INFT-C9YKVY",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.457",
                "N": "0",
                "D": "1.462",
                "G": "0",
                "zip": "8755",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Judenburg",
                "city": "St. Peter ob Judenburg",
                "strasse": "Furth 24",
                "date": "22.8.2025",
                "time": "5:38:36"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.61781,
                    48.25192
                ]
            },
            "properties": {
                "id": "INFT-CA6NZR",
                "name": "boesch energy,  turmöl Quick",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.474",
                "G": "0",
                "zip": "4320",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Perg",
                "city": "Perg",
                "strasse": "Zeitling 36",
                "date": "22.8.2025",
                "time": "5:38:11"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.244488,
                    47.829082
                ]
            },
            "properties": {
                "id": "INFT-CALJHY",
                "name": "Turmöl",
                "S98": "0",
                "S95": "1.506",
                "N": "0",
                "D": "1.521",
                "G": "0",
                "zip": "2700",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Wiener Neustadt Land",
                "city": "Wiener Neustadt",
                "strasse": "Wienerstraße 114",
                "date": "22.8.2025",
                "time": "5:37:37"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.379636,
                    48.162894
                ]
            },
            "properties": {
                "id": "INFT-CAMDWQ",
                "name": "Turmöl",
                "S98": "0",
                "S95": "1.447",
                "N": "0",
                "D": "1.458",
                "G": "0",
                "zip": "1100",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Favoriten",
                "city": "Wien",
                "strasse": "Grenzackerstraße 2-4",
                "date": "22.8.2025",
                "time": "5:38:53"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.0780523,
                    48.7920686
                ]
            },
            "properties": {
                "id": "INFT-CAMH8H",
                "name": "Turmöl",
                "S98": "0",
                "S95": "1.564",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "3902",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Waidhofen/Thaya",
                "city": "Vitis",
                "strasse": "Horner Straße 25",
                "date": "22.8.2025",
                "time": "5:37:56"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.620876,
                    48.198998
                ]
            },
            "properties": {
                "id": "INFT-CAMJH5",
                "name": "Turmöl",
                "S98": "0",
                "S95": "1.451",
                "N": "0",
                "D": "1.478",
                "G": "0",
                "zip": "3100",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "St. Pölten",
                "city": "St. Pölten",
                "strasse": "Mariazellerstraße 17",
                "date": "22.8.2025",
                "time": "5:37:36"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.4286182,
                    48.0414124
                ]
            },
            "properties": {
                "id": "INFT-CAMJHD",
                "name": "Turmöl",
                "S98": "0",
                "S95": "1.438",
                "N": "0",
                "D": "1.466",
                "G": "0",
                "zip": "4400",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Steyr Land",
                "city": "Steyr",
                "strasse": "Pachergasse 14",
                "date": "22.8.2025",
                "time": "5:38:1"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.36409,
                    47.76441
                ]
            },
            "properties": {
                "id": "INFT-CAN35P",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.479",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "5340",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Salzburg Umgebung",
                "city": "St. Gilgen",
                "strasse": "Konrad Lesiak Platz 6",
                "date": "22.8.2025",
                "time": "5:38:21"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.5611,
                    48.5612
                ]
            },
            "properties": {
                "id": "INFT-CATHZQ",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.493",
                "N": "0",
                "D": "1.511",
                "G": "0",
                "zip": "2130",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Mistelbach",
                "city": "Mistelbach",
                "strasse": "Ernstbrunnerstrasse 2 (am HOFER Parklpatz)",
                "date": "22.8.2025",
                "time": "5:37:50"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.0823,
                    48.3194
                ]
            },
            "properties": {
                "id": "INFT-CAZDTV",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.421",
                "N": "0",
                "D": "1.441",
                "G": "0",
                "zip": "3430",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Tulln",
                "city": "Tulln",
                "strasse": "Königstetter Strasse 148 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:37:55"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.311,
                    48.3603
                ]
            },
            "properties": {
                "id": "INFT-CBSSQ2",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.442",
                "N": "0",
                "D": "1.458",
                "G": "0",
                "zip": "2100",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Korneuburg",
                "city": "Leobendorf",
                "strasse": "Hammerschmiedstrasse 1 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:37:45"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.67055,
                    47.3666
                ]
            },
            "properties": {
                "id": "INFT-CBWGFU",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.484",
                "N": "0",
                "D": "1.513",
                "G": "0",
                "zip": "6845",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Dornbirn",
                "city": "Hohenems",
                "strasse": "Barnabas-Fink-Strasse 1 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:50"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.0738,
                    48.5645
                ]
            },
            "properties": {
                "id": "INFT-CCAD5K",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.482",
                "N": "0",
                "D": "1.512",
                "G": "0",
                "zip": "2020",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Hollabrunn",
                "city": "Hollabrunn",
                "strasse": "Gschmeidlerstrasse 16 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:37:43"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.5083,
                    46.7919
                ]
            },
            "properties": {
                "id": "INFT-CCAJSH",
                "name": "eni24",
                "S98": "0",
                "S95": "1.474",
                "N": "0",
                "D": "1.474",
                "G": "0",
                "zip": "9800",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Spittal",
                "city": "Spittal/Drau",
                "strasse": "Villacherstrasse 44",
                "date": "22.8.2025",
                "time": "5:37:30"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.684,
                    47.1295
                ]
            },
            "properties": {
                "id": "INFT-CCAJSY",
                "name": "eni24",
                "S98": "0",
                "S95": "1.689",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "5570",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Tamsweg",
                "city": "Mauterndorf",
                "strasse": "Katschberg Bundesstrasse",
                "date": "22.8.2025",
                "time": "5:38:23"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.377225,
                    48.163473
                ]
            },
            "properties": {
                "id": "INFT-CCAJT9",
                "name": "eni",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.519",
                "G": "0",
                "zip": "1100",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Favoriten",
                "city": "Wien",
                "strasse": "Grenzackerstrasse 6-8",
                "date": "22.8.2025",
                "time": "5:38:53"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.3551,
                    48.1676
                ]
            },
            "properties": {
                "id": "INFT-CCAJTA",
                "name": "eni",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.519",
                "G": "0",
                "zip": "1100",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Favoriten",
                "city": "Wien",
                "strasse": "Raxstrasse 44 / Windtenstrasse 2A",
                "date": "22.8.2025",
                "time": "5:38:53"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.461068,
                    48.263207
                ]
            },
            "properties": {
                "id": "INFT-CCAJTG",
                "name": "eni",
                "S98": "0",
                "S95": "1.459",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "1220",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Donaustadt",
                "city": "Wien",
                "strasse": "Rautenweg 13",
                "date": "22.8.2025",
                "time": "5:39:2"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.086187,
                    47.732187
                ]
            },
            "properties": {
                "id": "INFT-CCAKTZ",
                "name": "eni",
                "S98": "0",
                "S95": "1.499",
                "N": "0",
                "D": "1.529",
                "G": "0",
                "zip": "5412",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Hallein",
                "city": "Puch bei Hallein",
                "strasse": "Urstein Nord 15",
                "date": "22.8.2025",
                "time": "5:38:20"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.78306752,
                    46.83117595
                ]
            },
            "properties": {
                "id": "INFT-CCAKU7",
                "name": "eni",
                "S98": "0",
                "S95": "1.499",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "9900",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Lienz",
                "city": "Lienz",
                "strasse": "Kärntnerstrasse 84",
                "date": "22.8.2025",
                "time": "5:38:44"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    10.370189,
                    47.260476
                ]
            },
            "properties": {
                "id": "INFT-CCAKU9",
                "name": "eni24",
                "S98": "0",
                "S95": "1.599",
                "N": "0",
                "D": "1.599",
                "G": "0",
                "zip": "6653",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Reutte",
                "city": "Bach Im Lechtal",
                "strasse": "Stockach 29a",
                "date": "22.8.2025",
                "time": "5:38:45"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.163099,
                    47.113156
                ]
            },
            "properties": {
                "id": "INFT-CCANME",
                "name": "eni",
                "S98": "0",
                "S95": "1.499",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "8850",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Murau",
                "city": "Murau",
                "strasse": "Märzenkeller 3",
                "date": "22.8.2025",
                "time": "5:38:32"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.43327,
                    47.26347
                ]
            },
            "properties": {
                "id": "INFT-CCASM3",
                "name": "eni",
                "S98": "0",
                "S95": "1.599",
                "N": "0",
                "D": "1.599",
                "G": "0",
                "zip": "6020",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Innsbruck",
                "city": "Innsbruck-Amras",
                "strasse": "Amraser Seestrasse 64",
                "date": "22.8.2025",
                "time": "5:38:38"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.72079,
                    47.4104
                ]
            },
            "properties": {
                "id": "INFT-CCASM6",
                "name": "eni",
                "S98": "0",
                "S95": "1.529",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "6850",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Dornbirn",
                "city": "Dornbirn",
                "strasse": "Lustenauerstrasse 52",
                "date": "22.8.2025",
                "time": "5:38:50"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.54817,
                    47.131458
                ]
            },
            "properties": {
                "id": "INFT-CCB393",
                "name": "eni A 10 Tauernautobahn",
                "S98": "0",
                "S95": "1.999",
                "N": "0",
                "D": "1.999",
                "G": "0",
                "zip": "5584",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Tamsweg",
                "city": "Zederhaus/Krottendf.",
                "strasse": "Lamm 113",
                "date": "22.8.2025",
                "time": "5:38:23"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.1045,
                    47.6797
                ]
            },
            "properties": {
                "id": "INFT-CCB9B8",
                "name": "eni",
                "S98": "0",
                "S95": "1.499",
                "N": "0",
                "D": "1.529",
                "G": "0",
                "zip": "5400",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Hallein",
                "city": "Hallein",
                "strasse": "Salzachtalstrasse 23",
                "date": "22.8.2025",
                "time": "5:38:20"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.83863,
                    46.59716
                ]
            },
            "properties": {
                "id": "INFT-CCBDXT",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.454",
                "N": "0",
                "D": "1.454",
                "G": "0",
                "zip": "9500",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Villach",
                "city": "Villach",
                "strasse": "Kärntner Strasse 27 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:37:27"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.6174,
                    48.1737
                ]
            },
            "properties": {
                "id": "INFT-CCBDXW",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.444",
                "N": "0",
                "D": "1.472",
                "G": "0",
                "zip": "3100",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "St. Pölten",
                "city": "St. Poelten",
                "strasse": "Porschestrasse 35 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:37:36"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.3101,
                    48.1051
                ]
            },
            "properties": {
                "id": "INFT-CCBDY2",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.429",
                "N": "0",
                "D": "1.439",
                "G": "0",
                "zip": "2345",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Mödling",
                "city": "Brunn am Gebirge",
                "strasse": "Johann-Steinböck-Strasse 18 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:37:51"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.2443,
                    47.8465
                ]
            },
            "properties": {
                "id": "INFT-CCC3E5",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.483",
                "N": "0",
                "D": "1.491",
                "G": "0",
                "zip": "2604",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Wiener Neustadt Land",
                "city": "Theresienfeld",
                "strasse": "Grazerstrasse 68 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:37:57"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.40904,
                    48.27123
                ]
            },
            "properties": {
                "id": "INFT-CCC3EP",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.433",
                "N": "0",
                "D": "1.453",
                "G": "0",
                "zip": "1210",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Floridsdorf",
                "city": "Wien",
                "strasse": "Shuttleworthstrasse 11 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:39:0"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.4779,
                    48.3585
                ]
            },
            "properties": {
                "id": "INFT-CCCGF2",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.469",
                "G": "0",
                "zip": "4210",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Urfahr Umgebung",
                "city": "Unterweitersdorf",
                "strasse": "Betriebsstrasse 14 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:6"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.3937,
                    48.2274
                ]
            },
            "properties": {
                "id": "INFT-CCJG86",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.413",
                "N": "0",
                "D": "1.433",
                "G": "0",
                "zip": "4490",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Linz Land",
                "city": "St. Florian",
                "strasse": "Im Astenfeld 2 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:10"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.755,
                    47.9759
                ]
            },
            "properties": {
                "id": "INFT-CCKM2T",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.496",
                "N": "0",
                "D": "1.502",
                "G": "0",
                "zip": "3340",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Scheibbs",
                "city": "Waidhofen",
                "strasse": "Wiener Strasse 54 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:37:36"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.2807,
                    47.9747
                ]
            },
            "properties": {
                "id": "INFT-CCKM2U",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.449",
                "N": "0",
                "D": "1.464",
                "G": "0",
                "zip": "2500",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Baden",
                "city": "Baden",
                "strasse": "Haidhofstrasse 147 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:37:38"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.45753,
                    48.07173
                ]
            },
            "properties": {
                "id": "INFT-CCKM2V",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.434",
                "N": "0",
                "D": "1.451",
                "G": "0",
                "zip": "2325",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Wien Umgebung",
                "city": "Himberg",
                "strasse": "Hofer Strasse 2 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:37:39"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.61151,
                    48.04992
                ]
            },
            "properties": {
                "id": "INFT-CCKM2W",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.436",
                "N": "0",
                "D": "1.446",
                "G": "0",
                "zip": "3160",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Lilienfeld",
                "city": "Traisen",
                "strasse": "Gewerbestrasse 2 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:37:47"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.5312,
                    48.2401
                ]
            },
            "properties": {
                "id": "INFT-CCKM33",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.412",
                "N": "0",
                "D": "1.439",
                "G": "0",
                "zip": "4310",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Perg",
                "city": "Mauthausen",
                "strasse": "Wienerbergstrasse 1 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:11"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.5319,
                    47.825
                ]
            },
            "properties": {
                "id": "INFT-CCLFZX",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.454",
                "N": "0",
                "D": "1.467",
                "G": "0",
                "zip": "7000",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Eisenstadt",
                "city": "Eisenstadt",
                "strasse": "Haidäckerstrasse 4 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:37:20"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.4127,
                    47.73
                ]
            },
            "properties": {
                "id": "INFT-CCLFZY",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.464",
                "N": "0",
                "D": "1.482",
                "G": "0",
                "zip": "7210",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Mattersburg",
                "city": "Mattersburg",
                "strasse": "Fachmarktzentrum 2 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:37:21"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.48747,
                    47.51454
                ]
            },
            "properties": {
                "id": "INFT-CCLG22",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.474",
                "N": "0",
                "D": "1.474",
                "G": "0",
                "zip": "7344",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Oberpullendorf",
                "city": "Stoob",
                "strasse": "Bgld. Schnellstr./Zubr. Stoob (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:37:24"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.28436,
                    46.64932
                ]
            },
            "properties": {
                "id": "INFT-CCLG23",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.444",
                "N": "0",
                "D": "1.444",
                "G": "0",
                "zip": "9020",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Klagenfurt Land",
                "city": "Klagenfurt",
                "strasse": "Feldkirchner Strasse 221 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:37:26"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.2566,
                    48.0128
                ]
            },
            "properties": {
                "id": "INFT-CCLHWW",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.449",
                "N": "0",
                "D": "1.464",
                "G": "0",
                "zip": "2500",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Baden",
                "city": "Baden",
                "strasse": "Wiener Strasse 72 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:37:38"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.025008,
                    48.183554
                ]
            },
            "properties": {
                "id": "INFT-CCLHX7",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.487",
                "N": "0",
                "D": "1.491",
                "G": "0",
                "zip": "4600",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Wels",
                "city": "Wels",
                "strasse": "Dalistrasse 2 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:2"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.9715,
                    48.1437
                ]
            },
            "properties": {
                "id": "INFT-CCLHX8",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.487",
                "N": "0",
                "D": "1.491",
                "G": "0",
                "zip": "4600",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Wels",
                "city": "Wels",
                "strasse": "Malvenstrasse 3 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:2"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.4957,
                    48.217
                ]
            },
            "properties": {
                "id": "INFT-CCLHXA",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.474",
                "N": "0",
                "D": "1.484",
                "G": "0",
                "zip": "4910",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Ried",
                "city": "Tumeltsham",
                "strasse": "Hannesgrub Nord 1 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:13"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.1514,
                    48.1141
                ]
            },
            "properties": {
                "id": "INFT-CCLK9X",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.484",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "5230",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Braunau",
                "city": "Mattighofen",
                "strasse": "Braunauer Strasse 27 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:3"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.1281,
                    47.8895
                ]
            },
            "properties": {
                "id": "INFT-CCLK9Z",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.529",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "4563",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Kirchdorf",
                "city": "Micheldorf",
                "strasse": "Kollingerfeld 5 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:9"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.2773,
                    48.2146
                ]
            },
            "properties": {
                "id": "INFT-CCLKA3",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.459",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "4052",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Linz Land",
                "city": "Ansfelden",
                "strasse": "Auweg 2 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:0"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.458,
                    48.2162
                ]
            },
            "properties": {
                "id": "INFT-CCLKA5",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.413",
                "N": "0",
                "D": "1.433",
                "G": "0",
                "zip": "4470",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Linz Land",
                "city": "Enns",
                "strasse": "Doktor-Karl-Renner-Strasse 60 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:10"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.4651,
                    48.2072
                ]
            },
            "properties": {
                "id": "INFT-CCLKA6",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.474",
                "N": "0",
                "D": "1.484",
                "G": "0",
                "zip": "4910",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Ried",
                "city": "Ried im Innkreis",
                "strasse": "Aubachweg 2 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:13"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.96922,
                    48.4971
                ]
            },
            "properties": {
                "id": "INFT-CCLLCL",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "4121",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Rohrbach",
                "city": "Altenfelden i. Mkr.",
                "strasse": "Haselbach 30 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:14"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.3247,
                    47.869
                ]
            },
            "properties": {
                "id": "INFT-CCM3CR",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.484",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "5310",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Vöcklabruck",
                "city": "Mondsee",
                "strasse": "Moostrasse 11 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:18"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.9844,
                    47.7934
                ]
            },
            "properties": {
                "id": "INFT-CCM3CS",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.483",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "5071",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Salzburg Umgebung",
                "city": "Wals",
                "strasse": "Franz-Brötzner-Strasse 3 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:21"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.0865,
                    48.1685
                ]
            },
            "properties": {
                "id": "INFT-CCNA8V",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.449",
                "N": "0",
                "D": "1.453",
                "G": "0",
                "zip": "3370",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Melk",
                "city": "Ybbs",
                "strasse": "Bahnhofstrasse 26 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:37:48"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.9195,
                    48.0083
                ]
            },
            "properties": {
                "id": "INFT-CCNDQ2",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "4655",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Gmunden",
                "city": "Vorchdorf",
                "strasse": "Neue Landstrasse 74 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:6"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.1063,
                    47.38282
                ]
            },
            "properties": {
                "id": "INFT-CCQKMW",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.442",
                "N": "0",
                "D": "1.447",
                "G": "0",
                "zip": "8700",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Leoben",
                "city": "Leoben",
                "strasse": "Kärntner Strasse 92 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:30"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.8158,
                    46.8274
                ]
            },
            "properties": {
                "id": "INFT-CCQKMZ",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.499",
                "N": "0",
                "D": "1.489",
                "G": "0",
                "zip": "9990",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Lienz",
                "city": "Nussdorf",
                "strasse": "Hermann-Gmeiner-Strasse 14 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:44"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.81419,
                    47.15298
                ]
            },
            "properties": {
                "id": "INFT-CCQKN2",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.474",
                "N": "0",
                "D": "1.514",
                "G": "0",
                "zip": "6706",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Bludenz",
                "city": "Buers",
                "strasse": "Herrenau 2 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:47"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.62964,
                    47.32574
                ]
            },
            "properties": {
                "id": "INFT-CCQKN3",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.484",
                "N": "0",
                "D": "1.491",
                "G": "0",
                "zip": "6842",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Feldkirch",
                "city": "Koblach",
                "strasse": "Bundesstrasse 6 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:51"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.60797,
                    47.2724
                ]
            },
            "properties": {
                "id": "INFT-CCQKN4",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.477",
                "N": "0",
                "D": "1.497",
                "G": "0",
                "zip": "6830",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Feldkirch",
                "city": "Rankweil",
                "strasse": "St. Anna Weg 23 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:51"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.42698,
                    48.25258
                ]
            },
            "properties": {
                "id": "INFT-CCQKN5",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.433",
                "N": "0",
                "D": "1.453",
                "G": "0",
                "zip": "1210",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Floridsdorf",
                "city": "Wien",
                "strasse": "Donaufelderstrasse 137 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:39:1"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.24845,
                    47.56162
                ]
            },
            "properties": {
                "id": "INFT-CCQTME",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.464",
                "N": "0",
                "D": "1.474",
                "G": "0",
                "zip": "8940",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Liezen",
                "city": "Liezen",
                "strasse": "Gesäusestrasse 3a (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:30"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.51782,
                    46.78724
                ]
            },
            "properties": {
                "id": "INFT-CCRE4H",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.472",
                "N": "0",
                "D": "1.472",
                "G": "0",
                "zip": "9800",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Spittal",
                "city": "Spittal an der Drau",
                "strasse": "Lastenstrasse 1 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:37:30"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.87442,
                    46.65143
                ]
            },
            "properties": {
                "id": "INFT-CCRE4J",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.474",
                "N": "0",
                "D": "1.474",
                "G": "0",
                "zip": "9521",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Villach Land",
                "city": "Treffen",
                "strasse": "Ossiacher See Strasse (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:37:31"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.42804,
                    47.05646
                ]
            },
            "properties": {
                "id": "INFT-CCRE4V",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.432",
                "N": "0",
                "D": "1.436",
                "G": "0",
                "zip": "8020",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Graz",
                "city": "Graz Karlau",
                "strasse": "Karlauerguertel 4 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:25"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.415,
                    47.1541
                ]
            },
            "properties": {
                "id": "INFT-CCRE4X",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "1.462",
                "N": "0",
                "D": "1.467",
                "G": "0",
                "zip": "8811",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Murau",
                "city": "Scheifling",
                "strasse": "Gewerbepark 2 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:31"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.1820512,
                    47.9784772
                ]
            },
            "properties": {
                "id": "INFT-CDQ6MB",
                "name": "Shell Station St. Anton ",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "3283",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Scheibbs",
                "city": "St. Anton",
                "strasse": "Gnadenberg 29",
                "date": "22.8.2025",
                "time": "5:37:54"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    12.9961063,
                    47.7935477
                ]
            },
            "properties": {
                "id": "INFT-CDVJTE",
                "name": "Turmöl",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.517",
                "G": "0",
                "zip": "5020",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Salzburg Umgebung",
                "city": "Salzburg-Flughafen",
                "strasse": "Innsbrucker Bundesstraße 97",
                "date": "22.8.2025",
                "time": "5:38:18"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.95712,
                    48.23833
                ]
            },
            "properties": {
                "id": "INFT-CEJCPL",
                "name": "Diskont Tankstelle",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.494",
                "G": "0",
                "zip": "4702",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Grieskirchen",
                "city": "Wallern",
                "strasse": "Eferdinger Strasse 79 (am HOFER Parkplatz)",
                "date": "22.8.2025",
                "time": "5:38:8"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.38071,
                    48.71651
                ]
            },
            "properties": {
                "id": "INFT-CERGL7",
                "name": "boesch energy,  turmöl Quick",
                "S98": "0",
                "S95": "1.482",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "2136",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Mistelbach",
                "city": "Laa an der Thaya",
                "strasse": "Nordbahnstr. 53",
                "date": "22.8.2025",
                "time": "5:37:49"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.52827,
                    48.23962
                ]
            },
            "properties": {
                "id": "INFT-CFN6GW",
                "name": "Turmöl",
                "S98": "0",
                "S95": "1.419",
                "N": "0",
                "D": "1.445",
                "G": "0",
                "zip": "4310",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Perg",
                "city": "Mauthausen",
                "strasse": "Poschacherstraße 10",
                "date": "22.8.2025",
                "time": "5:38:11"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.449627,
                    46.641242
                ]
            },
            "properties": {
                "id": "INFT-CGGDB9",
                "name": "TurboSprit®",
                "S98": "0",
                "S95": "1.458",
                "N": "0",
                "D": "1.458",
                "G": "0",
                "zip": "9130",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Klagenfurt Land",
                "city": "Poggersdorf",
                "strasse": "Landesstrasse 2",
                "date": "22.8.2025",
                "time": "5:37:29"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.09422545,
                    46.63023943
                ]
            },
            "properties": {
                "id": "INFT-CGH26A",
                "name": "eni",
                "S98": "0",
                "S95": "1.999",
                "N": "0",
                "D": "1.999",
                "G": "0",
                "zip": "9212",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Klagenfurt Land",
                "city": "Techelsberg am Wörthersee",
                "strasse": "Tibitsch 84",
                "date": "22.8.2025",
                "time": "5:37:29"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.31935,
                    48.154766
                ]
            },
            "properties": {
                "id": "INFT-CGJK7B",
                "name": "Turmöl",
                "S98": "0",
                "S95": "1.437",
                "N": "0",
                "D": "1.447",
                "G": "0",
                "zip": "1230",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Liesing",
                "city": "Wien",
                "strasse": "Altmannsdorferstraße 150",
                "date": "22.8.2025",
                "time": "5:39:3"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.60052,
                    48.10019
                ]
            },
            "properties": {
                "id": "INFT-CGY28R",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.436",
                "N": "0",
                "D": "1.446",
                "G": "0",
                "zip": "3150",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "St. Pölten Land",
                "city": "Wilhelmsburg",
                "strasse": "Lilienfelderstraße 37",
                "date": "22.8.2025",
                "time": "5:37:52"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    9.77762,
                    47.19298
                ]
            },
            "properties": {
                "id": "INFT-CHDGD9",
                "name": "Disk",
                "S98": "0",
                "S95": "1.487",
                "N": "0",
                "D": "1.529",
                "G": "0",
                "zip": "6713",
                "land": "at",
                "bundesland": "Vorarlberg",
                "city2": "Bludenz",
                "city": "Ludesch",
                "strasse": "Walgaustraße 32",
                "date": "22.8.2025",
                "time": "5:38:48"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.157238,
                    48.01344
                ]
            },
            "properties": {
                "id": "INFT-CJYGAN",
                "name": "AVIA XPress (unser Service: Luft und Wasser)",
                "S98": "0",
                "S95": "1.487",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "3270",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Scheibbs",
                "city": "Scheibbs",
                "strasse": "Gewerbestraße 5",
                "date": "22.8.2025",
                "time": "5:37:53"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    11.399176862157587,
                    47.25418591941195
                ]
            },
            "properties": {
                "id": "INFT-CKMFD8",
                "name": "Gutmann ENI Tankstelle",
                "S98": "0",
                "S95": "1.599",
                "N": "0",
                "D": "1.599",
                "G": "0",
                "zip": "6020",
                "land": "at",
                "bundesland": "Tirol",
                "city2": "Innsbruck",
                "city": "Innsbruck",
                "strasse": "Leopoldstraße 67",
                "date": "22.8.2025",
                "time": "5:38:38"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.929128,
                    48.000903
                ]
            },
            "properties": {
                "id": "INFT-CKYGQQ",
                "name": "Lagerhaus Vorchdorf",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "4655",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Gmunden",
                "city": "Vorchdorf",
                "strasse": "Pettenbacherstraße 41",
                "date": "22.8.2025",
                "time": "5:38:7"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.950866,
                    47.899003
                ]
            },
            "properties": {
                "id": "INFT-CKYKXM",
                "name": "Lagerhaus Almtal",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "4644",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Gmunden",
                "city": "Scharnstein",
                "strasse": "Kalkofen 1",
                "date": "22.8.2025",
                "time": "5:38:7"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.5121246,
                    46.8512074
                ]
            },
            "properties": {
                "id": "INFT-CKZJ32",
                "name": "Rumpold",
                "S98": "0",
                "S95": "1.449",
                "N": "0",
                "D": "1.449",
                "G": "0",
                "zip": "8403",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Leibnitz",
                "city": "Lang",
                "strasse": "Stangersdorf-Gewerbegebiet 5",
                "date": "22.8.2025",
                "time": "5:38:29"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.760194,
                    47.887313
                ]
            },
            "properties": {
                "id": "INFT-CL2G79",
                "name": "Lagerhaus Altmünster",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "4813",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Gmunden",
                "city": "Altmünster",
                "strasse": "Großalmstraße 24",
                "date": "22.8.2025",
                "time": "5:38:7"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.37464,
                    46.75756
                ]
            },
            "properties": {
                "id": "INFT-CL3CTZ",
                "name": "Rumpold",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.449",
                "G": "0",
                "zip": "8443",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Leibnitz",
                "city": "Gleinstätten",
                "strasse": "Pistorf 208",
                "date": "22.8.2025",
                "time": "5:38:28"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.08005,
                    47.30293
                ]
            },
            "properties": {
                "id": "INFT-CLHGBJ",
                "name": "Turmöl Quick Posauner",
                "S98": "0",
                "S95": "1.519",
                "N": "0",
                "D": "1.544",
                "G": "0",
                "zip": "5621",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "St. Johann",
                "city": "St. Veit im Pongau",
                "strasse": "Klamm 14a",
                "date": "22.8.2025",
                "time": "5:38:22"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.079417,
                    47.061629
                ]
            },
            "properties": {
                "id": "INFT-CLLEJK",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.439",
                "N": "0",
                "D": "1.439",
                "G": "0",
                "zip": "8580",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Voitsberg",
                "city": "Köflach",
                "strasse": "Kärntnerstrasse 20",
                "date": "22.8.2025",
                "time": "5:38:33"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.67847,
                    46.68129
                ]
            },
            "properties": {
                "id": "INFT-CMDSQA",
                "name": "OMV Fast Lane - St. Jakob - Packerstraße 3",
                "S98": "0",
                "S95": "1.466",
                "N": "0",
                "D": "1.469",
                "G": "0",
                "zip": "9111",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Völkermarkt",
                "city": "St. Jakob",
                "strasse": "Packerstrasse 3",
                "date": "22.8.2025",
                "time": "5:37:32"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.001602886616373,
                    46.67329223509455
                ]
            },
            "properties": {
                "id": "INFT-CMWG64",
                "name": "One1 Tankstelle Kötschach",
                "S98": "0",
                "S95": "1.549",
                "N": "0",
                "D": "1.549",
                "G": "0",
                "zip": "9640",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Hermagor",
                "city": "Kötschach",
                "strasse": "Kötschach 264",
                "date": "22.8.2025",
                "time": "5:37:28"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.17962,
                    46.64263
                ]
            },
            "properties": {
                "id": "INFT-CNGCNU",
                "name": "SOCAR Schwarz - Kirchbach im Gailtal",
                "S98": "0",
                "S95": "1.564",
                "N": "0",
                "D": "1.569",
                "G": "0",
                "zip": "9632",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Hermagor",
                "city": "Kirchbach im Gailtal",
                "strasse": "Kirchbach 94",
                "date": "22.8.2025",
                "time": "5:37:28"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.88292064531762,
                    48.502476968764455
                ]
            },
            "properties": {
                "id": "INFT-CNGCP6",
                "name": "Genol - Lagerhaus",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "4134",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Rohrbach",
                "city": "Putzleinsdorf",
                "strasse": "Glotzing 20",
                "date": "22.8.2025",
                "time": "5:38:14"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.33126,
                    48.23011
                ]
            },
            "properties": {
                "id": "INFT-CNVHQA",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.45",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "3390",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Melk",
                "city": "Melk",
                "strasse": "Räcking 3",
                "date": "22.8.2025",
                "time": "5:37:49"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.221665,
                    47.848109
                ]
            },
            "properties": {
                "id": "INFT-CNVNV2",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "5303",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Salzburg Umgebung",
                "city": "THALGAU",
                "strasse": "SALZBURGER STRASSE 169",
                "date": "22.8.2025",
                "time": "5:38:21"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.4036,
                    48.26578
                ]
            },
            "properties": {
                "id": "INFT-CP57X4",
                "name": "boesch energy,  turmöl",
                "S98": "0",
                "S95": "1.422",
                "N": "0",
                "D": "1.432",
                "G": "0",
                "zip": "1210",
                "land": "at",
                "bundesland": "Wien",
                "city2": "Floridsdorf",
                "city": "Wien",
                "strasse": "Brünnerstr. 64",
                "date": "22.8.2025",
                "time": "5:39:0"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.11762,
                    48.44082
                ]
            },
            "properties": {
                "id": "INFT-CQMEEY",
                "name": "Genol Lagerhaus Innviertel-Traunviertel-Urfahr",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "4175",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Urfahr Umgebung",
                "city": "Herzogsdorf",
                "strasse": "Wigretsberg 9",
                "date": "22.8.2025",
                "time": "5:38:16"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.1209213,
                    47.9899716
                ]
            },
            "properties": {
                "id": "INFT-CQMJFL",
                "name": "Genol Lagerhaus Innviertel-Traunviertel-Urfahr",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "4552",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Kirchdorf",
                "city": "Wartberg",
                "strasse": "Bahnhofstraße 7",
                "date": "22.8.2025",
                "time": "5:38:9"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.2389091,
                    47.8885554
                ]
            },
            "properties": {
                "id": "INFT-CQMJFM",
                "name": "Genol Lagerhaus Innviertel-Traunviertel-Urfahr",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "4591",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Kirchdorf",
                "city": "Molln",
                "strasse": "Mollner Straße 7",
                "date": "22.8.2025",
                "time": "5:38:9"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.01119,
                    47.96416
                ]
            },
            "properties": {
                "id": "INFT-CQN355",
                "name": "Genol Lagerhaus Innviertel-Traunviertel-Urfahr",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "4643",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Kirchdorf",
                "city": "Pettenbach",
                "strasse": "Almtalstraße 3",
                "date": "22.8.2025",
                "time": "5:38:9"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.218088,
                    48.5527675
                ]
            },
            "properties": {
                "id": "INFT-CQNF32",
                "name": "Genol Lagerhaus Innviertel-Traunviertel-Urfahr",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "4191",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Urfahr Umgebung",
                "city": "Vorderweissenbach",
                "strasse": "Hauptstraße 17",
                "date": "22.8.2025",
                "time": "5:38:16"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.0563175517918,
                    48.3470443238984
                ]
            },
            "properties": {
                "id": "INFT-CQNF33",
                "name": "Genol Lagerhaus Innviertel-Traunviertel-Urfahr",
                "S98": "0",
                "S95": "1.489",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "4101",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Urfahr Umgebung",
                "city": "Feldkirchen",
                "strasse": "Hauptstraße 17",
                "date": "22.8.2025",
                "time": "5:38:16"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.98018,
                    48.15888
                ]
            },
            "properties": {
                "id": "INFT-CRFR9W",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.484",
                "N": "0",
                "D": "1.491",
                "G": "0",
                "zip": "4600",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Wels",
                "city": "Wels",
                "strasse": "Prillingerstraße 8",
                "date": "22.8.2025",
                "time": "5:38:2"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.1342715574788,
                    47.1054580712824
                ]
            },
            "properties": {
                "id": "INFT-CRHF5F",
                "name": "Scheyerer Energie- & Kraftstoffe GmbH",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.512",
                "G": "0",
                "zip": "5640",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "St. Johann",
                "city": "Bad Gastein",
                "strasse": "Böcksteiner Bundesstraße 15",
                "date": "22.8.2025",
                "time": "5:38:21"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.63286,
                    46.63452
                ]
            },
            "properties": {
                "id": "INFT-CRRCEM",
                "name": "unisprit®",
                "S98": "0",
                "S95": "1.458",
                "N": "0",
                "D": "1.458",
                "G": "0",
                "zip": "9125",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Völkermarkt",
                "city": "Kohldorf",
                "strasse": "Kohldorf 66",
                "date": "22.8.2025",
                "time": "5:37:32"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.538732,
                    46.835404
                ]
            },
            "properties": {
                "id": "INFT-CS79SN",
                "name": "M3 Klein St. Paul",
                "S98": "0",
                "S95": "1.479",
                "N": "0",
                "D": "1.489",
                "G": "0",
                "zip": "9373",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "St. Veit",
                "city": "Klein St. Paul",
                "strasse": "Bundesstraße 16",
                "date": "22.8.2025",
                "time": "5:37:29"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.036477300015548,
                    48.2546850983996
                ]
            },
            "properties": {
                "id": "INFT-CWFFBN",
                "name": "M3 Braunau",
                "S98": "0",
                "S95": "1.484",
                "N": "0",
                "D": "1.504",
                "G": "0",
                "zip": "5280",
                "land": "at",
                "bundesland": "Oberösterreich",
                "city2": "Braunau",
                "city": "Braunau am Inn",
                "strasse": "Salzburger Str. 11",
                "date": "22.8.2025",
                "time": "5:38:3"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.41597,
                    47.05026
                ]
            },
            "properties": {
                "id": "INFT-CWJM9U",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.432",
                "N": "0",
                "D": "1.436",
                "G": "0",
                "zip": "8053",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Graz",
                "city": "Graz",
                "strasse": "Kärntner Straße 137",
                "date": "22.8.2025",
                "time": "5:38:25"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.700095,
                    47.110072
                ]
            },
            "properties": {
                "id": "INFT-CXKMLH",
                "name": "Rumpold",
                "S98": "0",
                "S95": "1.458",
                "N": "0",
                "D": "1.459",
                "G": "0",
                "zip": "8200",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Weiz",
                "city": "Gleisdorf",
                "strasse": "Industriestraße 29",
                "date": "22.8.2025",
                "time": "5:38:34"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.42506,
                    47.139626
                ]
            },
            "properties": {
                "id": "INFT-CXTKVV",
                "name": "Rumpold",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.459",
                "G": "0",
                "zip": "8811",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Murau",
                "city": "Scheifling",
                "strasse": "Puchfeld 1",
                "date": "22.8.2025",
                "time": "5:38:31"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.0383,
                    47.39393
                ]
            },
            "properties": {
                "id": "INFT-CXUHTH",
                "name": "Rumpold",
                "S98": "0",
                "S95": "1.442",
                "N": "0",
                "D": "1.447",
                "G": "0",
                "zip": "8792",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Leoben",
                "city": "St. Peter Freienstein",
                "strasse": "Gewerbepark",
                "date": "22.8.2025",
                "time": "5:38:30"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.795488,
                    47.133005
                ]
            },
            "properties": {
                "id": "INFT-CXUKWD",
                "name": "Rumpold",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "5580",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "Tamsweg",
                "city": "Tamsweg",
                "strasse": "Gewerbepark",
                "date": "22.8.2025",
                "time": "5:38:22"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.12984,
                    47.38481
                ]
            },
            "properties": {
                "id": "INFT-CXUMG8",
                "name": "Rumpold",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.447",
                "G": "0",
                "zip": "8700",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Leoben",
                "city": "Leoben",
                "strasse": "Waltenbachstraße 9",
                "date": "22.8.2025",
                "time": "5:38:29"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.17749,
                    47.108763
                ]
            },
            "properties": {
                "id": "INFT-CXUQSA",
                "name": "Rumpold",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.479",
                "G": "0",
                "zip": "8850",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Murau",
                "city": "Murau",
                "strasse": "Bahnhofviertel 9",
                "date": "22.8.2025",
                "time": "5:38:31"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.71354,
                    47.19517
                ]
            },
            "properties": {
                "id": "INFT-CYPHF2",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.457",
                "N": "0",
                "D": "1.462",
                "G": "0",
                "zip": "8753",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Judenburg",
                "city": "Fohnsdorf",
                "strasse": "Bundesstraße 33",
                "date": "22.8.2025",
                "time": "5:38:36"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.098398188615368,
                    47.10442914674201
                ]
            },
            "properties": {
                "id": "INFT-CZ6SPV",
                "name": "M3 Kreischberg mit moderner SB Waschanlage",
                "S98": "0",
                "S95": "1.492",
                "N": "0",
                "D": "1.499",
                "G": "0",
                "zip": "8861",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Murau",
                "city": "Bundeststrasse 1",
                "strasse": "St. Georgen am Kreischberg",
                "date": "22.8.2025",
                "time": "5:38:31"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.60925,
                    48.04498
                ]
            },
            "properties": {
                "id": "INFT-D45GM8",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.436",
                "N": "0",
                "D": "1.446",
                "G": "0",
                "zip": "3160",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Lilienfeld",
                "city": "Traisen",
                "strasse": "Mariazellerstraße 33a",
                "date": "22.8.2025",
                "time": "5:37:47"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.80832,
                    48.016305
                ]
            },
            "properties": {
                "id": "INFT-D4ECEC",
                "name": "Rumpold",
                "S98": "0",
                "S95": "0",
                "N": "0",
                "D": "1.49",
                "G": "0",
                "zip": "2460",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Bruck/Leitha",
                "city": "Bruckneudorf",
                "strasse": "Parndorfer Str. 173",
                "date": "22.8.2025",
                "time": "5:37:22"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.255484419,
                    47.91120325
                ]
            },
            "properties": {
                "id": "INFT-D6UCMQ",
                "name": "Rumpold",
                "S98": "0",
                "S95": "1.483",
                "N": "0",
                "D": "1.476",
                "G": "0",
                "zip": "2601",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Wiener Neustadt Land",
                "city": "Sollenau",
                "strasse": "Industriestraße-Nord 1",
                "date": "22.8.2025",
                "time": "5:37:57"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.40896,
                    47.03413
                ]
            },
            "properties": {
                "id": "INFT-D7NESK",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.432",
                "N": "0",
                "D": "1.436",
                "G": "0",
                "zip": "8054",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Graz",
                "city": "Graz",
                "strasse": "Kärntnerstraße 291",
                "date": "22.8.2025",
                "time": "5:38:27"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.081523,
                    47.289223
                ]
            },
            "properties": {
                "id": "INFT-D7WPVH",
                "name": "Rumpold",
                "S98": "0",
                "S95": "1.483",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "7411",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Oberwart",
                "city": "Markt Allhau",
                "strasse": "Hauptstraße 5",
                "date": "22.8.2025",
                "time": "5:37:25"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.35752,
                    48.36735
                ]
            },
            "properties": {
                "id": "INFT-D8HBXW",
                "name": "GENOL",
                "S98": "0",
                "S95": "1.464",
                "N": "0",
                "D": "1.474",
                "G": "0",
                "zip": "2111",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Korneuburg",
                "city": "Tresdorf",
                "strasse": "Lagerhausplatz 1",
                "date": "22.8.2025",
                "time": "5:37:46"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.843557,
                    46.62369
                ]
            },
            "properties": {
                "id": "INFT-D8RJW9",
                "name": "Rumpold",
                "S98": "0",
                "S95": "1.454",
                "N": "0",
                "D": "1.454",
                "G": "0",
                "zip": "9500",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Villach",
                "city": "Villach",
                "strasse": "Rennsteinerstraße 34",
                "date": "22.8.2025",
                "time": "5:37:27"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.849851,
                    46.597867
                ]
            },
            "properties": {
                "id": "INFT-D8SHCH",
                "name": "Rumpold",
                "S98": "0",
                "S95": "1.454",
                "N": "0",
                "D": "1.454",
                "G": "0",
                "zip": "9500",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Villach",
                "city": "Villach",
                "strasse": "Karawankenweg 17",
                "date": "22.8.2025",
                "time": "5:37:27"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.173548978765615,
                    47.323801005828884
                ]
            },
            "properties": {
                "id": "INFT-D9PJ9M",
                "name": "M3 St. Veit im Pongau + Waschcenter",
                "S98": "0",
                "S95": "1.519",
                "N": "0",
                "D": "1.544",
                "G": "0",
                "zip": "5620",
                "land": "at",
                "bundesland": "Salzburg",
                "city2": "St. Johann",
                "city": "St. Veit im Pongau",
                "strasse": "Gewerbestraße 3",
                "date": "22.8.2025",
                "time": "5:38:22"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.28269,
                    47.84106
                ]
            },
            "properties": {
                "id": "INFT-D9VK4F",
                "name": "AVANTI - Eggendorf Pottendorferstraße 280",
                "S98": "0",
                "S95": "1.483",
                "N": "0",
                "D": "1.491",
                "G": "0",
                "zip": "2492",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Wiener Neustadt Land",
                "city": "Eggendorf",
                "strasse": "Pottendorferstrasse 280",
                "date": "22.8.2025",
                "time": "5:37:57"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.294425,
                    48.373263
                ]
            },
            "properties": {
                "id": "INFT-DAB9U8",
                "name": "Disk TANKAUTOMAT",
                "S98": "0",
                "S95": "1.472",
                "N": "0",
                "D": "0",
                "G": "0",
                "zip": "2100",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Korneuburg",
                "city": "Leobendorf",
                "strasse": "Schliebrückl 1",
                "date": "22.8.2025",
                "time": "5:37:46"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    16.16281215,
                    47.21238492
                ]
            },
            "properties": {
                "id": "INFT-DEBHYN",
                "name": "M3 Litzelsdorf",
                "S98": "0",
                "S95": "1.466",
                "N": "0",
                "D": "1.476",
                "G": "0",
                "zip": "7532",
                "land": "at",
                "bundesland": "Burgenland",
                "city2": "Oberwart",
                "city": "Litzelsdorf",
                "strasse": "Bundesstraße 2",
                "date": "22.8.2025",
                "time": "5:37:25"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.713338457124923,
                    47.098782082977664
                ]
            },
            "properties": {
                "id": "INFT-DFL9NE",
                "name": "No Name Diskonttankstelle ",
                "S98": "0",
                "S95": "1.459",
                "N": "0",
                "D": "1.459",
                "G": "0",
                "zip": "8200",
                "land": "at",
                "bundesland": "Steiermark",
                "city2": "Weiz",
                "city": "Gleisdorf",
                "strasse": "Neugasse 101",
                "date": "22.8.2025",
                "time": "5:38:35"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.819035,
                    46.943718
                ]
            },
            "properties": {
                "id": "INFT-DFLLC8",
                "name": "SOCAR Bad St. Leonhard",
                "S98": "0",
                "S95": "1.459",
                "N": "0",
                "D": "1.464",
                "G": "0",
                "zip": "9462",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Wolfsberg",
                "city": "Bad St. Leonhard",
                "strasse": "Wiesenau 48",
                "date": "22.8.2025",
                "time": "5:37:33"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    14.57518,
                    46.61506
                ]
            },
            "properties": {
                "id": "INFT-DGFUAK",
                "name": "Turmöl Quick",
                "S98": "0",
                "S95": "1.467",
                "N": "0",
                "D": "1.469",
                "G": "0",
                "zip": "9122",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Völkermarkt",
                "city": "St. Kanzian",
                "strasse": "Klopeiner Straße 6",
                "date": "22.8.2025",
                "time": "5:37:33"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    13.0032407,
                    46.6721177
                ]
            },
            "properties": {
                "id": "INFT-DHZV5G",
                "name": "Lagerhaus Tankstelle",
                "S98": "0",
                "S95": "1.54",
                "N": "0",
                "D": "1.54",
                "G": "0",
                "zip": "9640",
                "land": "at",
                "bundesland": "Kärnten",
                "city2": "Hermagor",
                "city": "Kötschach",
                "strasse": "Kötschach 153",
                "date": "22.8.2025",
                "time": "5:37:27"
            }
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    15.105846,
                    48.158543
                ]
            },
            "properties": {
                "id": "INFT-DK4DFY",
                "name": "JET TANKSTELLE",
                "S98": "0",
                "S95": "1.449",
                "N": "0",
                "D": "1.453",
                "G": "0",
                "zip": "3254",
                "land": "at",
                "bundesland": "Niederösterreich",
                "city2": "Melk",
                "city": "YBBS / BERGLAND",
                "strasse": "UNTEREGGING 21",
                "date": "22.8.2025",
                "time": "5:37:48"
            }
        }
    ]
}
,
            stations: [],
            datatable: null,
            getBundesland: "",
            getKraftstoff: "",
            initialSearchTerm: '', // Suchbegriff
            initialSortCol: 4, // Kraftstoff: s
            // Prepare the variables
            prepareVariables: function() {
                // Get url params for "bundesland" and "kraftstoff" and set the search and sorting field accordingly
                var urlParams = new URLSearchParams(window.location.search);
                if (urlParams.has("bundesland")) {
                    arboe.getBundesland = urlParams.get("bundesland");
                    arboe.initialSearchTerm = arboe.getBundesland;
                }
                if (urlParams.has("kraftstoff")) {
                    arboe.getKraftstoff = urlParams.get("kraftstoff");
                    if (arboe.getKraftstoff == "s") {
                        arboe.initialSortCol = 4;
                    } else if (arboe.getKraftstoff = "d") {
                        arboe.initialSortCol = 5;
                    }
                }
            },
            // Prepare the station data
            prepareStations: function() {
                arboe.json.features.forEach(function (item, index) {
                    var s = (item.properties.S95 == 0 ? 'unbekannt' : item.properties.S95);
                    var d = (item.properties.D == 0 ? 'unbekannt' : item.properties.D);
                    var station = new Array(
                        item.properties.name,
                        item.properties.bundesland,
                        item.properties.zip,
                        item.properties.city,
                        s,
                        d,
                        "<a href='https://map.arboe.at/tankstellen?gas_station=" + item.properties.id + "' target='_blank' title='Link zur ARBÖ Karte'><img src='/typo3conf/ext/arboe_theme/Resources/Public/Icons/maps.png' style='width:25px;'></a>",
                    );
                    // Skip following gas stations:
                    // - Empty name
                    // - Both prices empty
                    if (item.properties.name != '' || (item.properties.s == '' && item.properties.d == '')) {
                        arboe.stations.push(station);
                    }
                });
                arboe.populateDataTable();
            },
            populateDataTable: function() {
                arboe.datatable = $("#stations").DataTable({
                    mark: true,
                    'sDom': '<"H"<"colviz">lTfr><"clear">t<"F"ip>', // Need to add a clear div for Chris Firefox Browser!
                    'data': arboe.stations,
                    'aaSorting': [[ arboe.initialSortCol, "asc"]], // Which shown column, starting with 0
                    'search': {
                        'search': arboe.initialSearchTerm
                    },
                    'iDisplayLength': 25,
                    'oLanguage': {
                        'sLengthMenu': 'Anzeigen von _MENU_ Tankstellen',
                        'sSearch' : '',
                        'sZeroRecords' : '',
                        'oPaginate': {
                            'sFirst': '',
                            'sLast': '',
                            'sNext': '',
                            'sPrevious': '',
                        },
                        'sInfo': 'Anzeige von Tankstellen _START_ bis _END_ (insgesamt _TOTAL_)',
                        'sInfoFiltered': '',
                    },
                    'columns': [
                        { width: "30%" }, // Name
                        { width: "15%" }, // Bundesland
                        { width: "8"}, // PLZ
                        { width: "21"}, // Ort
                        { width: "15%" }, // Super 95
                        { width: "6%" }, // Diesel
                        { width: "5%", "className":"text-center" }, // Link zu Karte
                    ],
                    "initComplete": function() {}
                });
            },
        });
        // On document load, prepare the variables, and populate the datatable
        $(function() {
            arboe.prepareVariables();
            arboe.prepareStations();
        });
    
